-- HRMIS.dbo.ozekimessagein definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ozekimessagein;

CREATE TABLE HRMIS.dbo.ozekimessagein (
	id int IDENTITY(1,1) NOT NULL,
	sender varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	receiver varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	msg varchar(160) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	senttime varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	receivedtime varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	operator varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	msgtype varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	reference varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
