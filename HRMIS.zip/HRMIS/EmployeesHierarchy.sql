-- HRMIS.dbo.EmployeesHierarchy definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EmployeesHierarchy;

CREATE TABLE HRMIS.dbo.EmployeesHierarchy (
	EmpId int IDENTITY(1,1) NOT NULL,
	EmployeeId int NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Designation nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReportingManager nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReportId int NULL,
	PassportphotoUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_EmployeesHierarchy_1 PRIMARY KEY (EmpId)
);
