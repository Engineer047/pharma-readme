-- HRMIS.dbo.ECICalendarEvent_Test definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ECICalendarEvent_Test;

CREATE TABLE HRMIS.dbo.ECICalendarEvent_Test (
	event_id int IDENTITY(1,1) NOT NULL,
	description nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	title nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	event_start datetime NULL,
	event_end datetime NULL,
	all_day bit NULL,
	CONSTRAINT PK_event PRIMARY KEY (event_id)
);
