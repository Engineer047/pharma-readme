-- HRMIS.dbo.SACCO definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SACCO;

CREATE TABLE HRMIS.dbo.SACCO (
	EMPID int NULL,
	EMPNO nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NAME nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CoopSharesSaccoId int NULL,
	COOPSAHRES nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LoanPrincipalSaccoId int NULL,
	LOANPRINCIPAL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LoanInterestSaccoId int NULL,
	LOANINTEREST nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
