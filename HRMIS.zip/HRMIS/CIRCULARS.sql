-- HRMIS.dbo.CIRCULARS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.CIRCULARS;

CREATE TABLE HRMIS.dbo.CIRCULARS (
	CircularId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Subject nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Message nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Seen bit NULL,
	[Date] date NULL,
	CONSTRAINT PK_CIRCULARS_1 PRIMARY KEY (CircularId)
);
