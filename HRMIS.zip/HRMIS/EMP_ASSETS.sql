-- HRMIS.dbo.EMP_ASSETS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EMP_ASSETS;

CREATE TABLE HRMIS.dbo.EMP_ASSETS (
	EmpAssetId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	AssetId int NULL,
	[Date] date NULL,
	Notes nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Quantity decimal(18,2) NULL,
	Returned bit DEFAULT 0 NULL,
	StatusId int NULL,
	CONSTRAINT PK_EMP_ASSETS PRIMARY KEY (EmpAssetId)
);
