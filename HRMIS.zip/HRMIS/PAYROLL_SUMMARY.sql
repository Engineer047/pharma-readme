-- HRMIS.dbo.PAYROLL_SUMMARY definition

-- Drop table

-- DROP TABLE HRMIS.dbo.PAYROLL_SUMMARY;

CREATE TABLE HRMIS.dbo.PAYROLL_SUMMARY (
	RecordId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DepartmentId int NULL,
	YearId int NULL,
	MonthId int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SysDate datetime DEFAULT getdate() NULL,
	RecordType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RecordSort int NULL,
	RecordName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount decimal(18,2) NULL,
	StaffCount AS ([dbo].[getPayrollSummaryStaffCount]([DepartmentId],[MonthId],[YearId])),
	CONSTRAINT PK_PAYROLL_SUMMARY PRIMARY KEY (RecordId)
);
