-- HRMIS.dbo.ACC0395 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0395;

CREATE TABLE HRMIS.dbo.ACC0395 (
	IccidentId int IDENTITY(1,1) NOT NULL,
	IccidentCategoryId int NULL,
	EmpId int NULL,
	EmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReportedTo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Iccident nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Notes nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Closed bit NULL,
	SysDate datetime DEFAULT getdate() NULL,
	DateReported date NULL,
	DateOfIccident date NULL,
	IncidentActionId int NULL,
	CompensationAmount float NULL,
	CONSTRAINT PK_ACC0395 PRIMARY KEY (IccidentId)
);
