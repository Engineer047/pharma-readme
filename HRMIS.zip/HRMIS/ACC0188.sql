-- HRMIS.dbo.ACC0188 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0188;

CREATE TABLE HRMIS.dbo.ACC0188 (
	AppraisalId int IDENTITY(1,1) NOT NULL,
	EmpId int NOT NULL,
	CONSTRAINT PK_ACC0188 PRIMARY KEY (AppraisalId,EmpId)
);
