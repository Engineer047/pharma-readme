-- HRMIS.dbo.Machines definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Machines;

CREATE TABLE HRMIS.dbo.Machines (
	ID int IDENTITY(1,1) NOT NULL,
	MachineAlias varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	ConnectType int NOT NULL,
	IP varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SerialPort int DEFAULT 1 NULL,
	Port int DEFAULT 1 NULL,
	Baudrate int NULL,
	MachineNumber int DEFAULT 1 NOT NULL,
	IsHost bit NULL,
	Enabled bit NULL,
	CommPassword varchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UILanguage smallint DEFAULT -1 NULL,
	DateFormat smallint DEFAULT -1 NULL,
	InOutRecordWarn smallint DEFAULT -1 NULL,
	Idle smallint DEFAULT -1 NULL,
	Voice smallint DEFAULT -1 NULL,
	managercount smallint DEFAULT -1 NULL,
	usercount smallint DEFAULT -1 NULL,
	fingercount smallint DEFAULT -1 NULL,
	SecretCount smallint DEFAULT -1 NULL,
	FirmwareVersion varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ProductType varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LockControl smallint DEFAULT -1 NULL,
	Purpose smallint DEFAULT 1 NULL,
	ProduceKind int DEFAULT 1 NULL,
	sn varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhotoStamp varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '0' NULL,
	IsIfChangeConfigServer2 int DEFAULT 0 NULL,
	IsAndroid varchar(1) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '0' NULL,
	pushver int DEFAULT 0 NULL,
	CONSTRAINT PK__Machines__3214EC276E0F28CB PRIMARY KEY (ID)
);
