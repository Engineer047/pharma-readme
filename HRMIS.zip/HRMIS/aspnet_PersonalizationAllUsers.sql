-- HRMIS.dbo.aspnet_PersonalizationAllUsers definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_PersonalizationAllUsers;

CREATE TABLE HRMIS.dbo.aspnet_PersonalizationAllUsers (
	PathId uniqueidentifier NOT NULL,
	PageSettings image NOT NULL,
	LastUpdatedDate datetime NOT NULL,
	CONSTRAINT PK__aspnet_P__CD67DC59A654C8D4 PRIMARY KEY (PathId),
	CONSTRAINT FK__aspnet_Pe__PathI__5378497A FOREIGN KEY (PathId) REFERENCES HRMIS.dbo.aspnet_Paths(PathId)
);
