-- HRMIS.dbo.ACC0156 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0156;

CREATE TABLE HRMIS.dbo.ACC0156 (
	ServiceProviderId int IDENTITY(1,1) NOT NULL,
	ServiceProvider nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Address nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Town nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0156 PRIMARY KEY (ServiceProviderId)
);
