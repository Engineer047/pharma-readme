-- HRMIS.dbo.ACC0454 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0454;

CREATE TABLE HRMIS.dbo.ACC0454 (
	CashualPayrollScheduleId int IDENTITY(1,10001) NOT NULL,
	[Year] int NULL,
	[Month] int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Week varchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PSFrom date NULL,
	PSTo date NULL,
	Closed bit NULL,
	ClosedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ProcessedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ApproavedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PayRatio float NULL,
	RecoveryWeekCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0454 PRIMARY KEY (CashualPayrollScheduleId)
);
