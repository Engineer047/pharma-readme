-- HRMIS.dbo.TARGETS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.TARGETS;

CREATE TABLE HRMIS.dbo.TARGETS (
	TargetId int IDENTITY(1,1) NOT NULL,
	KPIId int NULL,
	AppraisalId int NULL,
	JobTitleId int NULL,
	KPA nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	KPM nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Target nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Marks decimal(18,2) NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_KPA PRIMARY KEY (TargetId)
);
