-- HRMIS.dbo.AttLogs definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AttLogs;

CREATE TABLE HRMIS.dbo.AttLogs (
	RCNO int IDENTITY(1,1) NOT NULL,
	Staffcode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	rcDate date NULL,
	rcDateTime datetime NULL,
	WeekDay nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	InOutMode int NULL,
	Status nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Device nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
