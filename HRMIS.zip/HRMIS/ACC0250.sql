-- HRMIS.dbo.ACC0250 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0250;

CREATE TABLE HRMIS.dbo.ACC0250 (
	AssetId int IDENTITY(1,1) NOT NULL,
	AssetCategoryId int NULL,
	AssetName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AssetModel nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SerialNumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	InStock bit NULL,
	CONSTRAINT PK_ACC050 PRIMARY KEY (AssetId)
);
