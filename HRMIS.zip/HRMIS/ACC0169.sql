-- HRMIS.dbo.ACC0169 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0169;

CREATE TABLE HRMIS.dbo.ACC0169 (
	CasualsPaymentId int IDENTITY(1,1) NOT NULL,
	CasualsId int NOT NULL,
	EmpId int NOT NULL,
	IsHourlyRate bit DEFAULT 0 NULL,
	IsDailyRate bit DEFAULT 0 NULL,
	IsWeeklyRate bit DEFAULT 0 NULL,
	Amount decimal(18,2) NULL,
	Tax decimal(18,2) NULL,
	OtherDeduction decimal(18,2) NULL,
	NetPay decimal(18,2) NULL,
	CONSTRAINT PK_ACC0169_1 PRIMARY KEY (CasualsPaymentId,CasualsId,EmpId),
	CONSTRAINT FK_ACC0169_ACC0166 FOREIGN KEY (CasualsId,EmpId) REFERENCES HRMIS.dbo.ACC0166(CasualsId,EmpId)
);
