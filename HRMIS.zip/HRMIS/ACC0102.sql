-- HRMIS.dbo.ACC0102 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0102;

CREATE TABLE HRMIS.dbo.ACC0102 (
	YearId int NOT NULL,
	[Year] int NULL,
	CONSTRAINT PK_ACC0102 PRIMARY KEY (YearId)
);
