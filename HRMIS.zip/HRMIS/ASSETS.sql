-- HRMIS.dbo.ASSETS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ASSETS;

CREATE TABLE HRMIS.dbo.ASSETS (
	AssetId int IDENTITY(1,1) NOT NULL,
	CategoryId int NULL,
	AssetName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SerialNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Model nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cost decimal(18,2) NULL,
	LocationId int NULL,
	[Date] date NULL,
	Status nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Assigned bit DEFAULT 0 NULL,
	[Condition] bit DEFAULT 1 NULL,
	LifeInYears AS (datediff(year,[Date],CONVERT([date],getdate(),(0)))),
	UsefulLife decimal(18,2) NULL,
	CurrentValue AS ([dbo].[fGetAssetValue]([UsefulLife],[Cost],[AssetId])),
	CONSTRAINT PK_ASSETS PRIMARY KEY (AssetId)
);
