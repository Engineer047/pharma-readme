-- HRMIS.dbo.ACC0013 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0013;

CREATE TABLE HRMIS.dbo.ACC0013 (
	TribeId int IDENTITY(1,1) NOT NULL,
	Tribe nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0013 PRIMARY KEY (TribeId)
);
