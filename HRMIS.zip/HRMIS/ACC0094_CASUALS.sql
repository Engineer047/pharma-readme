-- HRMIS.dbo.ACC0094_CASUALS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0094_CASUALS;

CREATE TABLE HRMIS.dbo.ACC0094_CASUALS (
	AllowanceId int NOT NULL,
	EmpId int NULL,
	CompanyId int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthId int NULL,
	YearId int NULL,
	Week int NULL,
	Amount decimal(18,2) NULL,
	EmpAllowanceId int IDENTITY(1,1) NOT NULL,
	Allowance nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	Cancelled bit DEFAULT 0 NULL,
	Locked bit DEFAULT 0 NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0094_CASUALS PRIMARY KEY (EmpAllowanceId)
);
