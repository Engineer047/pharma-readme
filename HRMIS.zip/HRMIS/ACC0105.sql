-- HRMIS.dbo.ACC0105 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0105;

CREATE TABLE HRMIS.dbo.ACC0105 (
	JobTitleShiftId int IDENTITY(1,1) NOT NULL,
	ShiftId int NULL,
	JobTitleId int NULL,
	DFrom datetime NULL,
	DTo datetime NULL,
	CONSTRAINT PK_ACC0105 PRIMARY KEY (JobTitleShiftId)
);
