-- HRMIS.dbo.aspnet_SchemaVersions definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_SchemaVersions;

CREATE TABLE HRMIS.dbo.aspnet_SchemaVersions (
	Feature nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	CompatibleSchemaVersion nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	IsCurrentVersion bit NOT NULL,
	CONSTRAINT PK__aspnet_S__5A1E6BC11AFAAD28 PRIMARY KEY (Feature,CompatibleSchemaVersion)
);
