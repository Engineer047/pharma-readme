-- HRMIS.dbo.INSURANCE definition

-- Drop table

-- DROP TABLE HRMIS.dbo.INSURANCE;

CREATE TABLE HRMIS.dbo.INSURANCE (
	EmpInsuranceId int IDENTITY(1,1) NOT NULL,
	InsuranceId int NOT NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Amount decimal(18,2) NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Insurance nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LogDate datetime DEFAULT getdate() NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	TotalAmount decimal(18,0) NULL,
	CONSTRAINT PK_INSURANCE PRIMARY KEY (EmpInsuranceId)
);
