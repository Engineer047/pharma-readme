-- HRMIS.dbo.ACC0207 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0207;

CREATE TABLE HRMIS.dbo.ACC0207 (
	AppraisalFinalScoresId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NULL,
	EmpId int NULL,
	AgreedActivitities decimal(18,2) NULL,
	Competencies decimal(18,2) NULL,
	FinalScoreRatingId int NULL,
	Remarks nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0207 PRIMARY KEY (AppraisalFinalScoresId)
);
