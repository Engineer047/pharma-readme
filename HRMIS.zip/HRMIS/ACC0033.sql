-- HRMIS.dbo.ACC0033 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0033;

CREATE TABLE HRMIS.dbo.ACC0033 (
	EducationLevelId int IDENTITY(1,1) NOT NULL,
	EducationLevel nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0033 PRIMARY KEY (EducationLevelId)
);
