-- HRMIS.dbo.SACCODATA definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SACCODATA;

CREATE TABLE HRMIS.dbo.SACCODATA (
	EMPNO nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NAME nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AMOUNT decimal(18,2) NULL,
	SACCO nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CATEGORY nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SACCOID int NULL,
	EMPID int NULL
);
