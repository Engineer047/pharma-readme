-- HRMIS.dbo.ACC0093 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0093;

CREATE TABLE HRMIS.dbo.ACC0093 (
	NonCashBenefitId int NULL,
	CompanyId int NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	ActualContribution decimal(18,2) NULL,
	Amount float NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpNonCashBenefitId int IDENTITY(1,1) NOT NULL,
	NonCashBenefit nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	Cancelled bit DEFAULT 0 NULL,
	Locked bit DEFAULT 0 NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0093 PRIMARY KEY (EmpNonCashBenefitId)
);
