-- HRMIS.dbo.SYSTEM_EMAIL definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SYSTEM_EMAIL;

CREATE TABLE HRMIS.dbo.SYSTEM_EMAIL (
	EmailId int IDENTITY(1,1) NOT NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Password nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SMTP nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PORT int NULL,
	UseSSL bit NULL,
	CONSTRAINT PK_SYSTEM_EMAIL PRIMARY KEY (EmailId)
);
