-- HRMIS.dbo.ACC0175 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0175;

CREATE TABLE HRMIS.dbo.ACC0175 (
	DisciplineId int IDENTITY(1,1) NOT NULL,
	EmpId int NOT NULL,
	DateOfIncident date NULL,
	InfractionCategoryid int NULL,
	Infraction nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	InfractionLocation nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ActionTakenId int NULL,
	DocumentURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cost decimal(18,2) NOT NULL,
	InfractionOriginId int NULL,
	NumberInvolved int NULL,
	Description nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Intervened bit DEFAULT 0 NULL,
	InterventionId int NULL,
	InterventionComment nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReportedByEmpId int NULL,
	YearMonth AS ([dbo].[fGetYearMonthJoint]([DateOfIncident])),
	CONSTRAINT PK_ACC0175 PRIMARY KEY (DisciplineId,EmpId)
);
