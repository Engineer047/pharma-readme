-- HRMIS.dbo.ACC0030 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0030;

CREATE TABLE HRMIS.dbo.ACC0030 (
	EmpCoursesId int IDENTITY(1,1) NOT NULL,
	TrainingId int NULL,
	TrainerId int NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	CourseId int NULL,
	ModuleId int NULL,
	ECFrom date NULL,
	ECTo date NULL,
	SponsoredBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Completed bit NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Response nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ResponseDetails nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Grade nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Points int NULL,
	TrainingPoint nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Approved bit DEFAULT 1 NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Comment nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Category nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RecommendedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0030 PRIMARY KEY (EmpCoursesId)
);
