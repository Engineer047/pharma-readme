-- HRMIS.dbo.PAYADVICES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.PAYADVICES;

CREATE TABLE HRMIS.dbo.PAYADVICES (
	PayAdviceId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	PayAdvice nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount decimal(18,2) NULL,
	ParameterId int NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentURL nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Period int NULL,
	Posted bit NULL,
	CONSTRAINT PK_PAYADVICES PRIMARY KEY (PayAdviceId)
);
