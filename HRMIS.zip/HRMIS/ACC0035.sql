-- HRMIS.dbo.ACC0035 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0035;

CREATE TABLE HRMIS.dbo.ACC0035 (
	InstitutionId int IDENTITY(1,1) NOT NULL,
	Institution nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhysicalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cellphone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContactPerson nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0035 PRIMARY KEY (InstitutionId)
);
