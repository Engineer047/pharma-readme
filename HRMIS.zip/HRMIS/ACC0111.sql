-- HRMIS.dbo.ACC0111 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0111;

CREATE TABLE HRMIS.dbo.ACC0111 (
	DocumentId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Url nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DatePosted date NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	PostedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0111 PRIMARY KEY (DocumentId)
);
