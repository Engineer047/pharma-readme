-- HRMIS.dbo.EmpPensionSchemes definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EmpPensionSchemes;

CREATE TABLE HRMIS.dbo.EmpPensionSchemes (
	EmpSchemeId int IDENTITY(1,1) NOT NULL,
	PensionId int NULL,
	EmpId int NULL,
	CONSTRAINT PK_EmpPensionSchemes PRIMARY KEY (EmpSchemeId)
);
