-- HRMIS.dbo.CASUALS_DATA definition

-- Drop table

-- DROP TABLE HRMIS.dbo.CASUALS_DATA;

CREATE TABLE HRMIS.dbo.CASUALS_DATA (
	CasualEmpId bigint IDENTITY(1,1) NOT NULL,
	CasualEmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IdNumber int NULL,
	FirstName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MiddleName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LastName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name AS (((([FirstName]+N' ')+[MiddleName])+N' ')+[LastName]),
	JobTitle nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitleId int NULL,
	ProjectId int NULL,
	NHIFNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NSSFNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PinNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cellphone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Active bit DEFAULT 1 NULL,
	PassportPhotoUrl nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT N'~/PassportPhotos/PassportIcon.jpg' NULL,
	[Search] AS ((((((CONVERT([nvarchar](50),[IDnumber],(0))+N'')+[FirstName])+N'')+[Middlename])+N'')+[LastName]),
	EnablePaye bit DEFAULT 1 NULL,
	EnableNHIF bit DEFAULT 1 NULL,
	EnablePayee bit DEFAULT 0 NULL,
	SHIFTID int DEFAULT 1 NULL,
	CategoryId int NULL,
	BankId int NULL,
	BankBranchId int NULL,
	BankAccountNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankAccountName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Relief decimal(18,2) DEFAULT 2400 NULL,
	NSSF decimal(18,2) DEFAULT 0 NULL,
	PayFrequencyId int DEFAULT 1 NULL,
	PaymentModeId int DEFAULT 1 NULL,
	CurrencyId int DEFAULT 1 NULL,
	BasicPay decimal(18,2) NULL,
	CONSTRAINT PK_CASUALS_DATA PRIMARY KEY (CasualEmpId)
);
