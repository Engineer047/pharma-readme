-- HRMIS.dbo.TBKEY definition

-- Drop table

-- DROP TABLE HRMIS.dbo.TBKEY;

CREATE TABLE HRMIS.dbo.TBKEY (
	PreName varchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ONEKEY int NULL
);
