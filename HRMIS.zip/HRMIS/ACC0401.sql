-- HRMIS.dbo.ACC0401 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0401;

CREATE TABLE HRMIS.dbo.ACC0401 (
	NssfId int IDENTITY(1,1) NOT NULL,
	YEARID int NULL,
	MONTHID int NULL,
	MMONTH nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EMPID int NULL,
	NAME nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EEarnings decimal(18,2) DEFAULT 0 NULL,
	PEarnings decimal(18,2) DEFAULT 0 NULL,
	Tier1Earnings decimal(18,2) DEFAULT 0 NULL,
	Tier2Earnings decimal(18,2) DEFAULT 0 NULL,
	Voluntary decimal(18,2) DEFAULT 0 NULL,
	Total decimal(18,2) DEFAULT 0 NULL,
	Tier1Amount decimal(18,2) NULL,
	Tier2Amount decimal(18,2) NULL,
	Tier1Rate decimal(18,2) NULL,
	Tier2Rate decimal(18,2) NULL,
	IDNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NSSFNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PinNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0401 PRIMARY KEY (NssfId)
);
