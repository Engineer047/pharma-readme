-- HRMIS.dbo.ACC0067 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0067;

CREATE TABLE HRMIS.dbo.ACC0067 (
	AppraisalScheduleId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ASFrom date NULL,
	ASTo date NULL,
	Period nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0067 PRIMARY KEY (AppraisalScheduleId)
);
