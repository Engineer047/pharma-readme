-- HRMIS.dbo.ACC0139 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0139;

CREATE TABLE HRMIS.dbo.ACC0139 (
	CategoryId int IDENTITY(1,1) NOT NULL,
	Category nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CompetencyId int NULL,
	Description int NULL,
	CONSTRAINT PK_ACC0139 PRIMARY KEY (CategoryId)
);
