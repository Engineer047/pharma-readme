-- HRMIS.dbo.ACC0091 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0091;

CREATE TABLE HRMIS.dbo.ACC0091 (
	ReliefId int IDENTITY(1,1) NOT NULL,
	Relief nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	CustomParameterType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	MonthId int NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MaxAmount decimal(18,2) NULL,
	CONSTRAINT PK_ACC0091 PRIMARY KEY (ReliefId)
);
