-- HRMIS.dbo.PETTY_CASH definition

-- Drop table

-- DROP TABLE HRMIS.dbo.PETTY_CASH;

CREATE TABLE HRMIS.dbo.PETTY_CASH (
	PettyCashId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount float NULL,
	YearId int NULL,
	CurrencyId int NULL,
	ApproavedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Locked bit DEFAULT 0 NULL,
	[Date] date DEFAULT getdate() NULL,
	Purpose nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cancelled bit DEFAULT 0 NULL,
	MonthId int NULL,
	Posted bit NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '100001' NULL,
	Processing bit NULL,
	Approaved bit NULL,
	DateApproaved date NULL,
	ApproaveComment nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RejectComment nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateCancelled date NULL,
	ManagerApproved bit DEFAULT 0 NULL,
	ManagerApprovedDate date NULL,
	ManagerComments nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerEmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerEmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentURL nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_PETTY_CASH PRIMARY KEY (PettyCashId)
);
