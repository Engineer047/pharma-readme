-- HRMIS.dbo.ACC0053 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0053;

CREATE TABLE HRMIS.dbo.ACC0053 (
	ShiftId int IDENTITY(1,1) NOT NULL,
	Shift nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	TimeOfDay nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SFrom time NULL,
	STo time NULL,
	SLFrom time NULL,
	SLTo time NULL,
	TotalHours float NULL,
	NPay float NULL,
	PCost float NULL,
	OPay float NULL,
	FixedPay float NULL,
	SPenalty float NULL,
	Penalise bit NULL,
	Overtime bit NULL,
	MOvertime float NULL,
	Monday bit NULL,
	Tuesday bit NULL,
	Wednesday bit NULL,
	Thursday bit NULL,
	Friday bit NULL,
	Saturday bit NULL,
	Sunday bit NULL,
	IsOptional bit NULL,
	IsCashual bit NULL,
	HasBreak bit NULL,
	MustFillAllTimes bit NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsCasual bit NULL,
	CONSTRAINT PK_ACC0053 PRIMARY KEY (ShiftId)
);
