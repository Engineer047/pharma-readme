-- HRMIS.dbo.ReportItem definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ReportItem;

CREATE TABLE HRMIS.dbo.ReportItem (
	RIID int IDENTITY(1,1) NOT NULL,
	RIIndex int NULL,
	ShowIt smallint NULL,
	RIName varchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UnitName varchar(6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Formula image NOT NULL,
	CalcBySchClass smallint NULL,
	StatisticMethod smallint NULL,
	CalcLast smallint NULL,
	Notes image NULL,
	CONSTRAINT PK__ReportIt__464E992E00EF6E70 PRIMARY KEY (RIID)
);
