-- HRMIS.dbo.aspnet_Profile definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_Profile;

CREATE TABLE HRMIS.dbo.aspnet_Profile (
	UserId uniqueidentifier NOT NULL,
	PropertyNames ntext COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	PropertyValuesString ntext COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	PropertyValuesBinary image NOT NULL,
	LastUpdatedDate datetime NOT NULL,
	CONSTRAINT PK__aspnet_P__1788CC4CE86DFF79 PRIMARY KEY (UserId),
	CONSTRAINT FK__aspnet_Pr__UserI__5654B625 FOREIGN KEY (UserId) REFERENCES HRMIS.dbo.aspnet_Users(UserId)
);
