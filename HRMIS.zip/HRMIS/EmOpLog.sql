-- HRMIS.dbo.EmOpLog definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EmOpLog;

CREATE TABLE HRMIS.dbo.EmOpLog (
	ID int IDENTITY(1,1) NOT NULL,
	USERID int NOT NULL,
	OperateTime datetime NOT NULL,
	manipulationID int NULL,
	Params1 int NULL,
	Params2 int NULL,
	Params3 int NULL,
	Params4 int NULL,
	SensorId varchar(5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
