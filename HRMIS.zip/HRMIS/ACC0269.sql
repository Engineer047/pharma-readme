-- HRMIS.dbo.ACC0269 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0269;

CREATE TABLE HRMIS.dbo.ACC0269 (
	AbsentUploadsId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	Amount decimal(18,2) NULL,
	DaysWorked decimal(18,2) NULL,
	MonthDays int NULL,
	AbsentPay decimal(18,2) NULL,
	Confirmed bit DEFAULT 0 NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0269 PRIMARY KEY (AbsentUploadsId)
);
