-- HRMIS.dbo.ACC0396 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0396;

CREATE TABLE HRMIS.dbo.ACC0396 (
	IncidentActionId int IDENTITY(1,1) NOT NULL,
	IncidentAction nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0396 PRIMARY KEY (IncidentActionId)
);
