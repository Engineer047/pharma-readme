-- HRMIS.dbo.PAYROLL_MONTHS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.PAYROLL_MONTHS;

CREATE TABLE HRMIS.dbo.PAYROLL_MONTHS (
	PayrollMonthId int IDENTITY(1,1) NOT NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	StartDate date NULL,
	EndDate date NULL,
	Days AS (datediff(day,[StartDate],[EndDate])+(1)),
	Active bit NULL
);
