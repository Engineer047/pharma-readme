-- HRMIS.dbo.ACC0070 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0070;

CREATE TABLE HRMIS.dbo.ACC0070 (
	RatingCategoryId int IDENTITY(1,1) NOT NULL,
	RatingCategory nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Rate decimal(18,2) NULL,
	CONSTRAINT PK_ACC0070 PRIMARY KEY (RatingCategoryId)
);
