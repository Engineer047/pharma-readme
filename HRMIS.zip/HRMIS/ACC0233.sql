-- HRMIS.dbo.ACC0233 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0233;

CREATE TABLE HRMIS.dbo.ACC0233 (
	FluencyId int IDENTITY(1,1) NOT NULL,
	Fluency nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0233 PRIMARY KEY (FluencyId)
);
