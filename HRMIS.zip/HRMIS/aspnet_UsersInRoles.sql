-- HRMIS.dbo.aspnet_UsersInRoles definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_UsersInRoles;

CREATE TABLE HRMIS.dbo.aspnet_UsersInRoles (
	UserId uniqueidentifier NOT NULL,
	RoleId uniqueidentifier NOT NULL,
	CONSTRAINT PK__aspnet_U__AF2760AD965E2BD1 PRIMARY KEY (UserId,RoleId),
	CONSTRAINT FK__aspnet_Us__RoleI__593122D0 FOREIGN KEY (RoleId) REFERENCES HRMIS.dbo.aspnet_Roles(RoleId),
	CONSTRAINT FK__aspnet_Us__UserI__5A254709 FOREIGN KEY (UserId) REFERENCES HRMIS.dbo.aspnet_Users(UserId)
);
 CREATE NONCLUSTERED INDEX aspnet_UsersInRoles_index ON HRMIS.dbo.aspnet_UsersInRoles (  RoleId ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
