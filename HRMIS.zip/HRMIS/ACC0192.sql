-- HRMIS.dbo.ACC0192 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0192;

CREATE TABLE HRMIS.dbo.ACC0192 (
	AspirationsId int IDENTITY(1,1) NOT NULL,
	Appraisalid int NOT NULL,
	EmpId int NOT NULL,
	Aspiration nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0192 PRIMARY KEY (AspirationsId,Appraisalid,EmpId),
	CONSTRAINT FK_ACC0192_ACC0188 FOREIGN KEY (Appraisalid,EmpId) REFERENCES HRMIS.dbo.ACC0188(AppraisalId,EmpId)
);
