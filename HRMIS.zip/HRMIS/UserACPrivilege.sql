-- HRMIS.dbo.UserACPrivilege definition

-- Drop table

-- DROP TABLE HRMIS.dbo.UserACPrivilege;

CREATE TABLE HRMIS.dbo.UserACPrivilege (
	UserID int NOT NULL,
	DeviceID int NOT NULL,
	ACGroupID int NULL,
	IsUseGroup bit NULL,
	TimeZone1 int NULL,
	TimeZone2 int NULL,
	TimeZone3 int NULL,
	verifystyle int NULL,
	CONSTRAINT pk_privilege PRIMARY KEY (UserID,DeviceID)
);
