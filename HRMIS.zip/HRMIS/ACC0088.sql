-- HRMIS.dbo.ACC0088 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0088;

CREATE TABLE HRMIS.dbo.ACC0088 (
	SaccoId int IDENTITY(1,1) NOT NULL,
	Sacco nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	YearId int NULL,
	MonthId int NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0088 PRIMARY KEY (SaccoId)
);
