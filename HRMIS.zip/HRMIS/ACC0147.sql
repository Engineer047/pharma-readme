-- HRMIS.dbo.ACC0147 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0147;

CREATE TABLE HRMIS.dbo.ACC0147 (
	EmpManagerId int IDENTITY(1,1) NOT NULL,
	MNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MId int NULL,
	MName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerId int NULL,
	CONSTRAINT PK_ACC0147 PRIMARY KEY (EmpManagerId)
);
