-- HRMIS.dbo.ACC0051 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0051;

CREATE TABLE HRMIS.dbo.ACC0051 (
	EmpLoanId int IDENTITY(1,1) NOT NULL,
	LoanTypeId int NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AmountApplied decimal(18,2) NULL,
	AmountApproaved decimal(18,2) NULL,
	RepaymentPeriod int NULL,
	Installements int NULL,
	MonthlyDeduction decimal(18,2) NULL,
	AmountDeducted AS ([dbo].[fReturnLoanDeduction]([EmpLoanId])),
	BalanceRemaining AS ([AmountApplied]-[dbo].[fReturnLoanDeduction]([EmpLoanId])),
	InterestRate float NULL,
	Locked bit DEFAULT 0 NULL,
	ApproavedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Posted bit DEFAULT 0 NULL,
	Issued float NULL,
	AdditionalRefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cancelled bit DEFAULT 0 NULL,
	Active bit NULL,
	Approved bit NULL,
	DateApplied datetime NULL,
	DateApproved datetime NULL,
	DateCancelled datetime NULL,
	AdditionalLoan float NULL,
	AmountPaid decimal(18,2) NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '100002' NULL,
	InterestCharged decimal(18,2) NULL,
	Processing bit NULL,
	ApprovalComment nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RejectComment nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerEmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerEmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AssManagerEmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AssManagerEmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LoanType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsCompanyLoan bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0051 PRIMARY KEY (EmpLoanId)
);
