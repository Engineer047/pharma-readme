-- HRMIS.dbo.ACC0238 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0238;

CREATE TABLE HRMIS.dbo.ACC0238 (
	TermsOfServiceId int IDENTITY(1,1) NOT NULL,
	TermsOfService nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0238 PRIMARY KEY (TermsOfServiceId)
);
