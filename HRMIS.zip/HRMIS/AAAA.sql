-- HRMIS.dbo.AAAA definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AAAA;

CREATE TABLE HRMIS.dbo.AAAA (
	empno int NULL,
	name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	id nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	department nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	employmentstatus nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	employmenttype nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	jobgroup nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	jobtitle nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	shiftid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	o nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	p nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	departmentid int NULL,
	employmentstatusid int NULL,
	employmenttypeid int NULL,
	jobgroupid int NULL,
	jobtitleid int NULL
);
