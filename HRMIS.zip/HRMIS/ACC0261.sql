-- HRMIS.dbo.ACC0261 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0261;

CREATE TABLE HRMIS.dbo.ACC0261 (
	DutyId int IDENTITY(1,1) NOT NULL,
	DutyCategoryId int NULL,
	Duty nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0261 PRIMARY KEY (DutyId)
);
