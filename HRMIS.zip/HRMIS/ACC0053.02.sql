-- HRMIS.dbo.[ACC0053.02] definition

-- Drop table

-- DROP TABLE HRMIS.dbo.[ACC0053.02];

CREATE TABLE HRMIS.dbo.[ACC0053.02] (
	RateId int IDENTITY(1,1) NOT NULL,
	Rate decimal(18,2) NULL,
	CONSTRAINT [PK_ACC0053.02] PRIMARY KEY (RateId)
);
