-- HRMIS.dbo.ACC0136 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0136;

CREATE TABLE HRMIS.dbo.ACC0136 (
	SubGoalId int IDENTITY(1,1) NOT NULL,
	Subgoal nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PercentComplete decimal(18,2) NULL,
	GoalId int NULL,
	SystemDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0136 PRIMARY KEY (SubGoalId),
	CONSTRAINT FK_ACC0136_ACC0137 FOREIGN KEY (GoalId) REFERENCES HRMIS.dbo.ACC0137(GoalId)
);
