-- HRMIS.dbo.ACC0162 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0162;

CREATE TABLE HRMIS.dbo.ACC0162 (
	FamilyInfoId int IDENTITY(1,1) NOT NULL,
	ClaimsId int NOT NULL,
	EmpId int NOT NULL,
	IsSpouseEmployed bit DEFAULT 0 NULL,
	SpouseName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SpouseDateOfBirth date NULL,
	SpouseEmployer nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsPatientInsured bit DEFAULT 0 NULL,
	EffectiveCoverageDate date NULL,
	PolicyNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TypeOfPlanId int NULL,
	CONSTRAINT PK_ACC0162_1 PRIMARY KEY (FamilyInfoId,ClaimsId,EmpId),
	CONSTRAINT FK_ACC0162_ACC0154 FOREIGN KEY (ClaimsId,EmpId) REFERENCES HRMIS.dbo.ACC0154(ClaimsId,EmpId),
	CONSTRAINT FK_ACC0162_ACC0163 FOREIGN KEY (TypeOfPlanId) REFERENCES HRMIS.dbo.ACC0163(TypeOfPlanId),
	CONSTRAINT FK_ACC0162_ACC0165 FOREIGN KEY (TypeOfPlanId) REFERENCES HRMIS.dbo.ACC0165(TypeOfPlanId)
);
