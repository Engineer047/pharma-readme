-- HRMIS.dbo.ACC0287 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0287;

CREATE TABLE HRMIS.dbo.ACC0287 (
	DestinationId int IDENTITY(1,1) NOT NULL,
	Destination nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DestinationCategoryId int NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0287 PRIMARY KEY (DestinationId)
);
