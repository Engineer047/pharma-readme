-- HRMIS.dbo.ACC0190 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0190;

CREATE TABLE HRMIS.dbo.ACC0190 (
	ChallengeId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NOT NULL,
	EmpId int NOT NULL,
	Challenge nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0190 PRIMARY KEY (ChallengeId,AppraisalId,EmpId),
	CONSTRAINT FK_ACC0190_ACC0188 FOREIGN KEY (AppraisalId,EmpId) REFERENCES HRMIS.dbo.ACC0188(AppraisalId,EmpId)
);
