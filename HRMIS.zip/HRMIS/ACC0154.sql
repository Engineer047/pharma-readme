-- HRMIS.dbo.ACC0154 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0154;

CREATE TABLE HRMIS.dbo.ACC0154 (
	ClaimsId int IDENTITY(1,1) NOT NULL,
	EmpId int NOT NULL,
	ClaimsCategoryId int NULL,
	ServiceProviderId int NULL,
	[Date] date NULL,
	CurrencyId int NULL,
	Amount int NULL,
	PostedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsProcessing bit DEFAULT 0 NULL,
	IsApproved bit DEFAULT 0 NULL,
	DateApproved date NULL,
	ApprovedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsCancelled bit DEFAULT 0 NULL,
	RejectComment nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateCancelled date NULL,
	Locked bit DEFAULT 0 NULL,
	AmountApproved decimal(18,2) NULL,
	Comment decimal(18,2) NULL,
	CONSTRAINT PK_ACC0154_1 PRIMARY KEY (ClaimsId,EmpId),
	CONSTRAINT FK_ACC0154_ACC0156 FOREIGN KEY (ServiceProviderId) REFERENCES HRMIS.dbo.ACC0156(ServiceProviderId),
	CONSTRAINT FK_ACC0154_ClaimsCategory FOREIGN KEY (ClaimsCategoryId) REFERENCES HRMIS.dbo.ACC0164(ClaimsCategoryId)
);
