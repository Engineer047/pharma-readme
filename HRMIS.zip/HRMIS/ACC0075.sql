-- HRMIS.dbo.ACC0075 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0075;

CREATE TABLE HRMIS.dbo.ACC0075 (
	AdvanceApplicationId int IDENTITY(1,1) NOT NULL,
	Amount float NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Status nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Completed bit NULL,
	Processing bit NULL,
	Declined bit NULL,
	AdvanceId int NULL,
	BasicPay200pc decimal(18,2) NULL,
	GrossPay33pc decimal(18,2) NULL,
	InterestRate decimal(18,2) NULL,
	AmountRepayable decimal(18,2) NULL,
	Comment nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0075 PRIMARY KEY (AdvanceApplicationId)
);
