-- HRMIS.dbo.aspnet_Membership definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_Membership;

CREATE TABLE HRMIS.dbo.aspnet_Membership (
	ApplicationId uniqueidentifier NOT NULL,
	UserId uniqueidentifier NOT NULL,
	Password nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	PasswordFormat int DEFAULT 0 NOT NULL,
	PasswordSalt nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	MobilePIN nvarchar(16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LoweredEmail nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PasswordQuestion nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PasswordAnswer nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsApproved bit NOT NULL,
	IsLockedOut bit NOT NULL,
	CreateDate datetime NOT NULL,
	LastLoginDate datetime NOT NULL,
	LastPasswordChangedDate datetime NOT NULL,
	LastLockoutDate datetime NOT NULL,
	FailedPasswordAttemptCount int NOT NULL,
	FailedPasswordAttemptWindowStart datetime NOT NULL,
	FailedPasswordAnswerAttemptCount int NOT NULL,
	FailedPasswordAnswerAttemptWindowStart datetime NOT NULL,
	Comment ntext COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__aspnet_M__1788CC4DC945561C PRIMARY KEY (UserId),
	CONSTRAINT FK__aspnet_Me__Appli__509BDCCF FOREIGN KEY (ApplicationId) REFERENCES HRMIS.dbo.aspnet_Applications(ApplicationId),
	CONSTRAINT FK__aspnet_Me__UserI__51900108 FOREIGN KEY (UserId) REFERENCES HRMIS.dbo.aspnet_Users(UserId)
);
 CREATE CLUSTERED INDEX aspnet_Membership_index ON HRMIS.dbo.aspnet_Membership (  ApplicationId ASC  , LoweredEmail ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
