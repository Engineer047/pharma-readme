-- HRMIS.dbo.ACC0046 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0046;

CREATE TABLE HRMIS.dbo.ACC0046 (
	ParameterCategoryId int IDENTITY(1,1) NOT NULL,
	Category nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NetEffect nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0046 PRIMARY KEY (ParameterCategoryId)
);
