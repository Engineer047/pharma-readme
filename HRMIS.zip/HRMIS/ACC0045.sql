-- HRMIS.dbo.ACC0045 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0045;

CREATE TABLE HRMIS.dbo.ACC0045 (
	EmpIndiscpline int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DisciplinaryAction nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0045 PRIMARY KEY (EmpIndiscpline)
);
