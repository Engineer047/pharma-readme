-- HRMIS.dbo.ACC0263 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0263;

CREATE TABLE HRMIS.dbo.ACC0263 (
	JobDescriptionQualificationsId int IDENTITY(1,1) NOT NULL,
	JobDescriptionId int NULL,
	JobTitleId int NULL,
	Qualification nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0263 PRIMARY KEY (JobDescriptionQualificationsId)
);
