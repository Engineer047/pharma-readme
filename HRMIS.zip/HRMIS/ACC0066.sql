-- HRMIS.dbo.ACC0066 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0066;

CREATE TABLE HRMIS.dbo.ACC0066 (
	HRScheduleATTId int IDENTITY(1,1) NOT NULL,
	HRScheduleId int NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0066 PRIMARY KEY (HRScheduleATTId)
);
