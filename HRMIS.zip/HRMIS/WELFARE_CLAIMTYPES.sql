-- HRMIS.dbo.WELFARE_CLAIMTYPES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.WELFARE_CLAIMTYPES;

CREATE TABLE HRMIS.dbo.WELFARE_CLAIMTYPES (
	WelfareClaimTypeId int IDENTITY(1,1) NOT NULL,
	WelfareClaimType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_WELFARE_CLAIMTYPES PRIMARY KEY (WelfareClaimTypeId)
);
