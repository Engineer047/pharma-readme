-- HRMIS.dbo.ACC0293 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0293;

CREATE TABLE HRMIS.dbo.ACC0293 (
	DestinationCategoryId int IDENTITY(1,1) NOT NULL,
	DestinationCategory nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0293 PRIMARY KEY (DestinationCategoryId)
);
