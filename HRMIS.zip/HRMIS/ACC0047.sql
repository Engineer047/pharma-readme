-- HRMIS.dbo.ACC0047 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0047;

CREATE TABLE HRMIS.dbo.ACC0047 (
	ParameterId int IDENTITY(1,1) NOT NULL,
	ParameterCategoryId int NULL,
	[Parameter] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Value float NULL,
	Rate float NULL,
	UseRate bit NULL,
	Recurring bigint NULL,
	Taxable bit NULL,
	CONSTRAINT PK_ACC0047 PRIMARY KEY (ParameterId)
);
