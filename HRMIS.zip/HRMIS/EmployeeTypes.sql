-- HRMIS.dbo.EmployeeTypes definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EmployeeTypes;

CREATE TABLE HRMIS.dbo.EmployeeTypes (
	EmployeeTypeId int IDENTITY(1,1) NOT NULL,
	EmployeeType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_EmployeeTypes PRIMARY KEY (EmployeeTypeId)
);
