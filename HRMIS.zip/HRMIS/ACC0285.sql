-- HRMIS.dbo.ACC0285 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0285;

CREATE TABLE HRMIS.dbo.ACC0285 (
	MonthLeaveStatement int IDENTITY(1,1) NOT NULL,
	YearId int NULL,
	MonthId int NULL,
	EmpLeaveId int NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LeaveTypeId int NULL,
	DefaultEntitlement decimal(18,2) NULL,
	Paid bit NULL,
	PayRate decimal(18,2) NULL,
	IsRecurring bit NULL,
	LeaveStartDate date DEFAULT getdate() NULL,
	Balance decimal(18,0) NULL,
	OpeningBalance decimal(18,2) DEFAULT 0 NULL,
	EarnedLeave decimal(18,0) NULL,
	DateToday datetime NOT NULL,
	DaysTaken decimal(18,0) NULL,
	LeaveType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0285 PRIMARY KEY (MonthLeaveStatement)
);
