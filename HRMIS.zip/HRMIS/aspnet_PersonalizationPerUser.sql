-- HRMIS.dbo.aspnet_PersonalizationPerUser definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_PersonalizationPerUser;

CREATE TABLE HRMIS.dbo.aspnet_PersonalizationPerUser (
	Id uniqueidentifier DEFAULT newid() NOT NULL,
	PathId uniqueidentifier NULL,
	UserId uniqueidentifier NULL,
	PageSettings image NOT NULL,
	LastUpdatedDate datetime NOT NULL,
	CONSTRAINT PK__aspnet_P__3214EC06580F7EF7 PRIMARY KEY (Id),
	CONSTRAINT FK__aspnet_Pe__PathI__546C6DB3 FOREIGN KEY (PathId) REFERENCES HRMIS.dbo.aspnet_Paths(PathId),
	CONSTRAINT FK__aspnet_Pe__UserI__556091EC FOREIGN KEY (UserId) REFERENCES HRMIS.dbo.aspnet_Users(UserId)
);
 CREATE UNIQUE CLUSTERED INDEX aspnet_PersonalizationPerUser_index1 ON HRMIS.dbo.aspnet_PersonalizationPerUser (  PathId ASC  , UserId ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE UNIQUE NONCLUSTERED INDEX aspnet_PersonalizationPerUser_ncindex2 ON HRMIS.dbo.aspnet_PersonalizationPerUser (  UserId ASC  , PathId ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
