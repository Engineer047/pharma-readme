-- HRMIS.dbo.OVERTIME_PAY definition

-- Drop table

-- DROP TABLE HRMIS.dbo.OVERTIME_PAY;

CREATE TABLE HRMIS.dbo.OVERTIME_PAY (
	OvertimeHrsId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Hours decimal(18,2) NULL,
	MonthDays int NULL,
	OvertimePay decimal(18,2) NULL,
	OvertimeId int NULL,
	Rate decimal(18,2) NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_OVERTIME_PAY PRIMARY KEY (OvertimeHrsId)
);
