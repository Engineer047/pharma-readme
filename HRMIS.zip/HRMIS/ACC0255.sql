-- HRMIS.dbo.ACC0255 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0255;

CREATE TABLE HRMIS.dbo.ACC0255 (
	EmployeeTestId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	TestId int NULL,
	TestScore decimal(18,0) NULL,
	TestDate date NULL,
	Recommendation nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0255 PRIMARY KEY (EmployeeTestId)
);
