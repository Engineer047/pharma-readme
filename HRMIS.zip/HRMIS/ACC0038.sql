-- HRMIS.dbo.ACC0038 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0038;

CREATE TABLE HRMIS.dbo.ACC0038 (
	EmployeeExperienceId int IDENTITY(1,1) NOT NULL,
	OrganizationId int NULL,
	EEFrom nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EETo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReasonForLeaving nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitle nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0039 PRIMARY KEY (EmployeeExperienceId)
);
