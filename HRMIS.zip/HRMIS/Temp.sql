-- HRMIS.dbo.Temp definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Temp;

CREATE TABLE HRMIS.dbo.Temp (
	UploadId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	Amount decimal(18,2) NULL,
	Confirmed bit NULL,
	CONSTRAINT PK_Temp PRIMARY KEY (UploadId)
);
