-- HRMIS.dbo.AlarmLog definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AlarmLog;

CREATE TABLE HRMIS.dbo.AlarmLog (
	ID int IDENTITY(1,1) NOT NULL,
	Operator varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EnrollNumber varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LogTime datetime DEFAULT getdate() NULL,
	MachineAlias varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AlarmType int NULL,
	CONSTRAINT PK__AlarmLog__3214EC279266D40D PRIMARY KEY (ID)
);
