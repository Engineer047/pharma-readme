-- HRMIS.dbo.EMPTARGETS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EMPTARGETS;

CREATE TABLE HRMIS.dbo.EMPTARGETS (
	EmpTargetId int IDENTITY(1,1) NOT NULL,
	SystemLog AS (getdate()) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitleId int NULL,
	KpaId int NULL,
	KPIID int NULL,
	TargetId int NULL,
	StartDate date NULL,
	DueDate date NULL,
	SelfAppraisalDate date NULL,
	AppraisalDate date NULL,
	PercentComplete decimal(18,2) NULL,
	StatusId int NULL,
	Target nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Weight decimal(18,2) NULL,
	MaxScore int NULL,
	EmpRatingId int NULL,
	ManRatingId int NULL,
	ManComments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpComments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpScores int NULL,
	ManScores int NULL,
	Appraiser nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Comments nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerAppraised bit DEFAULT 0 NULL,
	SelfAppraised bit DEFAULT 0 NULL,
	LineScore decimal(18,2) NULL,
	TotalScorePerKPI decimal(18,2) NULL,
	TotalScorePerKPA decimal(18,2) NULL,
	CONSTRAINT PK_EMPTARGETS PRIMARY KEY (EmpTargetId)
);
