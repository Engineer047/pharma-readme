-- HRMIS.dbo.ACC0173 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0173;

CREATE TABLE HRMIS.dbo.ACC0173 (
	ClaimsApplicationId int IDENTITY(1,1) NOT NULL,
	ClaimsId int NOT NULL,
	EmpId int NOT NULL,
	Amount float NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	Status nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Completed bit NULL,
	Processing bit NULL,
	Declined bit NULL,
	CONSTRAINT PK_ACC0173 PRIMARY KEY (ClaimsApplicationId,ClaimsId,EmpId),
	CONSTRAINT FK_ACC0173_ACC0154 FOREIGN KEY (ClaimsId,EmpId) REFERENCES HRMIS.dbo.ACC0154(ClaimsId,EmpId)
);
