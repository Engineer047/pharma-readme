-- HRMIS.dbo.ACC0026 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0026;

CREATE TABLE HRMIS.dbo.ACC0026 (
	MaritalStatusId int IDENTITY(1,1) NOT NULL,
	MaritalStatus nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_AC0012 PRIMARY KEY (MaritalStatusId)
);
