-- HRMIS.dbo.ACC0265 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0265;

CREATE TABLE HRMIS.dbo.ACC0265 (
	JobDescriptionEXId int IDENTITY(1,1) NOT NULL,
	JobDescriptionId int NULL,
	JobTitleId int NULL,
	Experience nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0265 PRIMARY KEY (JobDescriptionEXId)
);
