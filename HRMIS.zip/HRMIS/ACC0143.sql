-- HRMIS.dbo.ACC0143 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0143;

CREATE TABLE HRMIS.dbo.ACC0143 (
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpScores decimal(18,2) NULL,
	ManagerScores decimal(18,2) NULL,
	FormName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ScoresId int IDENTITY(1,1) NOT NULL,
	FormId int NULL,
	OverallEmpScores decimal(18,2) NULL,
	OverallManagerScores decimal(18,2) NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0143 PRIMARY KEY (ScoresId)
);
