-- HRMIS.dbo.ACC0087 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0087;

CREATE TABLE HRMIS.dbo.ACC0087 (
	CommissionId int IDENTITY(1,1) NOT NULL,
	Commission nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NOT NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0087 PRIMARY KEY (CommissionId)
);
