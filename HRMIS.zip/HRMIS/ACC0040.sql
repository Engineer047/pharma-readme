-- HRMIS.dbo.ACC0040 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0040;

CREATE TABLE HRMIS.dbo.ACC0040 (
	ReferreeId int IDENTITY(1,1) NOT NULL,
	Referree nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Organization nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitle nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Notes nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Profession nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellPhone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhysicalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	CONSTRAINT PK_ACC0040 PRIMARY KEY (ReferreeId)
);
