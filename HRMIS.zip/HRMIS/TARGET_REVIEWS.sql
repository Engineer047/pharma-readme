-- HRMIS.dbo.TARGET_REVIEWS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.TARGET_REVIEWS;

CREATE TABLE HRMIS.dbo.TARGET_REVIEWS (
	TargetReviewId int IDENTITY(1,1) NOT NULL,
	EmpTargetId int NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerComments nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReviewDate date NULL,
	[Action] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReviewedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_TARGET_REVIEWS PRIMARY KEY (TargetReviewId)
);
