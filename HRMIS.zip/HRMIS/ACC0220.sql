-- HRMIS.dbo.ACC0220 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0220;

CREATE TABLE HRMIS.dbo.ACC0220 (
	SuccessionTypeId int IDENTITY(1,1) NOT NULL,
	SuccessionType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0220 PRIMARY KEY (SuccessionTypeId)
);
