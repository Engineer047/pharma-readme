-- HRMIS.dbo.ACC0243 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0243;

CREATE TABLE HRMIS.dbo.ACC0243 (
	ConfirmationStatusId int IDENTITY(1,1) NOT NULL,
	ConfirmationStatus nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0243 PRIMARY KEY (ConfirmationStatusId)
);
