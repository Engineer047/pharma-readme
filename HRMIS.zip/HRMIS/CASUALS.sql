-- HRMIS.dbo.CASUALS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.CASUALS;

CREATE TABLE HRMIS.dbo.CASUALS (
	CasualId bigint IDENTITY(1,1) NOT NULL,
	CasualEmpId int NULL,
	FirstName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MiddleName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LastName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IdNumber int NULL,
	NSSFNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NHIFNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PinNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DaysWorked decimal(18,2) NULL,
	Week int NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	TypeOfWork nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ProjectId int NULL,
	ProjectCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Meters nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cellphone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DailyWage decimal(18,2) NULL,
	Closed bit DEFAULT 0 NULL,
	ManagerEmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Username nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] datetime NULL,
	WeeklyWage decimal(18,2) NULL,
	CONSTRAINT PK_CASUALS PRIMARY KEY (CasualId)
);
