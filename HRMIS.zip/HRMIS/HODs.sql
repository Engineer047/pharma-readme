-- HRMIS.dbo.HODs definition

-- Drop table

-- DROP TABLE HRMIS.dbo.HODs;

CREATE TABLE HRMIS.dbo.HODs (
	HODId int IDENTITY(1,1) NOT NULL,
	MNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MId int NULL,
	MName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DepartmentId int NULL,
	CONSTRAINT PK_HODs PRIMARY KEY (HODId)
);
