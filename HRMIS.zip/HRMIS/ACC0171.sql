-- HRMIS.dbo.ACC0171 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0171;

CREATE TABLE HRMIS.dbo.ACC0171 (
	GenderId int IDENTITY(1,1) NOT NULL,
	Gender nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
