-- HRMIS.dbo.ACC0186 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0186;

CREATE TABLE HRMIS.dbo.ACC0186 (
	NotificationId int IDENTITY(1,1) NOT NULL,
	DateSent datetime NULL,
	SenderId int NULL,
	Sender nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SenderEmail nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RecipientId int NULL,
	Recipient nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RecipientEmail nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Subject nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Message nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0186 PRIMARY KEY (NotificationId)
);
