-- HRMIS.dbo.ACC0195 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0195;

CREATE TABLE HRMIS.dbo.ACC0195 (
	AppraisalRecommendationId int IDENTITY(1,1) NOT NULL,
	Recommendation nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0195 PRIMARY KEY (AppraisalRecommendationId)
);
