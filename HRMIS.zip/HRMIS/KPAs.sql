-- HRMIS.dbo.KPAs definition

-- Drop table

-- DROP TABLE HRMIS.dbo.KPAs;

CREATE TABLE HRMIS.dbo.KPAs (
	KPAID int IDENTITY(1,1) NOT NULL,
	KPA nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Percentage decimal(18,2) NULL,
	CONSTRAINT PK_KPAs PRIMARY KEY (KPAID)
);
