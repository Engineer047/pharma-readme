-- HRMIS.dbo.ACC0096 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0096;

CREATE TABLE HRMIS.dbo.ACC0096 (
	SaccoId int NOT NULL,
	CompanyId int NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Amount decimal(18,2) NULL,
	TotalAmount AS ([dbo].[GetSaccoTotalShares]([EmpId],[SaccoId])),
	OpeningBalance decimal(18,2) DEFAULT 0 NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpSaccoId int IDENTITY(1,1) NOT NULL,
	Sacco nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Rate float NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	IsTaxable bit NULL,
	Cancelled bit DEFAULT 0 NULL,
	Locked bit DEFAULT 0 NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0096 PRIMARY KEY (EmpSaccoId)
);
