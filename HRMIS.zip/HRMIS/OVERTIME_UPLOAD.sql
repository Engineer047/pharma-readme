-- HRMIS.dbo.OVERTIME_UPLOAD definition

-- Drop table

-- DROP TABLE HRMIS.dbo.OVERTIME_UPLOAD;

CREATE TABLE HRMIS.dbo.OVERTIME_UPLOAD (
	OvertimeUploadId int IDENTITY(1,1) NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	Hours decimal(18,2) NULL,
	MonthDays int NULL,
	OvertimePay decimal(18,2) NULL,
	OvertimeId int NULL,
	Rate decimal(18,2) NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Confirmed bit DEFAULT 0 NULL,
	CONSTRAINT PK_OVERTIME_UPLOAD PRIMARY KEY (OvertimeUploadId)
);
