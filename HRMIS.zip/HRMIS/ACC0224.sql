-- HRMIS.dbo.ACC0224 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0224;

CREATE TABLE HRMIS.dbo.ACC0224 (
	AttendanceStatusId int IDENTITY(1,1) NOT NULL,
	AttendanceStatus nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0224 PRIMARY KEY (AttendanceStatusId)
);
