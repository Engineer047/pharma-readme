-- HRMIS.dbo.ACC0095 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0095;

CREATE TABLE HRMIS.dbo.ACC0095 (
	CommissionId int NOT NULL,
	CompanyId int NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Amount float NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpCommissionId int IDENTITY(1,1) NOT NULL,
	Commission nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	Cancelled bit DEFAULT 0 NULL,
	Locked bit DEFAULT 0 NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0095 PRIMARY KEY (EmpCommissionId)
);
