-- HRMIS.dbo.ACC0009 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0009;

CREATE TABLE HRMIS.dbo.ACC0009 (
	EmploymentTypeId int IDENTITY(1,1) NOT NULL,
	EmploymentType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0009 PRIMARY KEY (EmploymentTypeId)
);
