-- HRMIS.dbo.SchClass definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SchClass;

CREATE TABLE HRMIS.dbo.SchClass (
	schClassid int IDENTITY(1,1) NOT NULL,
	schName varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	StartTime datetime NOT NULL,
	EndTime datetime NOT NULL,
	LateMinutes int NULL,
	EarlyMinutes int NULL,
	CheckIn int DEFAULT 1 NULL,
	CheckOut int DEFAULT 1 NULL,
	CheckInTime1 datetime NULL,
	CheckInTime2 datetime NULL,
	CheckOutTime1 datetime NULL,
	CheckOutTime2 datetime NULL,
	Color int DEFAULT 16715535 NULL,
	AutoBind smallint DEFAULT 1 NULL,
	WorkDay float DEFAULT 1 NULL,
	SensorID varchar(5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	WorkMins float DEFAULT 0 NULL,
	CONSTRAINT PK__SchClass__FFE76E832E90ABF4 PRIMARY KEY (schClassid)
);
