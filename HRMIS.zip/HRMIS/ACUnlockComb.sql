-- HRMIS.dbo.ACUnlockComb definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACUnlockComb;

CREATE TABLE HRMIS.dbo.ACUnlockComb (
	UnlockCombID smallint NOT NULL,
	Name varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Group01 smallint NULL,
	Group02 smallint NULL,
	Group03 smallint NULL,
	Group04 smallint NULL,
	Group05 smallint NULL,
	CONSTRAINT PK__ACUnlock__1F6C4570757678CA PRIMARY KEY (UnlockCombID)
);
