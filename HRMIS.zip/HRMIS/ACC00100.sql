-- HRMIS.dbo.ACC00100 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC00100;

CREATE TABLE HRMIS.dbo.ACC00100 (
	TransactionId bigint IDENTITY(1,1) NOT NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Username nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Computername nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TrxDate datetime DEFAULT getdate() NULL,
	[Domain] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Ipaddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0085 PRIMARY KEY (TransactionId)
);
