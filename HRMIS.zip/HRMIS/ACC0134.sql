-- HRMIS.dbo.ACC0134 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0134;

CREATE TABLE HRMIS.dbo.ACC0134 (
	CategoryId int IDENTITY(1,1) NOT NULL,
	Category nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SystemDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0134 PRIMARY KEY (CategoryId)
);
