-- HRMIS.dbo.Contracts definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Contracts;

CREATE TABLE HRMIS.dbo.Contracts (
	ContractId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmploymentTypeId int NULL,
	StartDate date NULL,
	EndDate date NULL,
	Duration AS (datediff(day,[StartDate],[EndDate])/(364)),
	Expired AS ([dbo].[fGetContractExpired]([ContractId])),
	Renewed bit DEFAULT 0 NULL,
	Terminated bit DEFAULT 0 NULL,
	MonthsToExpire AS ([dbo].[fGetMonthsToExpire]([EndDate])),
	Comments nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_Contracts PRIMARY KEY (ContractId)
);
