-- HRMIS.dbo.ACC0112 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0112;

CREATE TABLE HRMIS.dbo.ACC0112 (
	AnnouncementId int IDENTITY(1,1) NOT NULL,
	DatePosted date DEFAULT getdate() NULL,
	ExpiryDate date NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Title nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Active bit DEFAULT 1 NULL,
	CONSTRAINT PK_ACC0112 PRIMARY KEY (AnnouncementId)
);
