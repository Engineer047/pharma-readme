-- HRMIS.dbo.ACC0099 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0099;

CREATE TABLE HRMIS.dbo.ACC0099 (
	EmpReliefId int IDENTITY(1,1) NOT NULL,
	CompanyId int NULL,
	ReliefId int NOT NULL,
	Relief nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	CustomParameterType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	MonthId int NULL,
	Amount float NULL,
	Cancelled bit DEFAULT 0 NULL,
	Locked bit DEFAULT 0 NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT [PK_ACC0099.1] PRIMARY KEY (EmpReliefId)
);
