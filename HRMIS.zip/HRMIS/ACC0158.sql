-- HRMIS.dbo.ACC0158 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0158;

CREATE TABLE HRMIS.dbo.ACC0158 (
	RelationshipId int IDENTITY(1,1) NOT NULL,
	Relationship nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0158 PRIMARY KEY (RelationshipId)
);
