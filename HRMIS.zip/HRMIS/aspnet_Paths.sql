-- HRMIS.dbo.aspnet_Paths definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_Paths;

CREATE TABLE HRMIS.dbo.aspnet_Paths (
	ApplicationId uniqueidentifier NOT NULL,
	PathId uniqueidentifier DEFAULT newid() NOT NULL,
	[Path] nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	LoweredPath nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	CONSTRAINT PK__aspnet_P__CD67DC584BB2D686 PRIMARY KEY (PathId),
	CONSTRAINT FK__aspnet_Pa__Appli__52842541 FOREIGN KEY (ApplicationId) REFERENCES HRMIS.dbo.aspnet_Applications(ApplicationId)
);
 CREATE UNIQUE CLUSTERED INDEX aspnet_Paths_index ON HRMIS.dbo.aspnet_Paths (  ApplicationId ASC  , LoweredPath ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
