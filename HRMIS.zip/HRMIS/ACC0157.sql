-- HRMIS.dbo.ACC0157 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0157;

CREATE TABLE HRMIS.dbo.ACC0157 (
	PatientInfoId int IDENTITY(1,1) NOT NULL,
	ClaimsId int NOT NULL,
	EmpId int NOT NULL,
	PatientName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RelationshipId int NULL,
	PatientDateOfBirth date NULL,
	GenderId int NULL,
	CONSTRAINT PK_ACC0157 PRIMARY KEY (PatientInfoId,ClaimsId,EmpId),
	CONSTRAINT FK_ACC0157_ACC0154 FOREIGN KEY (ClaimsId,EmpId) REFERENCES HRMIS.dbo.ACC0154(ClaimsId,EmpId),
	CONSTRAINT FK_ACC0157_ACC0158 FOREIGN KEY (RelationshipId) REFERENCES HRMIS.dbo.ACC0158(RelationshipId)
);
