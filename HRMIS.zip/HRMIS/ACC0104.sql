-- HRMIS.dbo.ACC0104 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0104;

CREATE TABLE HRMIS.dbo.ACC0104 (
	SectionShiftId int IDENTITY(1,1) NOT NULL,
	CompanyId int NOT NULL,
	OfficeId int NOT NULL,
	DepartmentId int NOT NULL,
	DivisionId int NOT NULL,
	SectionId int NOT NULL,
	ShiftId int NOT NULL,
	DFrom datetime NULL,
	DTo datetime NULL,
	CONSTRAINT PK_ACC0104 PRIMARY KEY (SectionShiftId)
);
