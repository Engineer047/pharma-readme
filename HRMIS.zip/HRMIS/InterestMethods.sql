-- HRMIS.dbo.InterestMethods definition

-- Drop table

-- DROP TABLE HRMIS.dbo.InterestMethods;

CREATE TABLE HRMIS.dbo.InterestMethods (
	InterestMethodId int IDENTITY(1,1) NOT NULL,
	InterestMethod nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_InterestMethods PRIMARY KEY (InterestMethodId)
);
