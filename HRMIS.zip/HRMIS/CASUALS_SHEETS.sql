-- HRMIS.dbo.CASUALS_SHEETS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.CASUALS_SHEETS;

CREATE TABLE HRMIS.dbo.CASUALS_SHEETS (
	CasualUploadId bigint IDENTITY(1,1) NOT NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IdNumber int NULL,
	Week int NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	ProjectId int NULL,
	DailyWage decimal(18,2) NULL,
	DaysWorked decimal(18,2) NULL,
	Confirmed bit NULL,
	CONSTRAINT PK_CASUALS_SHEETS PRIMARY KEY (CasualUploadId)
);
