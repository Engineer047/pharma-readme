-- HRMIS.dbo.ACC0125 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0125;

CREATE TABLE HRMIS.dbo.ACC0125 (
	Id int IDENTITY(1,1) NOT NULL,
	OpeningLoanBal decimal(18,2) NULL,
	AdditionalLoan decimal(18,2) NULL,
	DateLoanAdvanced datetime NULL,
	InterestRate decimal(18,2) NULL,
	Balance decimal(18,2) NULL,
	TaxablefringeBenefit decimal(18,2) NULL,
	TaxPaid decimal(18,2) NULL,
	YearId int NULL,
	[Year] int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_P10B PRIMARY KEY (Id)
);
