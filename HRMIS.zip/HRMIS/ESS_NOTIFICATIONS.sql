-- HRMIS.dbo.ESS_NOTIFICATIONS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ESS_NOTIFICATIONS;

CREATE TABLE HRMIS.dbo.ESS_NOTIFICATIONS (
	NotificationId bigint IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CategoryId int NULL,
	Notification nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	Seen bit DEFAULT 0 NULL,
	Link nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ESS_NOTIFICATIONS PRIMARY KEY (NotificationId)
);
