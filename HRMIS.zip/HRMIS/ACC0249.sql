-- HRMIS.dbo.ACC0249 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0249;

CREATE TABLE HRMIS.dbo.ACC0249 (
	EmpAssetId int IDENTITY(1,1) NOT NULL,
	AssetId int NULL,
	EmpId int NULL,
	AssignedDate date NULL,
	Returned bit DEFAULT 0 NULL,
	ReturnedDate date NULL,
	CONSTRAINT PK_ACC0249 PRIMARY KEY (EmpAssetId)
);
