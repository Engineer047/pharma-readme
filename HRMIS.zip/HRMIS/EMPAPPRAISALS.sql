-- HRMIS.dbo.EMPAPPRAISALS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EMPAPPRAISALS;

CREATE TABLE HRMIS.dbo.EMPAPPRAISALS (
	EmpAppraisalId int IDENTITY(1,1) NOT NULL,
	SystemLog date NULL,
	EmpId int NULL,
	PeriodId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitleId int NULL,
	KpaId int NULL,
	KPI nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	KPIID int NULL,
	TargetId int NULL,
	EmpTargetId int NULL,
	StartDate date NULL,
	DueDate date NULL,
	SelfAppraisalDate date NULL,
	AppraisalDate date NULL,
	PercentComplete decimal(18,2) NULL,
	StatusId int NULL,
	Target nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Weight decimal(18,2) NULL,
	MaxScore int NULL,
	EmpRatingId int NULL,
	ManRatingId int NULL,
	ManComments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpComments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpScores int NULL,
	ManScores int NULL,
	Appraiser nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManFinalComments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpFinalComments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerAppraised bit DEFAULT 0 NULL,
	SelfAppraised bit DEFAULT 0 NULL,
	Completed bit DEFAULT 0 NULL,
	LineScore AS ((isnull(CONVERT([decimal],[ManScores],(0)),(0))/isnull(CONVERT([decimal],[MaxScore],(0)),(0)))*isnull([Weight],(0))),
	SelfLineScore AS ((isnull(CONVERT([decimal],[EmpScores],(0)),(0))/isnull(CONVERT([decimal],[MaxScore],(0)),(0)))*isnull([Weight],(0))),
	TotalLineScore AS ([dbo].[fGetTotalLineScore]([PeriodId],[EmpId])),
	TotalSelfLineScore AS ([dbo].[fGetTotalSelfLineScore]([PeriodId],[EmpId])),
	TotalScorePerKPI decimal(18,2) NULL,
	TotalScorePerKPA decimal(18,2) NULL,
	DocumentURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_EMPAPPRAISALS PRIMARY KEY (EmpAppraisalId)
);
