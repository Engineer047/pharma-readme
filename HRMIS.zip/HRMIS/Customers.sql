-- HRMIS.dbo.Customers definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Customers;

CREATE TABLE HRMIS.dbo.Customers (
	CustomerID int IDENTITY(1,1) NOT NULL,
	CompanyName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContactName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	City nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_Customers PRIMARY KEY (CustomerID)
);
