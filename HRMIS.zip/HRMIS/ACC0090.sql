-- HRMIS.dbo.ACC0090 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0090;

CREATE TABLE HRMIS.dbo.ACC0090 (
	CustomParameterId int IDENTITY(1,1) NOT NULL,
	CustomParameter nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	CustomParameterType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	MonthId int NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsInsurance bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0099 PRIMARY KEY (CustomParameterId)
);
