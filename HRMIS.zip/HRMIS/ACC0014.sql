-- HRMIS.dbo.ACC0014 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0014;

CREATE TABLE HRMIS.dbo.ACC0014 (
	CountryId int IDENTITY(1,1) NOT NULL,
	Country nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CountryCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0014 PRIMARY KEY (CountryId)
);
