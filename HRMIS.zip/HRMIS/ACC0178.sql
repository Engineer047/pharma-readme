-- HRMIS.dbo.ACC0178 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0178;

CREATE TABLE HRMIS.dbo.ACC0178 (
	InterventionId int IDENTITY(1,1) NOT NULL,
	Intervention nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0178 PRIMARY KEY (InterventionId)
);
