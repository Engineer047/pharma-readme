-- HRMIS.dbo.ACC0222 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0222;

CREATE TABLE HRMIS.dbo.ACC0222 (
	SuccessionReadinessId int IDENTITY(1,1) NOT NULL,
	SuccessionReadiness nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0222 PRIMARY KEY (SuccessionReadinessId)
);
