-- HRMIS.dbo.ACC0034 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0034;

CREATE TABLE HRMIS.dbo.ACC0034 (
	CourceId int IDENTITY(1,1) NOT NULL,
	EducationLevelId int NULL,
	Course nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	McourseId int NULL,
	CONSTRAINT PK_ACC0034 PRIMARY KEY (CourceId)
);
