-- HRMIS.dbo.ACC0004 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0004;

CREATE TABLE HRMIS.dbo.ACC0004 (
	CompanyId int NOT NULL,
	BranchId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	CentreCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContactPerson nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Manager nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AssManager nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ASSMNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Latitude decimal(18,16) NULL,
	Longitude decimal(18,16) NULL,
	CONSTRAINT PK_ACC0004 PRIMARY KEY (CompanyId,BranchId)
);
