-- HRMIS.dbo.ACC0131 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0131;

CREATE TABLE HRMIS.dbo.ACC0131 (
	id int IDENTITY(1,1) NOT NULL,
	A decimal(18,2) NULL,
	B decimal(18,2) NULL,
	C decimal(18,2) NULL,
	D decimal(18,2) NULL,
	E1 decimal(18,2) NULL,
	E2 decimal(18,2) NOT NULL,
	E3 decimal(18,2) NULL,
	F decimal(18,2) NULL,
	G decimal(18,2) NULL,
	H decimal(18,2) NULL,
	J decimal(18,2) NULL,
	K decimal(18,2) NULL,
	L decimal(18,2) NULL,
	EmpId int NULL,
	Empno nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	OtherRelief decimal(18,2) NULL,
	MonthId int NULL,
	PersonalRelief decimal(18,2) NULL,
	TotalRelief decimal(18,2) NULL,
	[Month] int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Year] int NULL,
	CONSTRAINT PK_P9B PRIMARY KEY (id)
);
