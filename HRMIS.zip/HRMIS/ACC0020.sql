-- HRMIS.dbo.ACC0020 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0020;

CREATE TABLE HRMIS.dbo.ACC0020 (
	BankBranchId int IDENTITY(1,1) NOT NULL,
	BankId int NULL,
	BankBranchCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankBranch nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0020 PRIMARY KEY (BankBranchId)
);
