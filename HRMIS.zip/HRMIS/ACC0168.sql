-- HRMIS.dbo.ACC0168 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0168;

CREATE TABLE HRMIS.dbo.ACC0168 (
	CasualsRosterId int IDENTITY(1,1) NOT NULL,
	CasualsId int NOT NULL,
	EmpId int NOT NULL,
	[Date] date NULL,
	TimeIn datetime NULL,
	TimeOut datetime NULL,
	HoursWorked decimal(18,2) NULL,
	HoursLate decimal(18,2) NULL,
	CONSTRAINT PK_ACC0168 PRIMARY KEY (CasualsRosterId,CasualsId,EmpId),
	CONSTRAINT FK_ACC0168_ACC0166 FOREIGN KEY (CasualsId,EmpId) REFERENCES HRMIS.dbo.ACC0166(CasualsId,EmpId)
);
