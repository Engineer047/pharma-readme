-- HRMIS.dbo.ACC0017 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0017;

CREATE TABLE HRMIS.dbo.ACC0017 (
	PaymentRefId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CurrencyId int NULL,
	PayFrequencyId int NULL,
	BankId int NULL,
	BankBranchId int NULL,
	PaymentModeId int NULL,
	BankAccountNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankAccountName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NSSF decimal(18,2) DEFAULT 0 NULL,
	BasicPay decimal(18,2) DEFAULT 0 NULL,
	Relief decimal(18,2) DEFAULT 0 NULL,
	VoluntaryNSSF decimal(18,2) DEFAULT 0 NULL,
	PayrollLiability decimal(18,2) DEFAULT 0 NULL,
	HoldPayment bit DEFAULT 0 NULL,
	HoldPayReason nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PayrollRatio decimal(18,2) DEFAULT 1.00 NULL,
	EnablePaye bit DEFAULT 0 NULL,
	EnableNssf bit DEFAULT 0 NULL,
	EnableNhif bit DEFAULT 0 NULL,
	EnableHousingTax bit DEFAULT 1 NULL,
	HouseAllowance AS ((0.15)*[basicPay]),
	EnableHouseAllowance bit DEFAULT 0 NULL,
	FixedOvertime decimal(18,2) NULL,
	PensionEmloyer decimal(18,2) NULL,
	Gratuity bit DEFAULT 0 NULL,
	EmployeeTypeId int DEFAULT 1 NULL,
	Gross decimal(18,2) NULL,
	PaypointBankId int NULL,
	CONSTRAINT PK_ACC0017 PRIMARY KEY (PaymentRefId)
);
 CREATE NONCLUSTERED INDEX IX_ACC0017 ON HRMIS.dbo.ACC0017 (  EmpId ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
