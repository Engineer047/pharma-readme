-- HRMIS.dbo.ACC0236 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0236;

CREATE TABLE HRMIS.dbo.ACC0236 (
	TravelId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	YearId int NULL,
	MonthId int NULL,
	TravelDescription nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Departure date NULL,
	ReturnDate date NULL,
	CurrencyId int NULL,
	Transportation decimal(18,2) NULL,
	Lodging decimal(18,2) NULL,
	Fares decimal(18,2) NULL,
	CarRental decimal(18,2) NULL,
	Parking decimal(18,2) NULL,
	Other decimal(18,2) NULL,
	TotalExpense decimal(18,2) NULL,
	Processing bit DEFAULT 1 NULL,
	Approved bit DEFAULT 0 NULL,
	ApprovedDate date NULL,
	ApprovedAmount decimal(18,2) NULL,
	ApprovedBy int NULL,
	Cancelled bit DEFAULT 0 NULL,
	Comment nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Locked bit NULL,
	DocumentUrl nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerEmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerEmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AssManagerEmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AssManagerEmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0236 PRIMARY KEY (TravelId)
);
