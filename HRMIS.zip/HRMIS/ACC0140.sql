-- HRMIS.dbo.ACC0140 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0140;

CREATE TABLE HRMIS.dbo.ACC0140 (
	EmpCompetencyId int IDENTITY(1,1) NOT NULL,
	CompetencyId nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RatingId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Comments nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	FormId int NULL,
	FormName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManRatingId int NULL,
	ManComments nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SystemDate date DEFAULT getdate() NULL,
	EmpScores decimal(18,2) NULL,
	ManScores decimal(18,2) NULL,
	CONSTRAINT PK_ACC0140 PRIMARY KEY (EmpCompetencyId)
);
