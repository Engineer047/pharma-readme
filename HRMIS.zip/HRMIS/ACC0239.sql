-- HRMIS.dbo.ACC0239 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0239;

CREATE TABLE HRMIS.dbo.ACC0239 (
	SubAllowanceId int IDENTITY(1,1) NOT NULL,
	AllowanceId int NULL,
	JobGradeId int NULL,
	Rate decimal(18,2) NULL,
	CONSTRAINT PK_ACC0239 PRIMARY KEY (SubAllowanceId)
);
