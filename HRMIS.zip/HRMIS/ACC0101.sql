-- HRMIS.dbo.ACC0101 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0101;

CREATE TABLE HRMIS.dbo.ACC0101 (
	MonthId int IDENTITY(1,1) NOT NULL,
	[Month] int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0101 PRIMARY KEY (MonthId)
);
