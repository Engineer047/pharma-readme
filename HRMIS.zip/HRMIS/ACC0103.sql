-- HRMIS.dbo.ACC0103 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0103;

CREATE TABLE HRMIS.dbo.ACC0103 (
	EmpId int NULL,
	EmpShiftId int IDENTITY(1,1) NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DFrom date NULL,
	DTo date NULL,
	ShiftId int NULL,
	ShiftCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsOnCall bit NULL,
	Approved bit DEFAULT 0 NULL,
	BranchId int NULL,
	Cancelled bit DEFAULT 0 NULL,
	ApprovedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateApproved date NULL,
	CONSTRAINT PK_ACC0103 PRIMARY KEY (EmpShiftId)
);
