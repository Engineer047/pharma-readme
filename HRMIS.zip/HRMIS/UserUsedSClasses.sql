-- HRMIS.dbo.UserUsedSClasses definition

-- Drop table

-- DROP TABLE HRMIS.dbo.UserUsedSClasses;

CREATE TABLE HRMIS.dbo.UserUsedSClasses (
	UserId int NOT NULL,
	SchId int NOT NULL,
	CONSTRAINT USER_USED_SCL PRIMARY KEY (UserId,SchId)
);
