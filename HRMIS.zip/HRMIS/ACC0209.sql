-- HRMIS.dbo.ACC0209 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0209;

CREATE TABLE HRMIS.dbo.ACC0209 (
	BudgetItemId int IDENTITY(1,1) NOT NULL,
	BudgetItem nchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0209 PRIMARY KEY (BudgetItemId)
);
