-- HRMIS.dbo.ACC0027 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0027;

CREATE TABLE HRMIS.dbo.ACC0027 (
	HolidayId int IDENTITY(1,1) NOT NULL,
	Holiday nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RepeatsAnnually bit DEFAULT 0 NULL,
	HolidayDate date NULL,
	PayRate float NULL,
	IsCurrent AS ([dbo].[fGetCurrentPeriod]([HolidayDate])),
	CONSTRAINT PK_ACC0027 PRIMARY KEY (HolidayId)
);
