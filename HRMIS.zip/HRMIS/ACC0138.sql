-- HRMIS.dbo.ACC0138 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0138;

CREATE TABLE HRMIS.dbo.ACC0138 (
	CompetencyFactorsId int IDENTITY(1,1) NOT NULL,
	Competency nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TotalPercentage decimal(18,2) NULL,
	CONSTRAINT PK_ACC0138 PRIMARY KEY (CompetencyFactorsId)
);
