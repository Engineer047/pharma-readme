-- HRMIS.dbo.ACC0028 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0028;

CREATE TABLE HRMIS.dbo.ACC0028 (
	CourseId int IDENTITY(1,1) NOT NULL,
	Course nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0028 PRIMARY KEY (CourseId)
);
