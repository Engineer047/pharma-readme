-- HRMIS.dbo.ACC0077 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0077;

CREATE TABLE HRMIS.dbo.ACC0077 (
	LeaveApplicationId int IDENTITY(1,1) NOT NULL,
	LAFrom date NULL,
	LATo date NULL,
	SystemLog datetime NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Status nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Completed bit NULL,
	Processing bit NULL,
	Declined bit NULL,
	CONSTRAINT PK_ACC0077 PRIMARY KEY (LeaveApplicationId)
);
