-- HRMIS.dbo.ACC0176 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0176;

CREATE TABLE HRMIS.dbo.ACC0176 (
	InfactionId int IDENTITY(1,1) NOT NULL,
	Infraction nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0176 PRIMARY KEY (InfactionId)
);
