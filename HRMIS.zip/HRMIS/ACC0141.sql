-- HRMIS.dbo.ACC0141 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0141;

CREATE TABLE HRMIS.dbo.ACC0141 (
	RatingId int IDENTITY(1,1) NOT NULL,
	Rate nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Value nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0141 PRIMARY KEY (RatingId)
);
