-- HRMIS.dbo.ACC0126 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0126;

CREATE TABLE HRMIS.dbo.ACC0126 (
	Id int IDENTITY(1,1) NOT NULL,
	[Month] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	paye decimal(18,2) NULL,
	Pensioncontributions decimal(18,2) NULL,
	DatePaid date DEFAULT getdate() NULL,
	YearId int NULL,
	MonthId int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpPIN nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Year] int NULL,
	CONSTRAINT PK_P10C PRIMARY KEY (Id)
);
