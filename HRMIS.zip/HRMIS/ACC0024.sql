-- HRMIS.dbo.ACC0024 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0024;

CREATE TABLE HRMIS.dbo.ACC0024 (
	EmpLeaveId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LeaveTypeId int NULL,
	DefaultEntitlement decimal(18,2) NULL,
	Paid bit DEFAULT 0 NULL,
	PayRate decimal(18,2) NULL,
	IsRecurring bit NULL,
	LeaveStartDate date DEFAULT getdate() NULL,
	Balance AS ([dbo].[fGetLeaveDaysBalance]([EmpId],[LeaveTypeId],[PeriodId])),
	OpeningBalance decimal(18,2) DEFAULT 0 NULL,
	EarnedLeave AS ([dbo].[GetEarnedLeave]([EmpId],[LeaveTypeId],[PeriodId],[OpeningBalance])),
	DateToday AS (getdate()) NOT NULL,
	DaysTaken AS ([dbo].[fGetTotalLeaveDays]([EmpId],[LeaveTypeId],[PeriodId])),
	Entitlement decimal(18,2) DEFAULT 0 NULL,
	PeriodId int NULL,
	HasEntitlement int NULL,
	CONSTRAINT PK_ACC0024 PRIMARY KEY (EmpLeaveId)
);
