-- HRMIS.dbo.ACC0073 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0073;

CREATE TABLE HRMIS.dbo.ACC0073 (
	CompetencyId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NOT NULL,
	Competency nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RatingId int NULL,
	RatingCategoryId int NULL,
	Notes nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0073 PRIMARY KEY (CompetencyId)
);
