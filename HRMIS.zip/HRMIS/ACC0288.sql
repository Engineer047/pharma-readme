-- HRMIS.dbo.ACC0288 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0288;

CREATE TABLE HRMIS.dbo.ACC0288 (
	ClaimLimitId int IDENTITY(1,1) NOT NULL,
	YearId int NULL,
	ClaimTypeId int NULL,
	MaxAmount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0288 PRIMARY KEY (ClaimLimitId)
);
