-- HRMIS.dbo.SystemLog definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SystemLog;

CREATE TABLE HRMIS.dbo.SystemLog (
	ID int IDENTITY(1,1) NOT NULL,
	Operator varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LogTime datetime DEFAULT getdate() NULL,
	MachineAlias varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LogTag smallint NULL,
	LogDescr varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__SystemLo__3214EC2700FAD8E7 PRIMARY KEY (ID)
);
