-- HRMIS.dbo.ACC0106 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0106;

CREATE TABLE HRMIS.dbo.ACC0106 (
	EmpAttId int IDENTITY(1,1) NOT NULL,
	DateAtt datetime NOT NULL,
	EmpId int NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TimeIn datetime NOT NULL,
	TimeOut datetime NULL,
	Cancelled bit NULL,
	CONSTRAINT PK_ACC0106 PRIMARY KEY (EmpAttId)
);
