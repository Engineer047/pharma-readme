-- HRMIS.dbo.ACC0201 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0201;

CREATE TABLE HRMIS.dbo.ACC0201 (
	AppraisalAssignmentId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NOT NULL,
	Category nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	GoalId int NULL,
	Metric nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Weight nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SpecificObjective nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	AppraiserId int NULL,
	RatingId int NULL,
	Achievement nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RawScore decimal(18,2) NULL,
	WeightScore decimal(18,2) NULL,
	Comments nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PercentComplete decimal(18,2) NULL,
	DateCompleted date NULL,
	Assessed bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0201 PRIMARY KEY (AppraisalAssignmentId,AppraisalId)
);
