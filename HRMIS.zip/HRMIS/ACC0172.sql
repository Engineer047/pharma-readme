-- HRMIS.dbo.ACC0172 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0172;

CREATE TABLE HRMIS.dbo.ACC0172 (
	ConditionId int IDENTITY(1,1) NOT NULL,
	[Condition] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
