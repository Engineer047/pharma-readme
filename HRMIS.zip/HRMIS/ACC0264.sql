-- HRMIS.dbo.ACC0264 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0264;

CREATE TABLE HRMIS.dbo.ACC0264 (
	JobDescriptionResponsibilitiesId int IDENTITY(1,1) NOT NULL,
	JobDescriptionId int NULL,
	JobTitleId int NULL,
	Responsibility nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0264 PRIMARY KEY (JobDescriptionResponsibilitiesId)
);
