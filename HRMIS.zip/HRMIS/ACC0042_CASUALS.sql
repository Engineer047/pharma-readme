-- HRMIS.dbo.ACC0042_CASUALS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0042_CASUALS;

CREATE TABLE HRMIS.dbo.ACC0042_CASUALS (
	NextOfKinId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Relationship nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellPhone nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhysicalAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CasualEmpId int NULL,
	CONSTRAINT PK_ACC0042_CASUALS PRIMARY KEY (NextOfKinId)
);
