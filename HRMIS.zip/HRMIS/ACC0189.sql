-- HRMIS.dbo.ACC0189 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0189;

CREATE TABLE HRMIS.dbo.ACC0189 (
	AccomplishmentId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NOT NULL,
	EmpId int NOT NULL,
	Accomplishment nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0189 PRIMARY KEY (AccomplishmentId,AppraisalId,EmpId),
	CONSTRAINT FK_ACC0189_ACC0188 FOREIGN KEY (AppraisalId,EmpId) REFERENCES HRMIS.dbo.ACC0188(AppraisalId,EmpId)
);
