-- HRMIS.dbo.ACC0231 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0231;

CREATE TABLE HRMIS.dbo.ACC0231 (
	SubscriptionPaidById int IDENTITY(1,1) NOT NULL,
	SubscriptionPaidBy nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0231 PRIMARY KEY (SubscriptionPaidById)
);
