-- HRMIS.dbo.ASSET_CATEGORIES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ASSET_CATEGORIES;

CREATE TABLE HRMIS.dbo.ASSET_CATEGORIES (
	CategoryId int IDENTITY(1,1) NOT NULL,
	Category nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ASSET_CATEGORIES PRIMARY KEY (CategoryId)
);
