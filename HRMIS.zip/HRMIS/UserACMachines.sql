-- HRMIS.dbo.UserACMachines definition

-- Drop table

-- DROP TABLE HRMIS.dbo.UserACMachines;

CREATE TABLE HRMIS.dbo.UserACMachines (
	UserID int NOT NULL,
	Deviceid int NOT NULL,
	CONSTRAINT UserAC_Machines PRIMARY KEY (UserID,Deviceid)
);
