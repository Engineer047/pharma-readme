-- HRMIS.dbo.CASUALMASTER definition

-- Drop table

-- DROP TABLE HRMIS.dbo.CASUALMASTER;

CREATE TABLE HRMIS.dbo.CASUALMASTER (
	CasualMasterId int IDENTITY(1,1) NOT NULL,
	FirstName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MiddleName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LastName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitle nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Project nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ProjectId int NULL,
	Category nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CategoryId int NULL,
	PinNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IDNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NSSFNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NHIFNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellphoneNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DailyWage decimal(18,2) NULL,
	Confirmed bit DEFAULT 0 NULL,
	CONSTRAINT PK_CASUALMASTER PRIMARY KEY (CasualMasterId)
);
