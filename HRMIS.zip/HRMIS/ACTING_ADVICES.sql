-- HRMIS.dbo.ACTING_ADVICES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACTING_ADVICES;

CREATE TABLE HRMIS.dbo.ACTING_ADVICES (
	ActingAdviceId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	PayAdvice nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount decimal(18,2) NULL,
	ParameterId int NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentURL nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Period decimal(18,2) NULL,
	FullMonths int NULL,
	Posted bit NULL,
	Id int NULL,
	CONSTRAINT PK_ACTING_ADVICES PRIMARY KEY (ActingAdviceId)
);
