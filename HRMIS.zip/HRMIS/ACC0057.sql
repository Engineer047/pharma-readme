-- HRMIS.dbo.ACC0057 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0057;

CREATE TABLE HRMIS.dbo.ACC0057 (
	JobGroupId int IDENTITY(1,1) NOT NULL,
	JobGroup nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0057 PRIMARY KEY (JobGroupId)
);
