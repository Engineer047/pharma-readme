-- HRMIS.dbo.RECLAIMED_ASSETS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.RECLAIMED_ASSETS;

CREATE TABLE HRMIS.dbo.RECLAIMED_ASSETS (
	EmpReturnAssetId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	AssetId int NULL,
	EmpAssetId int NULL,
	ReturnDate date NULL,
	StatusId int NULL,
	[Condition] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentURL nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_RECLAIMED_ASSETS PRIMARY KEY (EmpReturnAssetId)
);
