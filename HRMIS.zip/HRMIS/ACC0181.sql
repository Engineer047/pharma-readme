-- HRMIS.dbo.ACC0181 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0181;

CREATE TABLE HRMIS.dbo.ACC0181 (
	LeaveToPositionId int IDENTITY(1,1) NOT NULL,
	LeaveToPosition nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0181 PRIMARY KEY (LeaveToPositionId)
);
