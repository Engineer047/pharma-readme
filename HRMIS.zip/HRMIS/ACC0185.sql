-- HRMIS.dbo.ACC0185 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0185;

CREATE TABLE HRMIS.dbo.ACC0185 (
	QuestionNoId int IDENTITY(1,1) NOT NULL,
	QuestionNo nvarchar(40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Question nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0185 PRIMARY KEY (QuestionNoId)
);
