-- HRMIS.dbo.ACC0226 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0226;

CREATE TABLE HRMIS.dbo.ACC0226 (
	JobContractId int IDENTITY(1,1) NOT NULL,
	StartDate date NULL,
	EndDate date NULL,
	ContractTypeId int NULL,
	Renewable bit NULL,
	ContractDocumentUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	CONSTRAINT PK_ACC0226 PRIMARY KEY (JobContractId)
);
