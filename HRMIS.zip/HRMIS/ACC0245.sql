-- HRMIS.dbo.ACC0245 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0245;

CREATE TABLE HRMIS.dbo.ACC0245 (
	AllowanceUploadsId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	AllowanceId int NULL,
	Amount decimal(18,2) NULL,
	[Date] date NULL,
	Confirmed bit DEFAULT 0 NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0245 PRIMARY KEY (AllowanceUploadsId)
);
