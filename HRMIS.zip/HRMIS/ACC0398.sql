-- HRMIS.dbo.ACC0398 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0398;

CREATE TABLE HRMIS.dbo.ACC0398 (
	IccidentTrailId int IDENTITY(1,1) NOT NULL,
	IccidentId int NULL,
	SysDate datetime NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	[Time] time NULL,
	Comment nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CommentByEmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0398 PRIMARY KEY (IccidentTrailId)
);
