-- HRMIS.dbo.ACC0059 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0059;

CREATE TABLE HRMIS.dbo.ACC0059 (
	AccountCodeId int IDENTITY(1,1) NOT NULL,
	AccountCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PayrollParameterId int NULL,
	PayrollParameter nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PayrollCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0059 PRIMARY KEY (AccountCodeId)
);
