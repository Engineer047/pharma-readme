-- HRMIS.dbo.ACC0165 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0165;

CREATE TABLE HRMIS.dbo.ACC0165 (
	TypeOfPlanId int IDENTITY(1,1) NOT NULL,
	TypeOfPlan nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0165 PRIMARY KEY (TypeOfPlanId)
);
