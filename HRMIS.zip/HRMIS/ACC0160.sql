-- HRMIS.dbo.ACC0160 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0160;

CREATE TABLE HRMIS.dbo.ACC0160 (
	ClaimConditionId int IDENTITY(1,1) NOT NULL,
	ClaimsId int NOT NULL,
	EmpId int NOT NULL,
	ConditionDueToId int NULL,
	DescriptionOfCondition nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateOfIncident date NULL,
	TimeOfServiceId int NULL,
	CONSTRAINT PK_ACC0160 PRIMARY KEY (ClaimConditionId,ClaimsId,EmpId),
	CONSTRAINT FK_ACC0160_ACC0154 FOREIGN KEY (ClaimsId,EmpId) REFERENCES HRMIS.dbo.ACC0154(ClaimsId,EmpId),
	CONSTRAINT FK_ACC0160_ACC0159 FOREIGN KEY (TimeOfServiceId) REFERENCES HRMIS.dbo.ACC0159(TimeOfServiceId),
	CONSTRAINT FK_ACC0160_ACC0161 FOREIGN KEY (ConditionDueToId) REFERENCES HRMIS.dbo.ACC0161(ConditionDueToId)
);
