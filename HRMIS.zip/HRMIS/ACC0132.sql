-- HRMIS.dbo.ACC0132 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0132;

CREATE TABLE HRMIS.dbo.ACC0132 (
	GoalStatusId int IDENTITY(1,1) NOT NULL,
	Status nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SystemDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0132 PRIMARY KEY (GoalStatusId)
);
