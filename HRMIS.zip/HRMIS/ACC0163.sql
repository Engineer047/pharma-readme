-- HRMIS.dbo.ACC0163 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0163;

CREATE TABLE HRMIS.dbo.ACC0163 (
	TypeOfPlanId int IDENTITY(1,1) NOT NULL,
	TypeOfPlan nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0163 PRIMARY KEY (TypeOfPlanId)
);
