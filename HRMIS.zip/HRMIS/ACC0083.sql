-- HRMIS.dbo.ACC0083 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0083;

CREATE TABLE HRMIS.dbo.ACC0083 (
	JobDescriptionId int IDENTITY(1,1) NOT NULL,
	JobTitleId int NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	Responsibility nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SkillsRequired nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Qualifications nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Notes ntext COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobDescription nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0083 PRIMARY KEY (JobDescriptionId)
);
