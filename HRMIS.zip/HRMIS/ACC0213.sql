-- HRMIS.dbo.ACC0213 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0213;

CREATE TABLE HRMIS.dbo.ACC0213 (
	SpecificObjectiveId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NULL,
	GoalId int NULL,
	EmpId int NULL,
	SpecificObjective nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Achievement nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateCompleted date NULL,
	PercentComplete decimal(18,2) NULL,
	CONSTRAINT PK_ACC0213 PRIMARY KEY (SpecificObjectiveId)
);
