-- HRMIS.dbo.ACC0056 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0056;

CREATE TABLE HRMIS.dbo.ACC0056 (
	JobGradeId int IDENTITY(1,1) NOT NULL,
	JobGrade nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MaxSalary float NULL,
	MinSalary float NULL,
	CONSTRAINT PK_ACC0056 PRIMARY KEY (JobGradeId)
);
