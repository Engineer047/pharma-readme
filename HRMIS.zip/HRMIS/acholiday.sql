-- HRMIS.dbo.acholiday definition

-- Drop table

-- DROP TABLE HRMIS.dbo.acholiday;

CREATE TABLE HRMIS.dbo.acholiday (
	begindate datetime NULL,
	enddate datetime NULL,
	holidayid int NULL,
	primaryid int IDENTITY(1,1) NOT NULL,
	timezone int NULL,
	CONSTRAINT PK__acholida__77EFAA4814C2F9D2 PRIMARY KEY (primaryid)
);
 CREATE NONCLUSTERED INDEX holidayid ON HRMIS.dbo.acholiday (  holidayid ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
