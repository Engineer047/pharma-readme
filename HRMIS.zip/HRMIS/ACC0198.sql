-- HRMIS.dbo.ACC0198 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0198;

CREATE TABLE HRMIS.dbo.ACC0198 (
	AppraisalId int IDENTITY(1,1) NOT NULL,
	AppraisalPeriodName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AppraisalStartDate date NULL,
	AppraisalEndDate date NULL,
	AppraisalPeriodDescription nvarchar(2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0198_1 PRIMARY KEY (AppraisalId)
);
