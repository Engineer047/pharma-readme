-- HRMIS.dbo.ServerLog definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ServerLog;

CREATE TABLE HRMIS.dbo.ServerLog (
	ID int IDENTITY(1,1) NOT NULL,
	EVENT varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	USERID int NOT NULL,
	EnrollNumber varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[parameter] smallint NULL,
	EVENTTIME datetime NOT NULL,
	SENSORID varchar(5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	OPERATOR varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
