-- HRMIS.dbo.ACC0048 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0048;

CREATE TABLE HRMIS.dbo.ACC0048 (
	EmpParameterId int IDENTITY(1,1) NOT NULL,
	ParameterId int NULL,
	ParameterCategoryId int NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SystemLog datetime NULL,
	Locked bit NULL,
	Value float NULL,
	Rate float NULL,
	[Month] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Year] int NULL,
	Currency float NULL,
	[Date] date NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0048 PRIMARY KEY (EmpParameterId)
);
