-- HRMIS.dbo.OVERTIME_PAY_CASUALS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.OVERTIME_PAY_CASUALS;

CREATE TABLE HRMIS.dbo.OVERTIME_PAY_CASUALS (
	OvertimeHrsId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Hours decimal(18,2) NULL,
	MonthDays int NULL,
	OvertimePay decimal(18,2) NULL,
	OvertimeId int NULL,
	Rate decimal(18,2) NULL,
	CONSTRAINT PK_OVERTIME_PAY_CASUALS PRIMARY KEY (OvertimeHrsId)
);
