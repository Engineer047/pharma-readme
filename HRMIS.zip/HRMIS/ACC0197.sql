-- HRMIS.dbo.ACC0197 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0197;

CREATE TABLE HRMIS.dbo.ACC0197 (
	AppraiserId int IDENTITY(1,1) NOT NULL,
	EmpId int NOT NULL,
	AppraisalGroupId int NOT NULL,
	AppraisalId int NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0197 PRIMARY KEY (AppraiserId,EmpId,AppraisalGroupId)
);
