-- HRMIS.dbo.ACC0450 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0450;

CREATE TABLE HRMIS.dbo.ACC0450 (
	Payrolld int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	iFrom date NULL,
	iTo date NULL,
	iNet decimal(18,2) NULL,
	iM decimal(18,2) NULL,
	iO decimal(18,2) NULL,
	iP decimal(18,2) NULL,
	Locked bit DEFAULT 0 NULL,
	Paid bit DEFAULT 0 NULL,
	SysDate datetime DEFAULT getdate() NULL,
	iMM decimal(18,2) NULL,
	iOM decimal(18,2) NULL,
	iPM decimal(18,2) NULL,
	CONSTRAINT PK_ACC0450 PRIMARY KEY (Payrolld)
);
