-- HRMIS.dbo.ACC0023 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0023;

CREATE TABLE HRMIS.dbo.ACC0023 (
	LeaveTypeId int IDENTITY(1,1) NOT NULL,
	LeaveType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultEntitlement decimal(18,2) NULL,
	Paid bit NULL,
	PayRate float NULL,
	IsRecurring bit NULL,
	MaxAmount decimal(18,2) NULL,
	ThresholdDays decimal(18,2) NULL,
	Active bit DEFAULT 1 NULL,
	NoticeNeeded bit DEFAULT 0 NULL,
	NoticeDays int NULL,
	CONSTRAINT PK_ACC0023 PRIMARY KEY (LeaveTypeId)
);
