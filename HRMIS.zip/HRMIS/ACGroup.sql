-- HRMIS.dbo.ACGroup definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACGroup;

CREATE TABLE HRMIS.dbo.ACGroup (
	GroupID smallint NOT NULL,
	Name varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TimeZone1 smallint DEFAULT 0 NULL,
	TimeZone2 smallint DEFAULT 0 NULL,
	TimeZone3 smallint DEFAULT 0 NULL,
	holidayvaild bit NULL,
	verifystyle int NULL,
	CONSTRAINT PK__ACGroup__149AF30AD1CE97AC PRIMARY KEY (GroupID)
);
