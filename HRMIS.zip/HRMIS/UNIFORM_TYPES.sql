-- HRMIS.dbo.UNIFORM_TYPES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.UNIFORM_TYPES;

CREATE TABLE HRMIS.dbo.UNIFORM_TYPES (
	UniformTypeId int IDENTITY(1,1) NOT NULL,
	UniformType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cost decimal(18,2) NULL,
	CONSTRAINT PK_UNIFORM_TYPES PRIMARY KEY (UniformTypeId)
);
