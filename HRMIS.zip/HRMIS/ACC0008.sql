-- HRMIS.dbo.ACC0008 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0008;

CREATE TABLE HRMIS.dbo.ACC0008 (
	EmploymentStatusId int IDENTITY(1,1) NOT NULL,
	EmploymentStatus nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EntitledToPayment bit NULL,
	PayRate decimal(18,2) NULL,
	CONSTRAINT PK_ACC0008 PRIMARY KEY (EmploymentStatusId)
);
