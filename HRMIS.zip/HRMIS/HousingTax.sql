-- HRMIS.dbo.HousingTax definition

-- Drop table

-- DROP TABLE HRMIS.dbo.HousingTax;

CREATE TABLE HRMIS.dbo.HousingTax (
	HousingTaxId int IDENTITY(1,1) NOT NULL,
	EmployeeRate decimal(18,2) NULL,
	EmployerRate decimal(18,2) NULL,
	CONSTRAINT PK_HousingTax PRIMARY KEY (HousingTaxId)
);
