-- HRMIS.dbo.ACC0137 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0137;

CREATE TABLE HRMIS.dbo.ACC0137 (
	GoalId int IDENTITY(1,1) NOT NULL,
	Metric nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Weight decimal(18,2) NULL,
	StartDate date NULL,
	DueDate date NULL,
	PercentComplete decimal(18,2) NULL,
	StatusId int NULL,
	MilestoneId int NULL,
	SubgoalId int NULL,
	SystemDate date DEFAULT getdate() NULL,
	CategoryId int NULL,
	VisibilityId int NULL,
	RatingId int NULL,
	Goal nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	FormId int NULL,
	FormName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0137 PRIMARY KEY (GoalId),
	CONSTRAINT FK_ACC0137_ACC0132 FOREIGN KEY (StatusId) REFERENCES HRMIS.dbo.ACC0132(GoalStatusId),
	CONSTRAINT FK_ACC0137_ACC01321 FOREIGN KEY (StatusId) REFERENCES HRMIS.dbo.ACC0132(GoalStatusId),
	CONSTRAINT FK_ACC0137_ACC0133 FOREIGN KEY (VisibilityId) REFERENCES HRMIS.dbo.ACC0133(VisibilityId),
	CONSTRAINT FK_ACC0137_ACC0134 FOREIGN KEY (CategoryId) REFERENCES HRMIS.dbo.ACC0134(CategoryId)
);
