-- HRMIS.dbo.EmpAppraisalPeriod definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EmpAppraisalPeriod;

CREATE TABLE HRMIS.dbo.EmpAppraisalPeriod (
	EmpPeriodId int IDENTITY(1,1) NOT NULL,
	PeriodId int NULL,
	EmpId int NULL,
	Appraised bit DEFAULT 0 NULL,
	ManagerAppraised bit DEFAULT 0 NULL,
	CONSTRAINT PK_EmpAppraisalPeriod PRIMARY KEY (EmpPeriodId)
);
