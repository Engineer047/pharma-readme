-- HRMIS.dbo.ACC0180 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0180;

CREATE TABLE HRMIS.dbo.ACC0180 (
	LenghtOfServiceId int IDENTITY(1,1) NOT NULL,
	LenghtOfService nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0180 PRIMARY KEY (LenghtOfServiceId)
);
