-- HRMIS.dbo.ACC0262 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0262;

CREATE TABLE HRMIS.dbo.ACC0262 (
	JobDescriptionSkillsId int IDENTITY(1,1) NOT NULL,
	JobDescriptionId int NULL,
	JobTitleId int NULL,
	Skill nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0262 PRIMARY KEY (JobDescriptionSkillsId)
);
