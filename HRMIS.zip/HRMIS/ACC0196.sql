-- HRMIS.dbo.ACC0196 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0196;

CREATE TABLE HRMIS.dbo.ACC0196 (
	AppraisalGroupId int IDENTITY(1,1) NOT NULL,
	AppraisalGroup nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0196 PRIMARY KEY (AppraisalGroupId)
);
