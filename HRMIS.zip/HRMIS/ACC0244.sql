-- HRMIS.dbo.ACC0244 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0244;

CREATE TABLE HRMIS.dbo.ACC0244 (
	SubLoanTypeId int IDENTITY(1,1) NOT NULL,
	LoanTypeId int NULL,
	JobGradeId int NULL,
	MaxAmount decimal(18,2) NULL,
	CONSTRAINT PK_ACC0244 PRIMARY KEY (SubLoanTypeId)
);
