-- HRMIS.dbo.COOPLOANS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.COOPLOANS;

CREATE TABLE HRMIS.dbo.COOPLOANS (
	EMPID int NULL,
	EMPNO nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	COOPID int NULL,
	COOP decimal(18,2) NULL,
	LOANPRINCID int NULL,
	LOANPRINC decimal(18,2) NULL,
	LOANINTID decimal(18,2) NULL,
	LOANINT decimal(18,2) NULL
);
