-- HRMIS.dbo.LeavePeriods definition

-- Drop table

-- DROP TABLE HRMIS.dbo.LeavePeriods;

CREATE TABLE HRMIS.dbo.LeavePeriods (
	PeriodID int IDENTITY(1,1) NOT NULL,
	StartDate date NULL,
	EndDate date NULL,
	IsCurrent AS ([dbo].[fGetCurrentPeriod]([StartDate])),
	NoOfDays int NULL,
	[Year] AS (datepart(year,[StartDate])),
	CONSTRAINT PK_LeavePeriods PRIMARY KEY (PeriodID)
);
