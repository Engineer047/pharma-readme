-- HRMIS.dbo.ACC0221 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0221;

CREATE TABLE HRMIS.dbo.ACC0221 (
	SuccessionLikelihoodId int NOT NULL,
	SuccessionLikelihood nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0221 PRIMARY KEY (SuccessionLikelihoodId)
);
