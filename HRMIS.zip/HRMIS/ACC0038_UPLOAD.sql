-- HRMIS.dbo.ACC0038_UPLOAD definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0038_UPLOAD;

CREATE TABLE HRMIS.dbo.ACC0038_UPLOAD (
	EmployeeExperienceId int IDENTITY(1,1) NOT NULL,
	Organization nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EEFrom nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EETo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReasonForLeaving nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitle nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Confirmed bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0038_UPLOAD PRIMARY KEY (EmployeeExperienceId)
);
