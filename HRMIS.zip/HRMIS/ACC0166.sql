-- HRMIS.dbo.ACC0166 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0166;

CREATE TABLE HRMIS.dbo.ACC0166 (
	CasualsId int IDENTITY(1,1) NOT NULL,
	EmpId int NOT NULL,
	IsSick bit DEFAULT 0 NULL,
	Monthid int NULL,
	Yearid int NULL,
	DutyId int NULL,
	RateTypeId int NULL,
	CurrencyId int NULL,
	EffectiveDate date NULL,
	TerminationDate date NULL,
	PostedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DatePosted date NULL,
	CONSTRAINT PK_ACC0166 PRIMARY KEY (CasualsId,EmpId),
	CONSTRAINT FK_ACC0166_ACC0015 FOREIGN KEY (CurrencyId) REFERENCES HRMIS.dbo.ACC0015(CurrencyId),
	CONSTRAINT FK_ACC0166_ACC0167 FOREIGN KEY (DutyId) REFERENCES HRMIS.dbo.ACC0167(DutyId),
	CONSTRAINT FK_ACC0166_ACC0174 FOREIGN KEY (RateTypeId) REFERENCES HRMIS.dbo.ACC0174(RateTypeId)
);
