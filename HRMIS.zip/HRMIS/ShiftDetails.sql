-- HRMIS.dbo.ShiftDetails definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ShiftDetails;

CREATE TABLE HRMIS.dbo.ShiftDetails (
	ShiftId int IDENTITY(1,1) NOT NULL,
	Email nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StaffNo nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StartTime datetime NULL,
	StartLat float NULL,
	StartLng float NULL,
	VehReg nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StartOdometer float NULL,
	ShiftCode nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EndTime datetime NULL,
	EndLat float NULL,
	EndLng nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EndOdometer float NULL,
	Milage float NULL,
	IsShiftCompleted bit NULL,
	Hrs AS (datediff(hour,[StartTime],[EndTime])),
	Min AS (datediff(minute,[StartTime],[EndTime])%(60)),
	StartLoc nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EndLoc nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ShiftDetails PRIMARY KEY (ShiftId)
);
