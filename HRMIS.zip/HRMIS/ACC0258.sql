-- HRMIS.dbo.ACC0258 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0258;

CREATE TABLE HRMIS.dbo.ACC0258 (
	ResponsibilityId int IDENTITY(1,1) NOT NULL,
	ResponsibiltyCategoryId int NULL,
	Responsibility nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0258 PRIMARY KEY (ResponsibilityId)
);
