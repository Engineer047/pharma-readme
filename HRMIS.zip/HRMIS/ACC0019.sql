-- HRMIS.dbo.ACC0019 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0019;

CREATE TABLE HRMIS.dbo.ACC0019 (
	BankId int IDENTITY(1,1) NOT NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Bank nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0019 PRIMARY KEY (BankId)
);
