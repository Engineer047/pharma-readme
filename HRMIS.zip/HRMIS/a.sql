-- HRMIS.dbo.a definition

-- Drop table

-- DROP TABLE HRMIS.dbo.a;

CREATE TABLE HRMIS.dbo.a (
	workid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	empno nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	groupid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	employeeid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	jobtitleid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	jobgroupid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	officeid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	departmentid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	supervisorid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	workinghours nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	employementstatusid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	shiftid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	payovertime nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	penalise nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	jobdescription nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	noofleavedays nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	present nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	newjobtitle nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
