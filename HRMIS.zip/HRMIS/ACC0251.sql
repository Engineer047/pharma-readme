-- HRMIS.dbo.ACC0251 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0251;

CREATE TABLE HRMIS.dbo.ACC0251 (
	SkillCategoryId int IDENTITY(1,1) NOT NULL,
	SkillCategory nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0251 PRIMARY KEY (SkillCategoryId)
);
