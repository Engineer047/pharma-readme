-- HRMIS.dbo.Attendance definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Attendance;

CREATE TABLE HRMIS.dbo.Attendance (
	AttendanceId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateAtt date NULL,
	CheckIn datetime NULL,
	CheckOut datetime NULL,
	StartLat nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StartLng nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EndLat nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EndLng nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Hours AS (datediff(minute,[CheckIn],[CheckOut])/(60.00)),
	StartLoc nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EndLoc nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_Attendance PRIMARY KEY (AttendanceId)
);
