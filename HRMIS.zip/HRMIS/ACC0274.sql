-- HRMIS.dbo.ACC0274 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0274;

CREATE TABLE HRMIS.dbo.ACC0274 (
	InterviewScheduleId int IDENTITY(1,1) NOT NULL,
	VacancyApplicationId int NULL,
	VacancyRequisitionId int NULL,
	CandidateId int NULL,
	CandidateInterviewed bit DEFAULT 0 NULL,
	InterviewDate datetime NULL,
	InterviewDuration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DepartmentId int NULL,
	InterviewerId int NULL,
	InterviewTypeId int NULL,
	Venue nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Subject nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Message nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Scheduled bit DEFAULT 0 NULL,
	Approved bit DEFAULT 0 NULL,
	Rejected bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0274 PRIMARY KEY (InterviewScheduleId)
);
