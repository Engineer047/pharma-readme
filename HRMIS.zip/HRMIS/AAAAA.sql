-- HRMIS.dbo.AAAAA definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AAAAA;

CREATE TABLE HRMIS.dbo.AAAAA (
	empno int NULL,
	name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	bankcode int NULL,
	branchcode int NULL,
	number nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	bankid int NULL,
	branchid int NULL
);
