-- HRMIS.dbo.ACC0456 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0456;

CREATE TABLE HRMIS.dbo.ACC0456 (
	PayrollId int IDENTITY(1,1) NOT NULL,
	CashualPayrollScheduleId int NULL,
	[Year] int NULL,
	[Month] int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Week varchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PSFrom date NULL,
	PSTo date NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Designation nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Bank nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AccountNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DaysWorked decimal(18,2) NULL,
	BasicPay decimal(18,2) NULL,
	OvertimeMinutes decimal(18,2) NULL,
	OvertimeAmount decimal(18,2) NULL,
	LateMinutes decimal(18,2) NULL,
	Penalties decimal(18,2) NULL,
	Advances decimal(18,2) NULL,
	Additions decimal(18,2) NULL,
	PayForPeriod decimal(18,2) NULL,
	CONSTRAINT PK_ACC0456 PRIMARY KEY (PayrollId)
);
