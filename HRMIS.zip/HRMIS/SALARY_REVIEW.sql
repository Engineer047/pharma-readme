-- HRMIS.dbo.SALARY_REVIEW definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SALARY_REVIEW;

CREATE TABLE HRMIS.dbo.SALARY_REVIEW (
	EmpSalaryReviewId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	OldBasic decimal(18,2) NULL,
	NewBasic decimal(18,2) NULL,
	Comment nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	HRApproved bit DEFAULT 0 NULL,
	FMApproved bit DEFAULT 0 NULL,
	DirectorApproved bit DEFAULT 0 NULL,
	Cancelled bit DEFAULT 0 NULL,
	HRApprovedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FMApprovedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DirectorApprovedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	HRApprovedDate date NULL,
	FMApprovedDate date NULL,
	DirectorApprovedDate date NULL,
	CONSTRAINT PK_SALARY_REVIEW PRIMARY KEY (EmpSalaryReviewId)
);
