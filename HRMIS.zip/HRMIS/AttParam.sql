-- HRMIS.dbo.AttParam definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AttParam;

CREATE TABLE HRMIS.dbo.AttParam (
	PARANAME varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	PARATYPE varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PARAVALUE varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	CONSTRAINT PK__AttParam__889D235FB6D40374 PRIMARY KEY (PARANAME)
);
