-- HRMIS.dbo.KPIs definition

-- Drop table

-- DROP TABLE HRMIS.dbo.KPIs;

CREATE TABLE HRMIS.dbo.KPIs (
	KpiId int IDENTITY(1,1) NOT NULL,
	KpaId int NULL,
	KPI nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_KPI PRIMARY KEY (KpiId)
);
