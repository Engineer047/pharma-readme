-- HRMIS.dbo.Contracts_Uploads definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Contracts_Uploads;

CREATE TABLE HRMIS.dbo.Contracts_Uploads (
	ContractUploadId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmploymentTypeId int NULL,
	StartDate nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EndDate nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Duration AS (datediff(month,[StartDate],[EndDate])/(12)),
	Expired bit NULL,
	Confirmed bit NULL,
	CONSTRAINT PK_Contracts_Uploads PRIMARY KEY (ContractUploadId)
);
