-- HRMIS.dbo.ACC0018 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0018;

CREATE TABLE HRMIS.dbo.ACC0018 (
	PayFrequencyId int IDENTITY(1,1) NOT NULL,
	PayFrequency nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0018 PRIMARY KEY (PayFrequencyId)
);
