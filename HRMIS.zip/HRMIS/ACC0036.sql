-- HRMIS.dbo.ACC0036 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0036;

CREATE TABLE HRMIS.dbo.ACC0036 (
	EmpCourseId int IDENTITY(1,1) NOT NULL,
	Course nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EducationLevelId int NULL,
	InstitutionId int NULL,
	ECFrom date NULL,
	ECTo date NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Grade nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Points nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Ranking int NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0036 PRIMARY KEY (EmpCourseId)
);
