-- HRMIS.dbo.ACC0215 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0215;

CREATE TABLE HRMIS.dbo.ACC0215 (
	SheduledTerminationId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	TypeOfTerminationId int NULL,
	TerminationReason nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EligibleForRehire bit DEFAULT 0 NULL,
	DateEmployed date NULL,
	TerminationDate date NULL,
	LastWorkDay date NULL,
	FurtherReasons nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cleared bit DEFAULT 0 NULL,
	ExitInterviewCompleted bit DEFAULT 0 NULL,
	TerminationLetter nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ClearanceLetter nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ServiceLetter nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LeaveDaysBalance AS ([dbo].[fGetLeavePayDays]([EmpId])),
	LeaveConvertibleAmount decimal(18,2) DEFAULT 0 NULL,
	PayrollLiability decimal(18,2) DEFAULT 0 NULL,
	NoticePay decimal(18,2) DEFAULT 0 NULL,
	NoticeGiven bit DEFAULT 0 NULL,
	NoticePeriod nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	GratuityAwarded decimal(18,2) DEFAULT 0 NULL,
	Debts decimal(18,2) DEFAULT 0 NULL,
	Payables decimal(18,2) DEFAULT 0 NULL,
	OtherPayables decimal(18,2) DEFAULT 0 NULL,
	Refunds decimal(18,2) DEFAULT 0 NULL,
	OtherLiability decimal(18,2) DEFAULT 0 NULL,
	NetDebts AS (([PayrollLiability]+[OtherLiability])+[Debts]),
	NetPayables AS ((((([LeaveConvertibleAmount]+[NoticePay])+[GratuityAwarded])+[OtherPayables])+[Refunds])+[Payables]),
	NetAmount AS ((((([LeaveConvertibleAmount]+[NoticePay])+[GratuityAwarded])+[OtherPayables])+[Refunds])-(([PayrollLiability]+[OtherLiability])+[Debts])),
	Comments nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Approved bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0215 PRIMARY KEY (SheduledTerminationId)
);
