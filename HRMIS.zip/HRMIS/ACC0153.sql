-- HRMIS.dbo.ACC0153 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0153;

CREATE TABLE HRMIS.dbo.ACC0153 (
	InsuranceId int IDENTITY(1,1) NOT NULL,
	SysDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0153 PRIMARY KEY (InsuranceId)
);
