-- HRMIS.dbo.ACC0113 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0113;

CREATE TABLE HRMIS.dbo.ACC0113 (
	NewsId int IDENTITY(1,1) NOT NULL,
	Event nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Venue nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date DEFAULT getdate() NULL,
	IsOffDay bit DEFAULT 0 NULL,
	Details text COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	Active bit NULL,
	CONSTRAINT PK_ACC0113 PRIMARY KEY (NewsId)
);
