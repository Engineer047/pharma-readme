-- HRMIS.dbo.ACC0193 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0193;

CREATE TABLE HRMIS.dbo.ACC0193 (
	OtherInfoId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NOT NULL,
	EmpId int NOT NULL,
	OtherInfo nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0193 PRIMARY KEY (OtherInfoId,AppraisalId,EmpId),
	CONSTRAINT FK_ACC0193_ACC0188 FOREIGN KEY (AppraisalId,EmpId) REFERENCES HRMIS.dbo.ACC0188(AppraisalId,EmpId)
);
