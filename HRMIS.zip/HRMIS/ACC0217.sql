-- HRMIS.dbo.ACC0217 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0217;

CREATE TABLE HRMIS.dbo.ACC0217 (
	ActingAppointmentId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	PositionHolderId int NULL,
	BranchId int NULL,
	DepartmentId int NULL,
	JobTitleId int NULL,
	ActingAllowance decimal(18,2) NULL,
	DocumentURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StartDate date NULL,
	EndDate date NULL,
	Posted bit DEFAULT 0 NULL,
	Complete AS ([dbo].[GetActingAppointmentStatus]([EmpId])),
	CONSTRAINT PK_ACC0217 PRIMARY KEY (ActingAppointmentId)
);
