-- HRMIS.dbo.ACC0108 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0108;

CREATE TABLE HRMIS.dbo.ACC0108 (
	NHIFBracketId int IDENTITY(1,1) NOT NULL,
	Rangefrom decimal(18,2) NOT NULL,
	Rangeto decimal(18,2) NOT NULL,
	Amount decimal(18,2) NULL,
	Rate decimal(18,2) NULL,
	CONSTRAINT PK_ACC0108 PRIMARY KEY (NHIFBracketId)
);
