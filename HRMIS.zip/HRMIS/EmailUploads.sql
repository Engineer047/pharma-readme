-- HRMIS.dbo.EmailUploads definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EmailUploads;

CREATE TABLE HRMIS.dbo.EmailUploads (
	EmailUploadId int IDENTITY(1,1) NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmailAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_EmailUploads PRIMARY KEY (EmailUploadId)
);
