-- HRMIS.dbo.ACC0128 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0128;

CREATE TABLE HRMIS.dbo.ACC0128 (
	Id int IDENTITY(1,1) NOT NULL,
	PAYE decimal(18,2) NULL,
	PAYEInterest decimal(18,2) NULL,
	[Others] decimal(18,2) NULL,
	CONSTRAINT PK_ACC0121 PRIMARY KEY (Id)
);
