-- HRMIS.dbo.ACC0223 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0223;

CREATE TABLE HRMIS.dbo.ACC0223 (
	SuccessionRiskImpactId int IDENTITY(1,1) NOT NULL,
	SuccessionRiskImpact nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0223 PRIMARY KEY (SuccessionRiskImpactId)
);
