-- HRMIS.dbo.ACC01062 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC01062;

CREATE TABLE HRMIS.dbo.ACC01062 (
	EmpBiometricAttId int IDENTITY(1,1) NOT NULL,
	DateAtt date NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TimeIn datetime NULL,
	TimeOut datetime NULL,
	Cancelled bit NULL,
	ShiftId int NULL,
	CONSTRAINT PK_ACC01062 PRIMARY KEY (EmpBiometricAttId)
);
