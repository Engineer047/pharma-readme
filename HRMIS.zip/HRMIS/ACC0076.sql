-- HRMIS.dbo.ACC0076 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0076;

CREATE TABLE HRMIS.dbo.ACC0076 (
	LoanApplicationId int IDENTITY(1,1) NOT NULL,
	Amount float NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Status nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Completed bit NULL,
	Processing bit NULL,
	Declined bit NULL,
	CONSTRAINT PK_ACC0076 PRIMARY KEY (LoanApplicationId)
);
