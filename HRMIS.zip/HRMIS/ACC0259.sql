-- HRMIS.dbo.ACC0259 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0259;

CREATE TABLE HRMIS.dbo.ACC0259 (
	ResponsibilityCategoryId int IDENTITY(1,1) NOT NULL,
	ResponsibilityCategory nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0259 PRIMARY KEY (ResponsibilityCategoryId)
);
