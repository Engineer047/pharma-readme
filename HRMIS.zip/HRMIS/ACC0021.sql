-- HRMIS.dbo.ACC0021 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0021;

CREATE TABLE HRMIS.dbo.ACC0021 (
	PaymentModeId int IDENTITY(1,1) NOT NULL,
	PaymentMode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0021 PRIMARY KEY (PaymentModeId)
);
