-- HRMIS.dbo.ACC0225 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0225;

CREATE TABLE HRMIS.dbo.ACC0225 (
	DependantId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	DependantName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateOfBirth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Relationship nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cellphone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhotoUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0225 PRIMARY KEY (DependantId)
);
