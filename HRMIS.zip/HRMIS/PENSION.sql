-- HRMIS.dbo.PENSION definition

-- Drop table

-- DROP TABLE HRMIS.dbo.PENSION;

CREATE TABLE HRMIS.dbo.PENSION (
	EMPNO nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PENSION decimal(18,2) NULL,
	EMPID int NULL
);
