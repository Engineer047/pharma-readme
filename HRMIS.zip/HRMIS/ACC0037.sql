-- HRMIS.dbo.ACC0037 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0037;

CREATE TABLE HRMIS.dbo.ACC0037 (
	OrganizationId int IDENTITY(1,1) NOT NULL,
	Organization nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhysicalAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cellphone nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContactPerson nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0037 PRIMARY KEY (OrganizationId)
);
