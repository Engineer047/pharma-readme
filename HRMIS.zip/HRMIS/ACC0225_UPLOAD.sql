-- HRMIS.dbo.ACC0225_UPLOAD definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0225_UPLOAD;

CREATE TABLE HRMIS.dbo.ACC0225_UPLOAD (
	DependantId int IDENTITY(1,1) NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DependantName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateOfBirth nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Relationship nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cellphone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Confirmed bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0225_UPLOAD PRIMARY KEY (DependantId)
);
