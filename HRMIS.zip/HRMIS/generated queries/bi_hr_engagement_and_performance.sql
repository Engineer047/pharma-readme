/*
bi_hr_engagement_and_performance

Purpose:
- Performance ratings distribution
- Employee satisfaction (if survey data is available)
- High vs low performer retention

Design note:
- Grain is one row per employee appraisal activity record
- Appraisal activity is anchored on distinct employee-appraisal pairs across assignment, KPI, competency, feedback, and final-score tables
- Final performance scoring is left joined so appraisal activity still appears even when final scores are not yet posted
- Retention is evaluated against the employee''s current active status
- Appraisal summary context borrows native HRMIS appraisal-report and competency-rollup structures
- Satisfaction score is left NULL because the supplied HRMIS DDL exposes feedback text but no numeric satisfaction survey scale
- This avoids repeating period-level rates across detail rows and helps prevent inflated reporting

Assumptions:
- The activity anchor is the distinct employee-appraisal footprint across appraisal-related tables
- Final-score fields stay NULL when appraisal activity exists but dbo.ACC0207 has not been posted
- Final score = AgreedActivitities + Competencies
- Retained = employee is currently active and not terminated as of today
- High/Low performer band is derived from final score and final rating text
- Satisfaction response counts use available feedback/comment tables, but no numeric satisfaction score is fabricated

SQL Server note:
- This script avoids GO because some clients send GO directly to SQL Server
*/

IF OBJECT_ID('dbo.bi_hr_engagement_and_performance', 'V') IS NOT NULL
    EXEC(N'DROP VIEW dbo.bi_hr_engagement_and_performance;');

EXEC(N'
CREATE VIEW dbo.bi_hr_engagement_and_performance
AS
WITH EmployeeBase AS (
    SELECT
        E.EmpId,
        E.EmpNo,
        LTRIM(RTRIM(
            ISNULL(E.FirstName + '' '', '''')
            + ISNULL(E.MiddleName + '' '', '''')
            + ISNULL(E.LastName, '''')
        )) AS EmployeeName,
        E.CompanyId,
        E.BranchId,
        E.DepartmentId,
        E.JobTitleId,
        E.EmploymentTypeID AS StaffCategoryId,
        CAST(COALESCE(E.ED, E.ED01) AS date) AS HireDate,
        CAST(E.TerminationDate AS date) AS TerminationDate,
        CASE
            WHEN ISNULL(E.Active, 0) = 1
                 AND (E.TerminationDate IS NULL OR E.TerminationDate > CAST(GETDATE() AS date))
                THEN 1
            ELSE 0
        END AS CurrentActiveFlag
    FROM dbo.ACC0001 AS E
),
AppraisalActivitySeed AS (
    SELECT
        EP.PeriodId AS AppraisalId,
        EP.EmpId
    FROM dbo.EmpAppraisalPeriod AS EP
    WHERE EP.PeriodId IS NOT NULL
      AND EP.EmpId IS NOT NULL

    UNION

    SELECT
        EA.PeriodId AS AppraisalId,
        EA.EmpId
    FROM dbo.EMPAPPRAISALS AS EA
    WHERE EA.PeriodId IS NOT NULL
      AND EA.EmpId IS NOT NULL

    UNION

    SELECT
        AC.AppraisalId,
        AC.EmpId
    FROM dbo.ACC0202 AS AC
    WHERE AC.AppraisalId IS NOT NULL
      AND AC.EmpId IS NOT NULL

    UNION

    SELECT
        AFB.AppraisalId,
        AFB.EmpId
    FROM dbo.ACC0194 AS AFB
    WHERE AFB.AppraisalId IS NOT NULL
      AND AFB.EmpId IS NOT NULL

    UNION

    SELECT
        APF.AppraisalId,
        APF.EmpId
    FROM dbo.ACC0206 AS APF
    WHERE APF.AppraisalId IS NOT NULL
      AND APF.EmpId IS NOT NULL

    UNION

    SELECT
        FS.AppraisalId,
        FS.EmpId
    FROM dbo.ACC0207 AS FS
    WHERE FS.AppraisalId IS NOT NULL
      AND FS.EmpId IS NOT NULL
),
AppraisalActivity AS (
    SELECT
        AAS.AppraisalId,
        AAS.EmpId
    FROM AppraisalActivitySeed AS AAS
    GROUP BY
        AAS.AppraisalId,
        AAS.EmpId
),
FinalScoreBase AS (
    SELECT
        AF.AppraisalFinalScoresId,
        AF.AppraisalId,
        AF.EmpId,
        CAST(ISNULL(AF.AgreedActivitities, 0) AS decimal(18, 2)) AS AgreedActivitiesScore,
        CAST(ISNULL(AF.Competencies, 0) AS decimal(18, 2)) AS CompetenciesScore,
        CAST(ISNULL(AF.AgreedActivitities, 0) + ISNULL(AF.Competencies, 0) AS decimal(18, 2)) AS FinalScore,
        AF.FinalScoreRatingId,
        AF.Remarks,
        R.Rate AS FinalRating,
        R.Value AS FinalRatingValue,
        R.Description AS FinalRatingDescription,
        ROW_NUMBER() OVER (
            PARTITION BY AF.AppraisalId, AF.EmpId
            ORDER BY AF.AppraisalFinalScoresId DESC
        ) AS RN
    FROM dbo.ACC0207 AS AF
    LEFT JOIN dbo.ACC0200 AS R
        ON AF.FinalScoreRatingId = R.RatingId
    WHERE AF.EmpId IS NOT NULL
      AND AF.AppraisalId IS NOT NULL
),
FinalScoreLatest AS (
    SELECT
        FSB.AppraisalFinalScoresId,
        FSB.AppraisalId,
        FSB.EmpId,
        FSB.AgreedActivitiesScore,
        FSB.CompetenciesScore,
        FSB.FinalScore,
        FSB.FinalScoreRatingId,
        FSB.Remarks,
        FSB.FinalRating,
        FSB.FinalRatingValue,
        FSB.FinalRatingDescription
    FROM FinalScoreBase AS FSB
    WHERE FSB.RN = 1
),
AppraisalContext AS (
    SELECT
        FSL.AppraisalFinalScoresId,
        AA.AppraisalId,
        AP.AppraisalPeriodName,
        AP.AppraisalStartDate,
        AP.AppraisalEndDate,
        AA.EmpId,
        FSL.AgreedActivitiesScore,
        FSL.CompetenciesScore,
        FSL.FinalScore,
        FSL.FinalScoreRatingId,
        FSL.FinalRating,
        FSL.FinalRatingValue,
        FSL.FinalRatingDescription,
        FSL.Remarks
    FROM AppraisalActivity AS AA
    LEFT JOIN dbo.ACC0198 AS AP
        ON AA.AppraisalId = AP.AppraisalId
    LEFT JOIN FinalScoreLatest AS FSL
        ON AA.AppraisalId = FSL.AppraisalId
       AND AA.EmpId = FSL.EmpId
),
AppraisalReportRollup AS (
    SELECT
        AR.PeriodId AS AppraisalId,
        AR.EmpId,
        MAX(CASE WHEN NULLIF(LTRIM(RTRIM(AR.ManFinalComments)), '''') IS NOT NULL THEN 1 ELSE 0 END) AS ManagerFinalCommentFlag,
        MAX(CASE WHEN NULLIF(LTRIM(RTRIM(AR.EmpFinalComments)), '''') IS NOT NULL THEN 1 ELSE 0 END) AS EmployeeFinalCommentFlag,
        MAX(CAST(ISNULL(AR.TotalLineScore, 0) AS decimal(18, 2))) AS TotalLineScore,
        MAX(CAST(ISNULL(AR.TotalSelfLineScore, 0) AS decimal(18, 2))) AS TotalSelfLineScore
    FROM dbo.vwAppraisalReport AS AR
    GROUP BY
        AR.PeriodId,
        AR.EmpId
),
AppraisalCompetencyRollup AS (
    SELECT
        AC.AppraisalId,
        AC.EmpId,
        COUNT(*) AS CompetencyItemCount,
        CAST(SUM(ISNULL(AC.Score, 0)) AS decimal(18, 2)) AS CompetencyScoreAchieved,
        CAST(SUM(ISNULL(AC.OutOf, 0)) AS decimal(18, 2)) AS CompetencyScorePossible
    FROM dbo.vwAppraisalCompetency AS AC
    GROUP BY
        AC.AppraisalId,
        AC.EmpId
),
AppraisalFeedback AS (
    SELECT
        A.AppraisalId,
        A.EmpId,
        COUNT(*) AS AppraiseeFeedbackCount
    FROM dbo.ACC0194 AS A
    GROUP BY
        A.AppraisalId,
        A.EmpId
),
AppraiserFeedback AS (
    SELECT
        A.AppraisalId,
        A.EmpId,
        COUNT(*) AS AppraiserFeedbackCount
    FROM dbo.ACC0206 AS A
    GROUP BY
        A.AppraisalId,
        A.EmpId
),
GeneralFeedbackByPeriod AS (
    SELECT
        ACX.AppraisalId,
        ACX.EmpId,
        COUNT(*) AS GeneralFeedbackCount
    FROM AppraisalContext AS ACX
    INNER JOIN (
        SELECT
            F.EmpId,
            CAST(F.SystemLog AS datetime) AS FeedbackDate
        FROM dbo.ACC0078 AS F
        WHERE F.EmpId IS NOT NULL

        UNION ALL

        SELECT
            F.EmpId,
            CAST(COALESCE(CAST(F.[Date] AS datetime), F.SystemLog) AS datetime) AS FeedbackDate
        FROM dbo.ACC0110 AS F
        WHERE F.EmpId IS NOT NULL
    ) AS FB
        ON ACX.EmpId = FB.EmpId
       AND (
            (ACX.AppraisalStartDate IS NOT NULL AND ACX.AppraisalEndDate IS NOT NULL AND CAST(FB.FeedbackDate AS date) BETWEEN ACX.AppraisalStartDate AND ACX.AppraisalEndDate)
            OR (ACX.AppraisalStartDate IS NOT NULL AND ACX.AppraisalEndDate IS NULL AND CAST(FB.FeedbackDate AS date) >= ACX.AppraisalStartDate)
            OR (ACX.AppraisalStartDate IS NULL AND ACX.AppraisalEndDate IS NOT NULL AND CAST(FB.FeedbackDate AS date) <= ACX.AppraisalEndDate)
       )
    GROUP BY
        ACX.AppraisalId,
        ACX.EmpId
)
SELECT
    ACX.AppraisalFinalScoresId,
    ACX.AppraisalId,
    ACX.AppraisalPeriodName,
    ACX.AppraisalStartDate,
    ACX.AppraisalEndDate,
    ACX.EmpId,
    EB.EmpNo,
    COALESCE(NULLIF(EB.EmployeeName, ''''), EB.EmpNo) AS EmployeeName,
    EB.CompanyId,
    COALESCE(C.Name, ''Unassigned'') AS Company,
    EB.BranchId,
    COALESCE(B.Name, ''Unassigned'') AS Branch,
    EB.DepartmentId,
    COALESCE(D.Name, ''Unassigned'') AS Department,
    EB.JobTitleId,
    COALESCE(J.JobTitle, ''Unassigned'') AS Role,
    EB.StaffCategoryId,
    COALESCE(ET.EmploymentType, ''Unassigned'') AS StaffCategory,
    ACX.AgreedActivitiesScore,
    ACX.CompetenciesScore,
    ACX.FinalScore,
    ACX.FinalScoreRatingId,
    COALESCE(ACX.FinalRating, ''Unrated'') AS FinalRating,
    ACX.FinalRatingValue,
    ACX.FinalRatingDescription,
    CASE
        WHEN ACX.FinalScore IS NULL
             AND ACX.FinalScoreRatingId IS NULL
             AND NULLIF(LTRIM(RTRIM(COALESCE(ACX.FinalRating, ''''))), '''') IS NULL
             AND NULLIF(LTRIM(RTRIM(COALESCE(ACX.FinalRatingValue, ''''))), '''') IS NULL
             AND NULLIF(LTRIM(RTRIM(COALESCE(ACX.FinalRatingDescription, ''''))), '''') IS NULL
            THEN ''Unrated''
        WHEN
            ACX.FinalScore >= 80
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%excellent%''
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%outstanding%''
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%very good%''
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%high%''
            THEN ''High Performer''
        WHEN
            ACX.FinalScore < 60
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%poor%''
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%unsatisfactory%''
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%needs improvement%''
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%below%''
            OR LOWER(COALESCE(ACX.FinalRating, '''') + '' '' + COALESCE(ACX.FinalRatingValue, '''') + '' '' + COALESCE(ACX.FinalRatingDescription, '''')) LIKE ''%low%''
            THEN ''Low Performer''
        ELSE ''Mid Performer''
    END AS PerformerBand,
    CAST(1 AS int) AS PerformanceRecordFlag,
    EB.CurrentActiveFlag AS RetainedFlag,
    CASE WHEN EB.CurrentActiveFlag = 1 THEN ''Retained'' ELSE ''Exited'' END AS RetentionStatus,
    EB.TerminationDate,
    ISNULL(ARR.ManagerFinalCommentFlag, 0) AS ManagerFinalCommentFlag,
    ISNULL(ARR.EmployeeFinalCommentFlag, 0) AS EmployeeFinalCommentFlag,
    CAST(ISNULL(ARR.TotalLineScore, 0) AS decimal(18, 2)) AS TotalLineScore,
    CAST(ISNULL(ARR.TotalSelfLineScore, 0) AS decimal(18, 2)) AS TotalSelfLineScore,
    ISNULL(ACR.CompetencyItemCount, 0) AS CompetencyItemCount,
    CAST(ISNULL(ACR.CompetencyScoreAchieved, 0) AS decimal(18, 2)) AS CompetencyScoreAchieved,
    CAST(ISNULL(ACR.CompetencyScorePossible, 0) AS decimal(18, 2)) AS CompetencyScorePossible,
    ISNULL(AFDB.AppraiseeFeedbackCount, 0) AS AppraiseeFeedbackCount,
    ISNULL(APFDB.AppraiserFeedbackCount, 0) AS AppraiserFeedbackCount,
    ISNULL(GFDB.GeneralFeedbackCount, 0) AS GeneralFeedbackCount,
    ISNULL(AFDB.AppraiseeFeedbackCount, 0)
        + ISNULL(APFDB.AppraiserFeedbackCount, 0)
        + ISNULL(GFDB.GeneralFeedbackCount, 0) AS SatisfactionResponseCount,
    CAST(NULL AS decimal(18, 2)) AS EmployeeSatisfactionScore,
    CAST(0 AS int) AS SatisfactionScoreAvailableFlag,
    ACX.Remarks
FROM AppraisalContext AS ACX
INNER JOIN EmployeeBase AS EB
    ON ACX.EmpId = EB.EmpId
LEFT JOIN dbo.ACC0002 AS C
    ON EB.CompanyId = C.CompanyId
LEFT JOIN dbo.ACC0004 AS B
    ON EB.CompanyId = B.CompanyId
   AND EB.BranchId = B.BranchId
LEFT JOIN dbo.ACC0006 AS D
    ON EB.DepartmentId = D.DepartmentId
LEFT JOIN dbo.ACC0010 AS J
    ON EB.JobTitleId = J.JobTitleId
LEFT JOIN dbo.ACC0009 AS ET
    ON EB.StaffCategoryId = ET.EmploymentTypeId
LEFT JOIN AppraisalReportRollup AS ARR
    ON ACX.AppraisalId = ARR.AppraisalId
   AND ACX.EmpId = ARR.EmpId
LEFT JOIN AppraisalCompetencyRollup AS ACR
    ON ACX.AppraisalId = ACR.AppraisalId
   AND ACX.EmpId = ACR.EmpId
LEFT JOIN AppraisalFeedback AS AFDB
    ON ACX.AppraisalId = AFDB.AppraisalId
   AND ACX.EmpId = AFDB.EmpId
LEFT JOIN AppraiserFeedback AS APFDB
    ON ACX.AppraisalId = APFDB.AppraisalId
   AND ACX.EmpId = APFDB.EmpId
LEFT JOIN GeneralFeedbackByPeriod AS GFDB
    ON ACX.AppraisalId = GFDB.AppraisalId
   AND ACX.EmpId = GFDB.EmpId;
');
