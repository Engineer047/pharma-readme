/*
bi_hr_learning_and_development

Purpose:
- Training hours per employee
- Training spend per employee
- Promotion rate (internal mobility support)
- Skills coverage (who is trained in what)

Design note:
- Grain is one row per employee, period type, and period start date
- Training records borrow native HRMIS training join structures from dbo.vcoursetraining and dbo.vCourseModules, then normalize to employee-event grain before aggregation
- Mobility events are normalized separately before aggregation
- Current skills are aggregated separately and joined only once per employee
- This avoids inflating training hours/spend when employees have multiple skills or multiple mobility records

Assumptions:
- A reportable training event is an approved dbo.vcoursetraining / dbo.ACC0030 record
- Training event period is based on the event start date
- Training hours are derived as inclusive training days * 8 hours because the supplied HRMIS DDL does not expose a dedicated training-hours field
- Training spend is derived from dbo.vCourseModules.Cost via module id
- Internal mobility and promotion events come from approved, non-cancelled dbo.ACC0219 records
- Promotion rate should be calculated in Power BI as SUM(PromotionFlag) / SUM(EmployeeHeadcountFlag) for the selected period
- Skills coverage is current-state coverage from dbo.ACC0254 / dbo.ACC0032 and is repeated across periods by design

SQL Server note:
- This script avoids GO because some clients send GO directly to SQL Server
*/

IF OBJECT_ID('dbo.bi_hr_learning_and_development', 'V') IS NOT NULL
    EXEC(N'DROP VIEW dbo.bi_hr_learning_and_development;');

EXEC(N'
CREATE VIEW dbo.bi_hr_learning_and_development
AS
WITH EmployeeBase AS (
    SELECT
        E.EmpId,
        E.EmpNo,
        LTRIM(RTRIM(
            ISNULL(E.FirstName + '' '', '''')
            + ISNULL(E.MiddleName + '' '', '''')
            + ISNULL(E.LastName, '''')
        )) AS EmployeeName,
        E.CompanyId,
        E.BranchId,
        E.DepartmentId,
        E.JobTitleId,
        E.EmploymentTypeID AS StaffCategoryId,
        CAST(COALESCE(E.ED, E.ED01) AS date) AS HireDate,
        CAST(E.TerminationDate AS date) AS ExitDate
    FROM dbo.ACC0001 AS E
    WHERE COALESCE(E.ED, E.ED01) IS NOT NULL
      AND COALESCE(E.ED, E.ED01) <= CAST(GETDATE() AS date)
),
TrainingEvents AS (
    SELECT
        CT.EmpCoursesId,
        CT.EmpId,
        CAST(COALESCE(CT.ECFrom, TP.TrainingStartDate, CAST(T.SystemLog AS date)) AS date) AS EventStartDate,
        CAST(
            COALESCE(
                CT.ECTo,
                TP.TrainingEndDate,
                CT.ECFrom,
                TP.TrainingStartDate,
                CAST(T.SystemLog AS date)
            ) AS date
        ) AS EventEndDate,
        COALESCE(CM.Course, CT.Course, ''Unassigned'') AS Course,
        COALESCE(CM.Module, ''Unassigned'') AS Module,
        COALESCE(CT.TrainingPeriodName, ''Unassigned'') AS TrainingPeriodName,
        COALESCE(CT.Trainer, ''Unassigned'') AS Trainer,
        CASE WHEN ISNULL(CT.Approved, 1) = 1 THEN 1 ELSE 0 END AS ApprovedFlag,
        CASE WHEN ISNULL(CT.Completed, 0) = 1 THEN 1 ELSE 0 END AS CompletedFlag,
        CAST(ISNULL(CM.Cost, 0) AS decimal(18, 2)) AS TrainingSpend
    FROM dbo.vcoursetraining AS CT
    INNER JOIN dbo.ACC0030 AS T
        ON CT.EmpCoursesId = T.EmpCoursesId
    LEFT JOIN dbo.ACC0203 AS TP
        ON CT.TrainingId = TP.TrainingId
    LEFT JOIN dbo.vCourseModules AS CM
        ON CT.ModuleId = CM.CourseModuleId
    WHERE CT.EmpId IS NOT NULL
      AND COALESCE(CT.ECFrom, TP.TrainingStartDate, CAST(T.SystemLog AS date)) IS NOT NULL
),
TrainingEventsNormalized AS (
    SELECT
        TE.EmpCoursesId,
        TE.EmpId,
        TE.EventStartDate,
        TE.EventEndDate,
        TE.Course,
        TE.Module,
        TE.TrainingPeriodName,
        TE.Trainer,
        TE.ApprovedFlag,
        TE.CompletedFlag,
        CASE
            WHEN TE.EventEndDate >= TE.EventStartDate
                THEN DATEDIFF(DAY, TE.EventStartDate, TE.EventEndDate) + 1
            ELSE 1
        END AS DurationDays,
        CAST(
            CASE
                WHEN TE.EventEndDate >= TE.EventStartDate
                    THEN (DATEDIFF(DAY, TE.EventStartDate, TE.EventEndDate) + 1) * 8.0
                ELSE 8.0
            END
            AS decimal(18, 2)
        ) AS TrainingHours,
        TE.TrainingSpend
    FROM TrainingEvents AS TE
    WHERE TE.ApprovedFlag = 1
),
MobilityEvents AS (
    SELECT
        MT.EmpTransfersId,
        MT.EmpId,
        CAST(MT.StartDate AS date) AS EventDate,
        COALESCE(LTRIM(RTRIM(TT.TransferType)), ''Unassigned'') AS TransferType,
        MT.TransferReason,
        MT.Narrative,
        CASE
            WHEN
                (
                    ISNULL(MT.CompanyId, -1) <> ISNULL(MT.DestinationCompanyId, -1)
                    OR ISNULL(MT.BranchId, -1) <> ISNULL(MT.DestinationBranchId, -1)
                    OR ISNULL(MT.OfficeId, -1) <> ISNULL(MT.DestinationOfficeId, -1)
                    OR ISNULL(MT.DivisionId, -1) <> ISNULL(MT.DestinationDivisionId, -1)
                    OR ISNULL(MT.Deptid, -1) <> ISNULL(MT.DestinationDeptId, -1)
                    OR ISNULL(MT.SectionId, -1) <> ISNULL(MT.DestinationSectionId, -1)
                    OR ISNULL(MT.JobTitleId, -1) <> ISNULL(MT.DestinationJobTitleId, -1)
                    OR ISNULL(MT.JobGroupId, -1) <> ISNULL(MT.DestinationJobGroupId, -1)
                    OR ISNULL(MT.JobGradeId, -1) <> ISNULL(MT.DestinationJobGradeId, -1)
                    OR ISNULL(MT.BasicSalary, 0) <> ISNULL(MT.DestinationBasicSalary, 0)
                )
                THEN 1
            ELSE 0
        END AS InternalMobilityFlag,
        CASE
            WHEN
                (
                    ISNULL(MT.CompanyId, -1) <> ISNULL(MT.DestinationCompanyId, -1)
                    OR ISNULL(MT.BranchId, -1) <> ISNULL(MT.DestinationBranchId, -1)
                    OR ISNULL(MT.OfficeId, -1) <> ISNULL(MT.DestinationOfficeId, -1)
                    OR ISNULL(MT.DivisionId, -1) <> ISNULL(MT.DestinationDivisionId, -1)
                    OR ISNULL(MT.Deptid, -1) <> ISNULL(MT.DestinationDeptId, -1)
                    OR ISNULL(MT.SectionId, -1) <> ISNULL(MT.DestinationSectionId, -1)
                    OR ISNULL(MT.JobTitleId, -1) <> ISNULL(MT.DestinationJobTitleId, -1)
                    OR ISNULL(MT.JobGroupId, -1) <> ISNULL(MT.DestinationJobGroupId, -1)
                    OR ISNULL(MT.JobGradeId, -1) <> ISNULL(MT.DestinationJobGradeId, -1)
                    OR ISNULL(MT.BasicSalary, 0) <> ISNULL(MT.DestinationBasicSalary, 0)
                )
                AND
                (
                    LOWER(COALESCE(TT.TransferType, '''') + '' '' + COALESCE(MT.TransferReason, '''') + '' '' + COALESCE(MT.Narrative, '''')) LIKE ''%promot%''
                    OR ISNULL(MT.DestinationBasicSalary, 0) > ISNULL(MT.BasicSalary, 0)
                    OR (MT.DestinationJobTitleId IS NOT NULL AND ISNULL(MT.DestinationJobTitleId, -1) <> ISNULL(MT.JobTitleId, -1))
                    OR (MT.DestinationJobGroupId IS NOT NULL AND ISNULL(MT.DestinationJobGroupId, -1) <> ISNULL(MT.JobGroupId, -1))
                    OR (MT.DestinationJobGradeId IS NOT NULL AND ISNULL(MT.DestinationJobGradeId, -1) <> ISNULL(MT.JobGradeId, -1))
                )
                THEN 1
            ELSE 0
        END AS PromotionFlag
    FROM dbo.ACC0219 AS MT
    LEFT JOIN dbo.ACC0218 AS TT
        ON MT.TransferTypeId = TT.TransferTypeId
    WHERE MT.EmpId IS NOT NULL
      AND MT.StartDate IS NOT NULL
      AND ISNULL(MT.Approved, 0) = 1
      AND ISNULL(MT.Cancelled, 0) = 0
),
SkillsCurrent AS (
    SELECT
        ES.EmpId,
        COUNT(DISTINCT ES.SkilIsd) AS SkillCount,
        STUFF((
            SELECT DISTINCT
                '', '' + COALESCE(S2.Skill, ''Unassigned'')
            FROM dbo.ACC0254 AS ES2
            LEFT JOIN dbo.ACC0032 AS S2
                ON ES2.SkilIsd = S2.SkillsId
            WHERE ES2.EmpId = ES.EmpId
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''nvarchar(max)''), 1, 2, '''') AS SkillsList,
        STUFF((
            SELECT DISTINCT
                '', '' + COALESCE(SC2.SkillCategory, ''Unassigned'')
            FROM dbo.ACC0254 AS ES2
            LEFT JOIN dbo.ACC0251 AS SC2
                ON ES2.SkillCategoryId = SC2.SkillCategoryId
            WHERE ES2.EmpId = ES.EmpId
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''nvarchar(max)''), 1, 2, '''') AS SkillCategoriesList
    FROM dbo.ACC0254 AS ES
    GROUP BY ES.EmpId
),
DateBounds AS (
    SELECT
        COALESCE(
            MIN(D.EventMonth),
            DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        ) AS MinMonth,
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1) AS MaxMonth
    FROM (
        SELECT DATEFROMPARTS(YEAR(EB.HireDate), MONTH(EB.HireDate), 1) AS EventMonth
        FROM EmployeeBase AS EB

        UNION ALL

        SELECT DATEFROMPARTS(YEAR(TE.EventStartDate), MONTH(TE.EventStartDate), 1) AS EventMonth
        FROM TrainingEventsNormalized AS TE

        UNION ALL

        SELECT DATEFROMPARTS(YEAR(ME.EventDate), MONTH(ME.EventDate), 1) AS EventMonth
        FROM MobilityEvents AS ME
    ) AS D
),
Numbers AS (
    SELECT TOP (2400)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Num
    FROM sys.all_objects AS A
    CROSS JOIN sys.all_objects AS B
),
MonthCalendar AS (
    SELECT
        CAST(DATEADD(MONTH, N.Num, DB.MinMonth) AS date) AS MonthStart
    FROM DateBounds AS DB
    INNER JOIN Numbers AS N
        ON N.Num <= DATEDIFF(MONTH, DB.MinMonth, DB.MaxMonth)
),
Periods AS (
    SELECT
        CAST(''Monthly'' AS varchar(20)) AS PeriodType,
        MC.MonthStart AS PeriodStartDate,
        CAST(EOMONTH(MC.MonthStart) AS date) AS PeriodEndDate,
        YEAR(MC.MonthStart) AS CalendarYear,
        DATEPART(QUARTER, MC.MonthStart) AS CalendarQuarter,
        MONTH(MC.MonthStart) AS CalendarMonth,
        DATENAME(MONTH, MC.MonthStart) AS MonthName,
        CONVERT(char(7), MC.MonthStart, 120) AS PeriodLabel
    FROM MonthCalendar AS MC

    UNION ALL

    SELECT
        CAST(''Quarterly'' AS varchar(20)) AS PeriodType,
        Q.QuarterStart AS PeriodStartDate,
        CAST(EOMONTH(DATEADD(MONTH, 2, Q.QuarterStart)) AS date) AS PeriodEndDate,
        YEAR(Q.QuarterStart) AS CalendarYear,
        DATEPART(QUARTER, Q.QuarterStart) AS CalendarQuarter,
        CAST(NULL AS int) AS CalendarMonth,
        CAST(NULL AS varchar(20)) AS MonthName,
        CAST(CAST(YEAR(Q.QuarterStart) AS varchar(4)) + '' Q'' + CAST(DATEPART(QUARTER, Q.QuarterStart) AS varchar(1)) AS varchar(20)) AS PeriodLabel
    FROM (
        SELECT DISTINCT
            CAST(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, MC.MonthStart), 0) AS date) AS QuarterStart
        FROM MonthCalendar AS MC
    ) AS Q
),
EmployeePeriods AS (
    SELECT
        P.PeriodType,
        P.PeriodStartDate,
        P.PeriodEndDate,
        P.CalendarYear,
        P.CalendarQuarter,
        P.CalendarMonth,
        P.MonthName,
        P.PeriodLabel,
        EB.EmpId,
        EB.EmpNo,
        EB.EmployeeName,
        EB.CompanyId,
        EB.BranchId,
        EB.DepartmentId,
        EB.JobTitleId,
        EB.StaffCategoryId
    FROM Periods AS P
    INNER JOIN EmployeeBase AS EB
        ON EB.HireDate <= P.PeriodEndDate
       AND (EB.ExitDate IS NULL OR EB.ExitDate >= P.PeriodStartDate)
)
SELECT
    EP.PeriodType,
    EP.PeriodStartDate,
    EP.PeriodEndDate,
    EP.CalendarYear,
    EP.CalendarQuarter,
    EP.CalendarMonth,
    EP.MonthName,
    EP.PeriodLabel,
    EP.EmpId,
    EP.EmpNo,
    COALESCE(NULLIF(EP.EmployeeName, ''''), EP.EmpNo) AS EmployeeName,
    EP.CompanyId,
    COALESCE(C.Name, ''Unassigned'') AS Company,
    EP.BranchId,
    COALESCE(B.Name, ''Unassigned'') AS Branch,
    EP.DepartmentId,
    COALESCE(D.Name, ''Unassigned'') AS Department,
    EP.JobTitleId,
    COALESCE(J.JobTitle, ''Unassigned'') AS Role,
    EP.StaffCategoryId,
    COALESCE(ET.EmploymentType, ''Unassigned'') AS StaffCategory,
    CAST(1 AS int) AS EmployeeHeadcountFlag,
    ISNULL(TA.TrainingEvents, 0) AS TrainingEvents,
    ISNULL(TA.CompletedTrainingEvents, 0) AS CompletedTrainingEvents,
    CAST(ISNULL(TA.TrainingHoursPerEmployee, 0) AS decimal(18, 2)) AS TrainingHoursPerEmployee,
    CAST(ISNULL(TA.TrainingSpendPerEmployee, 0) AS decimal(18, 2)) AS TrainingSpendPerEmployee,
    CASE WHEN ISNULL(TA.TrainingEvents, 0) > 0 THEN 1 ELSE 0 END AS HasTrainingFlag,
    ISNULL(MA.InternalMobilityEvents, 0) AS InternalMobilityEvents,
    ISNULL(MA.PromotionEvents, 0) AS PromotionEvents,
    CASE WHEN ISNULL(MA.InternalMobilityEvents, 0) > 0 THEN 1 ELSE 0 END AS InternalMobilityFlag,
    CASE WHEN ISNULL(MA.PromotionEvents, 0) > 0 THEN 1 ELSE 0 END AS PromotionFlag,
    ISNULL(SC.SkillCount, 0) AS SkillCount,
    CASE WHEN ISNULL(SC.SkillCount, 0) > 0 THEN 1 ELSE 0 END AS HasSkillFlag,
    COALESCE(NULLIF(SC.SkillsList, ''''), ''No recorded skills'') AS SkillsList,
    COALESCE(NULLIF(SC.SkillCategoriesList, ''''), ''No recorded skill categories'') AS SkillCategoriesList,
    COALESCE(NULLIF(TA.CoursesInPeriodList, ''''), ''No recorded training in period'') AS CoursesInPeriodList,
    COALESCE(NULLIF(TA.ModulesInPeriodList, ''''), ''No recorded modules in period'') AS ModulesInPeriodList,
    COALESCE(NULLIF(TA.TrainingPeriodsInPeriodList, ''''), ''No recorded training periods in period'') AS TrainingPeriodsInPeriodList,
    COALESCE(NULLIF(TA.TrainersInPeriodList, ''''), ''No recorded trainers in period'') AS TrainersInPeriodList
FROM EmployeePeriods AS EP
LEFT JOIN dbo.ACC0002 AS C
    ON EP.CompanyId = C.CompanyId
LEFT JOIN dbo.ACC0004 AS B
    ON EP.CompanyId = B.CompanyId
   AND EP.BranchId = B.BranchId
LEFT JOIN dbo.ACC0006 AS D
    ON EP.DepartmentId = D.DepartmentId
LEFT JOIN dbo.ACC0010 AS J
    ON EP.JobTitleId = J.JobTitleId
LEFT JOIN dbo.ACC0009 AS ET
    ON EP.StaffCategoryId = ET.EmploymentTypeId
LEFT JOIN SkillsCurrent AS SC
    ON EP.EmpId = SC.EmpId
OUTER APPLY (
    SELECT
        COUNT(*) AS TrainingEvents,
        SUM(CASE WHEN TEN.CompletedFlag = 1 THEN 1 ELSE 0 END) AS CompletedTrainingEvents,
        SUM(TEN.TrainingHours) AS TrainingHoursPerEmployee,
        SUM(TEN.TrainingSpend) AS TrainingSpendPerEmployee,
        STUFF((
            SELECT DISTINCT
                '', '' + TEN2.Course
            FROM TrainingEventsNormalized AS TEN2
            WHERE TEN2.EmpId = EP.EmpId
              AND TEN2.EventStartDate >= EP.PeriodStartDate
              AND TEN2.EventStartDate <= EP.PeriodEndDate
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''nvarchar(max)''), 1, 2, '''') AS CoursesInPeriodList,
        STUFF((
            SELECT DISTINCT
                '', '' + TEN2.Module
            FROM TrainingEventsNormalized AS TEN2
            WHERE TEN2.EmpId = EP.EmpId
              AND TEN2.EventStartDate >= EP.PeriodStartDate
              AND TEN2.EventStartDate <= EP.PeriodEndDate
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''nvarchar(max)''), 1, 2, '''') AS ModulesInPeriodList,
        STUFF((
            SELECT DISTINCT
                '', '' + TEN2.TrainingPeriodName
            FROM TrainingEventsNormalized AS TEN2
            WHERE TEN2.EmpId = EP.EmpId
              AND TEN2.EventStartDate >= EP.PeriodStartDate
              AND TEN2.EventStartDate <= EP.PeriodEndDate
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''nvarchar(max)''), 1, 2, '''') AS TrainingPeriodsInPeriodList,
        STUFF((
            SELECT DISTINCT
                '', '' + TEN2.Trainer
            FROM TrainingEventsNormalized AS TEN2
            WHERE TEN2.EmpId = EP.EmpId
              AND TEN2.EventStartDate >= EP.PeriodStartDate
              AND TEN2.EventStartDate <= EP.PeriodEndDate
            FOR XML PATH(''''), TYPE
        ).value(''.'', ''nvarchar(max)''), 1, 2, '''') AS TrainersInPeriodList
    FROM TrainingEventsNormalized AS TEN
    WHERE TEN.EmpId = EP.EmpId
      AND TEN.EventStartDate >= EP.PeriodStartDate
      AND TEN.EventStartDate <= EP.PeriodEndDate
) AS TA
OUTER APPLY (
    SELECT
        SUM(ME.InternalMobilityFlag) AS InternalMobilityEvents,
        SUM(ME.PromotionFlag) AS PromotionEvents
    FROM MobilityEvents AS ME
    WHERE ME.EmpId = EP.EmpId
      AND ME.EventDate >= EP.PeriodStartDate
      AND ME.EventDate <= EP.PeriodEndDate
) AS MA;
');
