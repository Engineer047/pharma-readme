/*
bi_hr_attendance_and_productivity

Purpose:
- Absenteeism rate
- Attendance compliance (late check-ins, missed shifts)
- Sales per employee placeholder for future HR-to-retail linkage

Design note:
- Grain is one row per period type and period start date
- Absence metrics come from dbo.WORKDAYS at employee-month grain
- Compliance metrics come from dbo.ACC0054 after normalizing to one employee-date-shift row
- The two sources are aggregated separately and only joined at the final period grain
- This avoids inflating values in Power BI

Assumptions:
- Absenteeism rate = absent days / scheduled workdays * 100
- Scheduled workdays come from dbo.WORKDAYS.MonthDays
- A scheduled shift is one normalized dbo.ACC0054 employee-date-shift row with a non-null ShiftId
- Leave-tagged rows in dbo.ACC0054 are excluded from compliance counts
- A late check-in is a scheduled attended shift where LateMinutes > 0
- A missed shift is a scheduled non-leave shift with no attendance mark
- Sales per employee remains NULL because the supplied HRMIS DDL does not expose a retail sales fact table
- dbo.ACC0001.ERPCode is exposed only as a possible future retail linkage key, not as a sales measure

SQL Server note:
- This script avoids GO because some clients send GO directly to SQL Server
*/

IF OBJECT_ID('dbo.bi_hr_attendance_and_productivity', 'V') IS NOT NULL
    EXEC(N'DROP VIEW dbo.bi_hr_attendance_and_productivity;');

EXEC(N'
CREATE VIEW dbo.bi_hr_attendance_and_productivity
AS
WITH EmployeeBase AS (
    SELECT
        E.EmpId,
        CAST(COALESCE(E.ED, E.ED01) AS date) AS HireDate,
        CAST(E.TerminationDate AS date) AS ExitDate,
        NULLIF(LTRIM(RTRIM(E.ERPCode)), '''') AS ERPCode
    FROM dbo.ACC0001 AS E
    WHERE COALESCE(E.ED, E.ED01) IS NOT NULL
      AND COALESCE(E.ED, E.ED01) <= CAST(GETDATE() AS date)
),
WorkdaysNormalized AS (
    SELECT
        W.EmpId,
        DATEFROMPARTS(W.YearId, W.MonthId, 1) AS PeriodStartDate,
        MAX(ISNULL(W.DaysWorked, 0)) AS DaysWorked,
        MAX(ISNULL(W.MonthDays, 0)) AS ScheduledWorkDays,
        MAX(ISNULL(W.AbsentDays, 0)) AS AbsentDays,
        MAX(ISNULL(W.AbsentPay, 0)) AS AbsentPay
    FROM dbo.WORKDAYS AS W
    WHERE W.EmpId IS NOT NULL
      AND W.YearId IS NOT NULL
      AND W.MonthId BETWEEN 1 AND 12
    GROUP BY
        W.EmpId,
        DATEFROMPARTS(W.YearId, W.MonthId, 1)
),
RegisterNormalized AS (
    SELECT
        R.EmpId,
        CAST(R.RegisterDate AS date) AS RegisterDate,
        ISNULL(R.ShiftId, 0) AS ShiftId,
        MAX(CASE
                WHEN R.LeaveTransactionId IS NOT NULL OR R.LeaveTypeId IS NOT NULL THEN 1
                ELSE 0
            END) AS LeaveFlag,
        MAX(CASE
                WHEN R.EmpFrom IS NOT NULL OR R.EmpTo IS NOT NULL OR ISNULL(R.Present, 0) = 1 THEN 1
                ELSE 0
            END) AS AttendedFlag,
        MAX(CASE
                WHEN ISNULL(R.LateMinutes, 0) > 0 THEN 1
                ELSE 0
            END) AS LateFlag
    FROM dbo.ACC0054 AS R
    WHERE R.EmpId IS NOT NULL
      AND R.RegisterDate IS NOT NULL
      AND R.ShiftId IS NOT NULL
    GROUP BY
        R.EmpId,
        CAST(R.RegisterDate AS date),
        ISNULL(R.ShiftId, 0)
),
DateBounds AS (
    SELECT
        COALESCE(
            MIN(D.EventMonth),
            DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        ) AS MinMonth,
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1) AS MaxMonth
    FROM (
        SELECT WN.PeriodStartDate AS EventMonth
        FROM WorkdaysNormalized AS WN

        UNION ALL

        SELECT DATEFROMPARTS(YEAR(RN.RegisterDate), MONTH(RN.RegisterDate), 1) AS EventMonth
        FROM RegisterNormalized AS RN
    ) AS D
),
Numbers AS (
    SELECT TOP (2400)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Num
    FROM sys.all_objects AS A
    CROSS JOIN sys.all_objects AS B
),
MonthCalendar AS (
    SELECT
        CAST(DATEADD(MONTH, N.Num, DB.MinMonth) AS date) AS MonthStart
    FROM DateBounds AS DB
    INNER JOIN Numbers AS N
        ON N.Num <= DATEDIFF(MONTH, DB.MinMonth, DB.MaxMonth)
),
Periods AS (
    SELECT
        CAST(''Monthly'' AS varchar(20)) AS PeriodType,
        MC.MonthStart AS PeriodStartDate,
        CAST(EOMONTH(MC.MonthStart) AS date) AS PeriodEndDate,
        YEAR(MC.MonthStart) AS CalendarYear,
        DATEPART(QUARTER, MC.MonthStart) AS CalendarQuarter,
        MONTH(MC.MonthStart) AS CalendarMonth,
        DATENAME(MONTH, MC.MonthStart) AS MonthName,
        CONVERT(char(7), MC.MonthStart, 120) AS PeriodLabel
    FROM MonthCalendar AS MC

    UNION ALL

    SELECT
        CAST(''Quarterly'' AS varchar(20)) AS PeriodType,
        Q.QuarterStart AS PeriodStartDate,
        CAST(EOMONTH(DATEADD(MONTH, 2, Q.QuarterStart)) AS date) AS PeriodEndDate,
        YEAR(Q.QuarterStart) AS CalendarYear,
        DATEPART(QUARTER, Q.QuarterStart) AS CalendarQuarter,
        CAST(NULL AS int) AS CalendarMonth,
        CAST(NULL AS varchar(20)) AS MonthName,
        CAST(CAST(YEAR(Q.QuarterStart) AS varchar(4)) + '' Q'' + CAST(DATEPART(QUARTER, Q.QuarterStart) AS varchar(1)) AS varchar(20)) AS PeriodLabel
    FROM (
        SELECT DISTINCT
            CAST(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, MC.MonthStart), 0) AS date) AS QuarterStart
        FROM MonthCalendar AS MC
    ) AS Q
)
SELECT
    P.PeriodType,
    P.PeriodStartDate,
    P.PeriodEndDate,
    P.CalendarYear,
    P.CalendarQuarter,
    P.CalendarMonth,
    P.MonthName,
    P.PeriodLabel,
    ISNULL(H.ActiveEmployees, 0) AS ActiveEmployees,
    ISNULL(H.EmployeesWithRetailLink, 0) AS EmployeesWithRetailLink,
    ISNULL(W.EmployeesWithWorkdays, 0) AS EmployeesWithWorkdays,
    CAST(ISNULL(W.DaysWorked, 0) AS decimal(18, 2)) AS DaysWorked,
    CAST(ISNULL(W.ScheduledWorkDays, 0) AS decimal(18, 2)) AS ScheduledWorkDays,
    CAST(ISNULL(W.AbsentDays, 0) AS decimal(18, 2)) AS AbsentDays,
    CAST(ISNULL(W.AbsentPay, 0) AS decimal(18, 2)) AS AbsentPay,
    CAST(
        CASE
            WHEN ISNULL(W.ScheduledWorkDays, 0) = 0 THEN NULL
            ELSE (100.0 * ISNULL(W.AbsentDays, 0)) / NULLIF(W.ScheduledWorkDays, 0)
        END
        AS decimal(18, 2)
    ) AS AbsenteeismRatePct,
    ISNULL(R.EmployeesWithShiftRegister, 0) AS EmployeesWithShiftRegister,
    ISNULL(R.ScheduledShifts, 0) AS ScheduledShifts,
    ISNULL(R.AttendedShifts, 0) AS AttendedShifts,
    ISNULL(R.LateCheckIns, 0) AS LateCheckIns,
    ISNULL(R.MissedShifts, 0) AS MissedShifts,
    ISNULL(R.OnTimeShifts, 0) AS OnTimeShifts,
    CAST(
        CASE
            WHEN ISNULL(R.ScheduledShifts, 0) = 0 THEN NULL
            ELSE (100.0 * ISNULL(R.LateCheckIns, 0)) / NULLIF(R.ScheduledShifts, 0)
        END
        AS decimal(18, 2)
    ) AS LateCheckInRatePct,
    CAST(
        CASE
            WHEN ISNULL(R.ScheduledShifts, 0) = 0 THEN NULL
            ELSE (100.0 * ISNULL(R.MissedShifts, 0)) / NULLIF(R.ScheduledShifts, 0)
        END
        AS decimal(18, 2)
    ) AS MissedShiftRatePct,
    CAST(
        CASE
            WHEN ISNULL(R.ScheduledShifts, 0) = 0 THEN NULL
            ELSE (100.0 * ISNULL(R.OnTimeShifts, 0)) / NULLIF(R.ScheduledShifts, 0)
        END
        AS decimal(18, 2)
    ) AS AttendanceCompliancePct,
    CAST(NULL AS decimal(18, 2)) AS RetailSalesAmount,
    CAST(NULL AS decimal(18, 2)) AS SalesPerEmployee
FROM Periods AS P
OUTER APPLY (
    SELECT
        COUNT(DISTINCT EB.EmpId) AS ActiveEmployees,
        COUNT(DISTINCT CASE WHEN EB.ERPCode IS NOT NULL THEN EB.EmpId END) AS EmployeesWithRetailLink
    FROM EmployeeBase AS EB
    WHERE EB.HireDate <= P.PeriodEndDate
      AND (EB.ExitDate IS NULL OR EB.ExitDate > P.PeriodEndDate)
) AS H
OUTER APPLY (
    SELECT
        COUNT(DISTINCT WN.EmpId) AS EmployeesWithWorkdays,
        SUM(WN.DaysWorked) AS DaysWorked,
        SUM(WN.ScheduledWorkDays) AS ScheduledWorkDays,
        SUM(WN.AbsentDays) AS AbsentDays,
        SUM(WN.AbsentPay) AS AbsentPay
    FROM WorkdaysNormalized AS WN
    WHERE WN.PeriodStartDate >= P.PeriodStartDate
      AND WN.PeriodStartDate <= P.PeriodEndDate
) AS W
OUTER APPLY (
    SELECT
        COUNT(DISTINCT RN.EmpId) AS EmployeesWithShiftRegister,
        SUM(CASE WHEN RN.LeaveFlag = 0 THEN 1 ELSE 0 END) AS ScheduledShifts,
        SUM(CASE WHEN RN.LeaveFlag = 0 AND RN.AttendedFlag = 1 THEN 1 ELSE 0 END) AS AttendedShifts,
        SUM(CASE WHEN RN.LeaveFlag = 0 AND RN.AttendedFlag = 1 AND RN.LateFlag = 1 THEN 1 ELSE 0 END) AS LateCheckIns,
        SUM(CASE WHEN RN.LeaveFlag = 0 AND RN.AttendedFlag = 0 THEN 1 ELSE 0 END) AS MissedShifts,
        SUM(CASE WHEN RN.LeaveFlag = 0 AND RN.AttendedFlag = 1 AND RN.LateFlag = 0 THEN 1 ELSE 0 END) AS OnTimeShifts
    FROM RegisterNormalized AS RN
    WHERE RN.RegisterDate >= P.PeriodStartDate
      AND RN.RegisterDate <= P.PeriodEndDate
) AS R;
');
