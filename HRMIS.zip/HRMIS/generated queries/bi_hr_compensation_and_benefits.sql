/*
bi_hr_compensation_and_benefits

Purpose:
- Total payroll cost
- Payroll as % of sales
- Bonus distribution
- Average pay per staff category

Design note:
- Grain is one row per period type, period start date, and staff category
- Payroll is normalized to one employee-period payroll row before aggregation
- Bonus is derived separately from bonus-like allowance and commission records
- Payroll and bonus are combined only after both are normalized to employee-period grain
- This avoids inflated values in Power BI

Assumptions:
- Total payroll cost = dbo.ACC0055.GrossPay
- Staff category = current employee employment type from dbo.ACC0009
- Payroll duplicates are de-duplicated by keeping the latest payroll row per employee-month
- Bonus distribution is derived from allowance/commission records whose labels look like bonus/incentive/reward/merit/performance items
- Payroll as % of sales remains NULL because the supplied HRMIS DDL does not expose a retail sales fact table

SQL Server note:
- This script avoids GO because some clients send GO directly to SQL Server
*/

IF OBJECT_ID('dbo.bi_hr_compensation_and_benefits', 'V') IS NOT NULL
    EXEC(N'DROP VIEW dbo.bi_hr_compensation_and_benefits;');

EXEC(N'
CREATE VIEW dbo.bi_hr_compensation_and_benefits
AS
WITH EmployeeCategory AS (
    SELECT
        E.EmpId,
        E.CompanyId,
        E.EmploymentTypeID AS StaffCategoryId,
        COALESCE(ET.EmploymentType, ''Unassigned'') AS StaffCategory
    FROM dbo.ACC0001 AS E
    LEFT JOIN dbo.ACC0009 AS ET
        ON E.EmploymentTypeID = ET.EmploymentTypeId
),
PayrollRanked AS (
    SELECT
        P.PayrollId,
        P.EmpId,
        DATEFROMPARTS(P.YearId, P.MonthId, 1) AS PeriodStartDate,
        CAST(ISNULL(P.Basic, 0) AS decimal(18, 2)) AS BasicPay,
        CAST(ISNULL(P.GrossPay, 0) AS decimal(18, 2)) AS GrossPay,
        CAST(ISNULL(P.Net, 0) AS decimal(18, 2)) AS NetPay,
        CAST(ISNULL(P.Allowance, 0) AS decimal(18, 2)) AS PayrollAllowance,
        CAST(ISNULL(P.Commission, 0) AS decimal(18, 2)) AS PayrollCommission,
        CAST(ISNULL(P.NonCashBenefits, 0) AS decimal(18, 2)) AS NonCashBenefits,
        CAST(ISNULL(P.FringeBenefits, 0) AS decimal(18, 2)) AS FringeBenefits,
        ROW_NUMBER() OVER (
            PARTITION BY P.EmpId, P.YearId, P.MonthId
            ORDER BY
                ISNULL(P.IsClosed, 0) DESC,
                ISNULL(P.PayrollDate, P.SystemLog) DESC,
                P.PayrollId DESC
        ) AS RN
    FROM dbo.ACC0055 AS P
    WHERE P.EmpId IS NOT NULL
      AND P.YearId IS NOT NULL
      AND P.MonthId BETWEEN 1 AND 12
),
PayrollNormalized AS (
    SELECT
        PR.EmpId,
        PR.PeriodStartDate,
        PR.BasicPay,
        PR.GrossPay,
        PR.NetPay,
        PR.PayrollAllowance,
        PR.PayrollCommission,
        PR.NonCashBenefits,
        PR.FringeBenefits,
        PR.GrossPay AS TotalPayrollCost
    FROM PayrollRanked AS PR
    WHERE PR.RN = 1
),
BonusAllowance AS (
    SELECT
        A.EmpId,
        DATEFROMPARTS(A.YearId, A.MonthId, 1) AS PeriodStartDate,
        CAST(ISNULL(A.Amount, 0) AS decimal(18, 2)) AS BonusAmount
    FROM dbo.ACC0094 AS A
    WHERE A.EmpId IS NOT NULL
      AND ISNULL(A.Cancelled, 0) = 0
      AND A.YearId IS NOT NULL
      AND A.MonthId BETWEEN 1 AND 12
      AND (
            LOWER(COALESCE(A.Allowance, '''') + '' '' + COALESCE(A.Code, '''') + '' '' + COALESCE(A.Narration, '''')) LIKE ''%bonus%''
         OR LOWER(COALESCE(A.Allowance, '''') + '' '' + COALESCE(A.Code, '''') + '' '' + COALESCE(A.Narration, '''')) LIKE ''%incentiv%''
         OR LOWER(COALESCE(A.Allowance, '''') + '' '' + COALESCE(A.Code, '''') + '' '' + COALESCE(A.Narration, '''')) LIKE ''%reward%''
         OR LOWER(COALESCE(A.Allowance, '''') + '' '' + COALESCE(A.Code, '''') + '' '' + COALESCE(A.Narration, '''')) LIKE ''%merit%''
         OR LOWER(COALESCE(A.Allowance, '''') + '' '' + COALESCE(A.Code, '''') + '' '' + COALESCE(A.Narration, '''')) LIKE ''%performance%''
         OR LOWER(COALESCE(A.Allowance, '''') + '' '' + COALESCE(A.Code, '''') + '' '' + COALESCE(A.Narration, '''')) LIKE ''%ex gratia%''
         OR LOWER(COALESCE(A.Allowance, '''') + '' '' + COALESCE(A.Code, '''') + '' '' + COALESCE(A.Narration, '''')) LIKE ''%exgratia%''
      )
),
BonusCommission AS (
    SELECT
        C.EmpId,
        DATEFROMPARTS(C.YearId, C.MonthId, 1) AS PeriodStartDate,
        CAST(ISNULL(C.Amount, 0) AS decimal(18, 2)) AS BonusAmount
    FROM dbo.ACC0095 AS C
    WHERE C.EmpId IS NOT NULL
      AND ISNULL(C.Cancelled, 0) = 0
      AND C.YearId IS NOT NULL
      AND C.MonthId BETWEEN 1 AND 12
      AND (
            LOWER(COALESCE(C.Commission, '''') + '' '' + COALESCE(C.Code, '''') + '' '' + COALESCE(C.Narration, '''')) LIKE ''%bonus%''
         OR LOWER(COALESCE(C.Commission, '''') + '' '' + COALESCE(C.Code, '''') + '' '' + COALESCE(C.Narration, '''')) LIKE ''%incentiv%''
         OR LOWER(COALESCE(C.Commission, '''') + '' '' + COALESCE(C.Code, '''') + '' '' + COALESCE(C.Narration, '''')) LIKE ''%reward%''
         OR LOWER(COALESCE(C.Commission, '''') + '' '' + COALESCE(C.Code, '''') + '' '' + COALESCE(C.Narration, '''')) LIKE ''%merit%''
         OR LOWER(COALESCE(C.Commission, '''') + '' '' + COALESCE(C.Code, '''') + '' '' + COALESCE(C.Narration, '''')) LIKE ''%performance%''
         OR LOWER(COALESCE(C.Commission, '''') + '' '' + COALESCE(C.Code, '''') + '' '' + COALESCE(C.Narration, '''')) LIKE ''%ex gratia%''
         OR LOWER(COALESCE(C.Commission, '''') + '' '' + COALESCE(C.Code, '''') + '' '' + COALESCE(C.Narration, '''')) LIKE ''%exgratia%''
      )
),
BonusByEmpPeriod AS (
    SELECT
        B.EmpId,
        B.PeriodStartDate,
        SUM(B.BonusAmount) AS BonusAmount
    FROM (
        SELECT
            BA.EmpId,
            BA.PeriodStartDate,
            BA.BonusAmount
        FROM BonusAllowance AS BA

        UNION ALL

        SELECT
            BC.EmpId,
            BC.PeriodStartDate,
            BC.BonusAmount
        FROM BonusCommission AS BC
    ) AS B
    GROUP BY
        B.EmpId,
        B.PeriodStartDate
),
EmployeePeriodBase AS (
    SELECT
        PN.EmpId,
        PN.PeriodStartDate
    FROM PayrollNormalized AS PN

    UNION

    SELECT
        BP.EmpId,
        BP.PeriodStartDate
    FROM BonusByEmpPeriod AS BP
),
EmployeePeriodMetrics AS (
    SELECT
        EP.EmpId,
        EP.PeriodStartDate,
        EC.StaffCategoryId,
        COALESCE(EC.StaffCategory, ''Unassigned'') AS StaffCategory,
        CASE
            WHEN PN.EmpId IS NULL THEN 0
            ELSE 1
        END AS HasPayrollRecord,
        ISNULL(PN.BasicPay, 0) AS BasicPay,
        ISNULL(PN.GrossPay, 0) AS GrossPay,
        ISNULL(PN.NetPay, 0) AS NetPay,
        ISNULL(PN.TotalPayrollCost, 0) AS TotalPayrollCost,
        ISNULL(BP.BonusAmount, 0) AS BonusAmount
    FROM EmployeePeriodBase AS EP
    LEFT JOIN PayrollNormalized AS PN
        ON EP.EmpId = PN.EmpId
       AND EP.PeriodStartDate = PN.PeriodStartDate
    LEFT JOIN BonusByEmpPeriod AS BP
        ON EP.EmpId = BP.EmpId
       AND EP.PeriodStartDate = BP.PeriodStartDate
    LEFT JOIN EmployeeCategory AS EC
        ON EP.EmpId = EC.EmpId
),
DateBounds AS (
    SELECT
        COALESCE(
            MIN(D.PeriodStartDate),
            DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        ) AS MinMonth,
        COALESCE(
            MAX(D.PeriodStartDate),
            DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        ) AS MaxMonth
    FROM (
        SELECT
            PN.PeriodStartDate
        FROM PayrollNormalized AS PN

        UNION ALL

        SELECT
            BP.PeriodStartDate
        FROM BonusByEmpPeriod AS BP
    ) AS D
),
Numbers AS (
    SELECT TOP (2400)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Num
    FROM sys.all_objects AS A
    CROSS JOIN sys.all_objects AS B
),
MonthCalendar AS (
    SELECT
        CAST(DATEADD(MONTH, N.Num, DB.MinMonth) AS date) AS MonthStart
    FROM DateBounds AS DB
    INNER JOIN Numbers AS N
        ON N.Num <= DATEDIFF(MONTH, DB.MinMonth, DB.MaxMonth)
),
CategoryDimension AS (
    SELECT DISTINCT
        EC.StaffCategoryId,
        COALESCE(EC.StaffCategory, ''Unassigned'') AS StaffCategory
    FROM EmployeeCategory AS EC

    UNION

    SELECT
        CAST(NULL AS int) AS StaffCategoryId,
        CAST(''Unassigned'' AS varchar(50)) AS StaffCategory
),
MonthlyBase AS (
    SELECT
        CAST(''Monthly'' AS varchar(20)) AS PeriodType,
        MC.MonthStart AS PeriodStartDate,
        CAST(EOMONTH(MC.MonthStart) AS date) AS PeriodEndDate,
        YEAR(MC.MonthStart) AS CalendarYear,
        DATEPART(QUARTER, MC.MonthStart) AS CalendarQuarter,
        MONTH(MC.MonthStart) AS CalendarMonth,
        DATENAME(MONTH, MC.MonthStart) AS MonthName,
        CONVERT(char(7), MC.MonthStart, 120) AS PeriodLabel,
        CD.StaffCategoryId,
        CD.StaffCategory,
        COUNT(DISTINCT CASE WHEN EPM.HasPayrollRecord = 1 THEN EPM.EmpId END) AS PayrollEmployeeCount,
        COUNT(CASE WHEN EPM.HasPayrollRecord = 1 THEN 1 END) AS PayrollRecordCount,
        SUM(EPM.TotalPayrollCost) AS TotalPayrollCost,
        SUM(EPM.BonusAmount) AS TotalBonusAmount,
        COUNT(DISTINCT CASE WHEN EPM.BonusAmount > 0 THEN EPM.EmpId END) AS EmployeesWithBonus
    FROM MonthCalendar AS MC
    CROSS JOIN CategoryDimension AS CD
    LEFT JOIN EmployeePeriodMetrics AS EPM
        ON EPM.PeriodStartDate = MC.MonthStart
       AND (
            (EPM.StaffCategoryId = CD.StaffCategoryId)
            OR (EPM.StaffCategoryId IS NULL AND CD.StaffCategoryId IS NULL)
       )
    GROUP BY
        MC.MonthStart,
        CD.StaffCategoryId,
        CD.StaffCategory
),
QuarterlyPeriods AS (
    SELECT DISTINCT
        CAST(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, MC.MonthStart), 0) AS date) AS QuarterStart
    FROM MonthCalendar AS MC
),
QuarterlyBase AS (
    SELECT
        CAST(''Quarterly'' AS varchar(20)) AS PeriodType,
        QP.QuarterStart AS PeriodStartDate,
        CAST(EOMONTH(DATEADD(MONTH, 2, QP.QuarterStart)) AS date) AS PeriodEndDate,
        YEAR(QP.QuarterStart) AS CalendarYear,
        DATEPART(QUARTER, QP.QuarterStart) AS CalendarQuarter,
        CAST(NULL AS int) AS CalendarMonth,
        CAST(NULL AS varchar(20)) AS MonthName,
        CAST(CAST(YEAR(QP.QuarterStart) AS varchar(4)) + '' Q'' + CAST(DATEPART(QUARTER, QP.QuarterStart) AS varchar(1)) AS varchar(20)) AS PeriodLabel,
        CD.StaffCategoryId,
        CD.StaffCategory,
        COUNT(DISTINCT CASE WHEN EPM.HasPayrollRecord = 1 THEN EPM.EmpId END) AS PayrollEmployeeCount,
        COUNT(CASE WHEN EPM.HasPayrollRecord = 1 THEN 1 END) AS PayrollRecordCount,
        SUM(EPM.TotalPayrollCost) AS TotalPayrollCost,
        SUM(EPM.BonusAmount) AS TotalBonusAmount,
        COUNT(DISTINCT CASE WHEN EPM.BonusAmount > 0 THEN EPM.EmpId END) AS EmployeesWithBonus
    FROM QuarterlyPeriods AS QP
    CROSS JOIN CategoryDimension AS CD
    LEFT JOIN EmployeePeriodMetrics AS EPM
        ON EPM.PeriodStartDate >= QP.QuarterStart
       AND EPM.PeriodStartDate < DATEADD(MONTH, 3, QP.QuarterStart)
       AND (
            (EPM.StaffCategoryId = CD.StaffCategoryId)
            OR (EPM.StaffCategoryId IS NULL AND CD.StaffCategoryId IS NULL)
       )
    GROUP BY
        QP.QuarterStart,
        CD.StaffCategoryId,
        CD.StaffCategory
),
CombinedBase AS (
    SELECT
        MB.PeriodType,
        MB.PeriodStartDate,
        MB.PeriodEndDate,
        MB.CalendarYear,
        MB.CalendarQuarter,
        MB.CalendarMonth,
        MB.MonthName,
        MB.PeriodLabel,
        MB.StaffCategoryId,
        MB.StaffCategory,
        MB.PayrollEmployeeCount,
        MB.PayrollRecordCount,
        CAST(ISNULL(MB.TotalPayrollCost, 0) AS decimal(18, 2)) AS TotalPayrollCost,
        CAST(ISNULL(MB.TotalBonusAmount, 0) AS decimal(18, 2)) AS TotalBonusAmount,
        MB.EmployeesWithBonus
    FROM MonthlyBase AS MB

    UNION ALL

    SELECT
        QB.PeriodType,
        QB.PeriodStartDate,
        QB.PeriodEndDate,
        QB.CalendarYear,
        QB.CalendarQuarter,
        QB.CalendarMonth,
        QB.MonthName,
        QB.PeriodLabel,
        QB.StaffCategoryId,
        QB.StaffCategory,
        QB.PayrollEmployeeCount,
        QB.PayrollRecordCount,
        CAST(ISNULL(QB.TotalPayrollCost, 0) AS decimal(18, 2)) AS TotalPayrollCost,
        CAST(ISNULL(QB.TotalBonusAmount, 0) AS decimal(18, 2)) AS TotalBonusAmount,
        QB.EmployeesWithBonus
    FROM QuarterlyBase AS QB
)
SELECT
    CB.PeriodType,
    CB.PeriodStartDate,
    CB.PeriodEndDate,
    CB.CalendarYear,
    CB.CalendarQuarter,
    CB.CalendarMonth,
    CB.MonthName,
    CB.PeriodLabel,
    CB.StaffCategoryId,
    CB.StaffCategory,
    CB.PayrollEmployeeCount,
    CB.PayrollRecordCount,
    CB.TotalPayrollCost,
    CAST(
        CASE
            WHEN CB.PayrollRecordCount = 0 THEN NULL
            ELSE CB.TotalPayrollCost / NULLIF(CB.PayrollRecordCount, 0)
        END
        AS decimal(18, 2)
    ) AS AveragePayPerStaffCategory,
    CB.TotalBonusAmount,
    CB.EmployeesWithBonus,
    CAST(
        CASE
            WHEN CB.EmployeesWithBonus = 0 THEN NULL
            ELSE CB.TotalBonusAmount / NULLIF(CB.EmployeesWithBonus, 0)
        END
        AS decimal(18, 2)
    ) AS AverageBonusPerRecipient,
    CAST(
        CASE
            WHEN SUM(CB.TotalBonusAmount) OVER (PARTITION BY CB.PeriodType, CB.PeriodStartDate) = 0 THEN NULL
            ELSE (100.0 * CB.TotalBonusAmount) / NULLIF(SUM(CB.TotalBonusAmount) OVER (PARTITION BY CB.PeriodType, CB.PeriodStartDate), 0)
        END
        AS decimal(18, 2)
    ) AS BonusDistributionPct,
    CAST(NULL AS decimal(18, 2)) AS SalesAmount,
    CAST(NULL AS decimal(18, 2)) AS PayrollAsPctOfSales
FROM CombinedBase AS CB;
');
