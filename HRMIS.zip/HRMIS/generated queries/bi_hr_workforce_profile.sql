/*
bi_hr_workforce_profile

Purpose:
- Workforce profile dataset for headcount by branch, department, gender, role, age group
- Employee distribution across regions

Design note:
- Grain is exactly 1 row per active employee
- Only employee master and lookup tables are joined
- No payroll or transactional joins are used, to avoid inflated headcount

Assumption:
- ACC0003 (Office) is used as Region because the supplied HRMIS DDL does not expose a separate region master

SQL Server note:
- This script avoids GO because some clients send GO directly to SQL Server
*/

IF OBJECT_ID('dbo.bi_hr_workforce_profile', 'V') IS NOT NULL
    EXEC(N'DROP VIEW dbo.bi_hr_workforce_profile;');

EXEC(N'
CREATE VIEW dbo.bi_hr_workforce_profile
AS
WITH EmployeeBase AS (
    SELECT
        E.EmpId,
        E.EmpNo,
        E.CompanyId,
        E.OfficeId AS RegionId,
        E.BranchId,
        E.DepartmentId,
        E.SectionId,
        E.JobTitleId,
        E.GenderId,
        E.EmploymentTypeID,
        E.EmploymentStatusId,
        E.ED AS DateOfEmployment,
        E.DOB,
        NULLIF(
            LTRIM(RTRIM(
                ISNULL(E.FirstName + '' '', '''')
                + ISNULL(E.MiddleName + '' '', '''')
                + ISNULL(E.LastName, '''')
            )),
            ''''
        ) AS EmployeeName
    FROM dbo.ACC0001 AS E
    WHERE ISNULL(E.Active, 0) = 1
),
EmployeeAge AS (
    SELECT
        EB.*,
        CASE
            WHEN EB.DOB IS NULL THEN NULL
            ELSE
                DATEDIFF(YEAR, EB.DOB, CAST(GETDATE() AS date))
                - CASE
                    WHEN DATEADD(YEAR, DATEDIFF(YEAR, EB.DOB, CAST(GETDATE() AS date)), EB.DOB) > CAST(GETDATE() AS date)
                        THEN 1
                    ELSE 0
                  END
        END AS AgeYears
    FROM EmployeeBase AS EB
)
SELECT
    CAST(GETDATE() AS date) AS SnapshotDate,
    EA.EmpId,
    EA.EmpNo,
    COALESCE(EA.EmployeeName, EA.EmpNo) AS EmployeeName,
    EA.CompanyId,
    COALESCE(C.Name, ''Unassigned'') AS Company,
    EA.RegionId,
    COALESCE(O.Name, ''Unassigned'') AS Region,
    EA.BranchId,
    COALESCE(B.Name, ''Unassigned'') AS Branch,
    EA.DepartmentId,
    COALESCE(D.Name, ''Unassigned'') AS Department,
    EA.SectionId,
    COALESCE(S.Name, ''Unassigned'') AS Section,
    EA.JobTitleId,
    COALESCE(J.JobTitle, ''Unassigned'') AS Role,
    EA.GenderId,
    COALESCE(G.Gender, ''Unspecified'') AS Gender,
    EA.EmploymentTypeID AS EmploymentTypeId,
    COALESCE(ET.EmploymentType, ''Unassigned'') AS EmploymentType,
    EA.EmploymentStatusId,
    COALESCE(ES.EmploymentStatus, ''Unassigned'') AS EmploymentStatus,
    EA.DateOfEmployment,
    EA.DOB,
    EA.AgeYears,
    CASE
        WHEN EA.AgeYears IS NULL THEN ''Unknown''
        WHEN EA.AgeYears < 25 THEN ''Under 25''
        WHEN EA.AgeYears BETWEEN 25 AND 34 THEN ''25-34''
        WHEN EA.AgeYears BETWEEN 35 AND 44 THEN ''35-44''
        WHEN EA.AgeYears BETWEEN 45 AND 54 THEN ''45-54''
        ELSE ''55+''
    END AS AgeGroup,
    CASE
        WHEN EA.AgeYears IS NULL THEN 99
        WHEN EA.AgeYears < 25 THEN 1
        WHEN EA.AgeYears BETWEEN 25 AND 34 THEN 2
        WHEN EA.AgeYears BETWEEN 35 AND 44 THEN 3
        WHEN EA.AgeYears BETWEEN 45 AND 54 THEN 4
        ELSE 5
    END AS AgeGroupSort,
    CAST(1 AS int) AS Headcount
FROM EmployeeAge AS EA
LEFT JOIN dbo.ACC0002 AS C
    ON EA.CompanyId = C.CompanyId
LEFT JOIN dbo.ACC0003 AS O
    ON EA.CompanyId = O.CompanyId
   AND EA.RegionId = O.OfficeId
LEFT JOIN dbo.ACC0004 AS B
    ON EA.CompanyId = B.CompanyId
   AND EA.BranchId = B.BranchId
LEFT JOIN dbo.ACC0006 AS D
    ON EA.DepartmentId = D.DepartmentId
LEFT JOIN dbo.ACC0007 AS S
    ON EA.DepartmentId = S.DepartmentId
   AND EA.SectionId = S.SectionId
LEFT JOIN dbo.ACC0010 AS J
    ON EA.JobTitleId = J.JobTitleId
LEFT JOIN dbo.ACC0011 AS G
    ON EA.GenderId = G.GenderId
LEFT JOIN dbo.ACC0009 AS ET
    ON EA.EmploymentTypeID = ET.EmploymentTypeId
LEFT JOIN dbo.ACC0008 AS ES
    ON EA.EmploymentStatusId = ES.EmploymentStatusId;
');
