/*
bi_hr_turnover_and_retention

Purpose:
- Employee turnover %
- Exit reasons by period
- Retention %

Design note:
- Grain is one row per period type and period start date
- Actual exit events come from dbo.ACC0001.TerminationDate so one employee = one exit
- Exit reason and exit-interview context borrow native HRMIS structures from dbo.vwEmpTermination and dbo.vwExitSurvey
- Separate exit-reason columns are used to avoid inflating totals in Power BI

Assumptions:
- Hire date = COALESCE(dbo.ACC0001.ED, dbo.ACC0001.ED01)
- Exit date = dbo.ACC0001.TerminationDate
- Turnover % = exits / average headcount * 100
- Average headcount = (beginning headcount + ending headcount) / 2
- Retention % = ending headcount / (beginning headcount + hires during period) * 100
- Exit reason buckets are derived from TypeOfTermination and TerminationReason text
- Exit survey responses are attached at employee-exit grain because dbo.vwExitSurvey does not expose a survey date

SQL Server note:
- This script avoids GO because some clients send GO directly to SQL Server
*/

IF OBJECT_ID('dbo.bi_hr_turnover_and_retention', 'V') IS NOT NULL
    EXEC(N'DROP VIEW dbo.bi_hr_turnover_and_retention;');

EXEC(N'
CREATE VIEW dbo.bi_hr_turnover_and_retention
AS
WITH EmployeeBase AS (
    SELECT
        E.EmpId,
        CAST(COALESCE(E.ED, E.ED01) AS date) AS HireDate,
        CAST(E.TerminationDate AS date) AS ExitDate
    FROM dbo.ACC0001 AS E
    WHERE COALESCE(E.ED, E.ED01) IS NOT NULL
      AND COALESCE(E.ED, E.ED01) <= CAST(GETDATE() AS date)
),
TerminationDetail AS (
    SELECT
        T.EmpId,
        CAST(T.TerminationDate AS date) AS ExitDate,
        T.TypeOfTermination,
        T.TerminationReason,
        CASE WHEN ISNULL(T.ExitInterviewCompleted, 0) = 1 THEN 1 ELSE 0 END AS ExitInterviewCompletedFlag,
        CASE WHEN ISNULL(T.EligibleForRehire, 0) = 1 THEN 1 ELSE 0 END AS EligibleForRehireFlag,
        CASE WHEN ISNULL(T.Cleared, 0) = 1 THEN 1 ELSE 0 END AS ClearedFlag,
        ROW_NUMBER() OVER (
            PARTITION BY T.EmpId, CAST(T.TerminationDate AS date)
            ORDER BY ISNULL(T.Approved, 0) DESC, CAST(T.TerminationDate AS date) DESC
        ) AS RN
    FROM dbo.vwEmpTermination AS T
    WHERE T.TerminationDate IS NOT NULL
),
ExitSurveyRollup AS (
    SELECT
        ES.EmpId,
        COUNT(*) AS ExitSurveyResponseCount,
        COUNT(DISTINCT ES.QuestionNo) AS ExitSurveyQuestionCount,
        MAX(NULLIF(LTRIM(RTRIM(ES.ReasonForLeaving)), '''')) AS SurveyReasonForLeaving
    FROM dbo.vwExitSurvey AS ES
    GROUP BY
        ES.EmpId
),
ExitEvents AS (
    SELECT
        EB.EmpId,
        EB.ExitDate,
        TD.TypeOfTermination,
        COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving) AS TerminationReason,
        TD.ExitInterviewCompletedFlag,
        TD.EligibleForRehireFlag,
        TD.ClearedFlag,
        ISNULL(ESR.ExitSurveyResponseCount, 0) AS ExitSurveyResponseCount,
        ISNULL(ESR.ExitSurveyQuestionCount, 0) AS ExitSurveyQuestionCount,
        CASE WHEN ISNULL(ESR.ExitSurveyResponseCount, 0) > 0 THEN 1 ELSE 0 END AS ExitSurveyCompletedFlag,
        CASE
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%retire%'' THEN ''Retirement''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%death%'' THEN ''Death''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%deceas%'' THEN ''Death''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%died%'' THEN ''Death''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%redundan%'' THEN ''Redundancy''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%layoff%'' THEN ''Redundancy''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%retrench%'' THEN ''Redundancy''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%contract%'' THEN ''Contract End''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%expiry%'' THEN ''Contract End''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%expiration%'' THEN ''Contract End''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%end of term%'' THEN ''Contract End''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%resign%'' THEN ''Voluntary''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%voluntar%'' THEN ''Voluntary''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%personal%'' THEN ''Voluntary''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%career%'' THEN ''Voluntary''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%relocat%'' THEN ''Voluntary''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%dismiss%'' THEN ''Dismissal''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%terminat%'' THEN ''Dismissal''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%disciplin%'' THEN ''Dismissal''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%misconduct%'' THEN ''Dismissal''
            WHEN LOWER(COALESCE(TD.TypeOfTermination, '''') + '' '' + COALESCE(NULLIF(LTRIM(RTRIM(TD.TerminationReason)), ''''), ESR.SurveyReasonForLeaving, '''')) LIKE ''%summary%'' THEN ''Dismissal''
            ELSE ''Other''
        END AS ExitReasonBucket
    FROM EmployeeBase AS EB
    LEFT JOIN TerminationDetail AS TD
        ON EB.EmpId = TD.EmpId
       AND EB.ExitDate = TD.ExitDate
       AND TD.RN = 1
    LEFT JOIN ExitSurveyRollup AS ESR
        ON EB.EmpId = ESR.EmpId
    WHERE EB.ExitDate IS NOT NULL
      AND EB.ExitDate <= CAST(GETDATE() AS date)
),
DateBounds AS (
    SELECT
        COALESCE(
            MIN(DATEFROMPARTS(YEAR(D.EventDate), MONTH(D.EventDate), 1)),
            DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)
        ) AS MinMonth,
        DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1) AS MaxMonth
    FROM (
        SELECT EB.HireDate AS EventDate
        FROM EmployeeBase AS EB

        UNION ALL

        SELECT EE.ExitDate AS EventDate
        FROM ExitEvents AS EE
    ) AS D
),
Numbers AS (
    SELECT TOP (2400)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Num
    FROM sys.all_objects AS A
    CROSS JOIN sys.all_objects AS B
),
MonthCalendar AS (
    SELECT
        CAST(DATEADD(MONTH, N.Num, DB.MinMonth) AS date) AS MonthStart
    FROM DateBounds AS DB
    INNER JOIN Numbers AS N
        ON N.Num <= DATEDIFF(MONTH, DB.MinMonth, DB.MaxMonth)
),
Periods AS (
    SELECT
        CAST(''Monthly'' AS varchar(20)) AS PeriodType,
        MC.MonthStart AS PeriodStartDate,
        CAST(EOMONTH(MC.MonthStart) AS date) AS PeriodEndDate,
        YEAR(MC.MonthStart) AS CalendarYear,
        DATEPART(QUARTER, MC.MonthStart) AS CalendarQuarter,
        MONTH(MC.MonthStart) AS CalendarMonth,
        DATENAME(MONTH, MC.MonthStart) AS MonthName,
        CONVERT(char(7), MC.MonthStart, 120) AS PeriodLabel
    FROM MonthCalendar AS MC

    UNION ALL

    SELECT
        CAST(''Quarterly'' AS varchar(20)) AS PeriodType,
        Q.QuarterStart AS PeriodStartDate,
        CAST(EOMONTH(DATEADD(MONTH, 2, Q.QuarterStart)) AS date) AS PeriodEndDate,
        YEAR(Q.QuarterStart) AS CalendarYear,
        DATEPART(QUARTER, Q.QuarterStart) AS CalendarQuarter,
        CAST(NULL AS int) AS CalendarMonth,
        CAST(NULL AS varchar(20)) AS MonthName,
        CONCAT(CAST(YEAR(Q.QuarterStart) AS varchar(4)), '' Q'', CAST(DATEPART(QUARTER, Q.QuarterStart) AS varchar(1))) AS PeriodLabel
    FROM (
        SELECT DISTINCT
            CAST(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, MC.MonthStart), 0) AS date) AS QuarterStart
        FROM MonthCalendar AS MC
    ) AS Q
)
SELECT
    P.PeriodType,
    P.PeriodStartDate,
    P.PeriodEndDate,
    P.CalendarYear,
    P.CalendarQuarter,
    P.CalendarMonth,
    P.MonthName,
    P.PeriodLabel,
    ISNULL(H.Hires, 0) AS NewHires,
    ISNULL(B.BeginningHeadcount, 0) AS BeginningHeadcount,
    ISNULL(E.EndingHeadcount, 0) AS EndingHeadcount,
    CAST((ISNULL(B.BeginningHeadcount, 0) + ISNULL(E.EndingHeadcount, 0)) / 2.0 AS decimal(18, 2)) AS AverageHeadcount,
    ISNULL(X.Exits, 0) AS Exits,
    ISNULL(X.VoluntaryExits, 0) AS VoluntaryExits,
    ISNULL(X.DismissalExits, 0) AS DismissalExits,
    ISNULL(X.RetirementExits, 0) AS RetirementExits,
    ISNULL(X.RedundancyExits, 0) AS RedundancyExits,
    ISNULL(X.ContractEndExits, 0) AS ContractEndExits,
    ISNULL(X.DeathExits, 0) AS DeathExits,
    ISNULL(X.OtherExits, 0) AS OtherExits,
    ISNULL(X.ExitInterviewCompletedExits, 0) AS ExitInterviewCompletedExits,
    ISNULL(X.ExitSurveyedExits, 0) AS ExitSurveyedExits,
    ISNULL(X.ExitSurveyResponses, 0) AS ExitSurveyResponses,
    ISNULL(X.ExitSurveyQuestions, 0) AS ExitSurveyQuestions,
    ISNULL(X.EligibleForRehireExits, 0) AS EligibleForRehireExits,
    ISNULL(X.ClearedExits, 0) AS ClearedExits,
    CAST(
        CASE
            WHEN ((ISNULL(B.BeginningHeadcount, 0) + ISNULL(E.EndingHeadcount, 0)) / 2.0) = 0 THEN NULL
            ELSE (100.0 * ISNULL(X.Exits, 0)) / NULLIF(((ISNULL(B.BeginningHeadcount, 0) + ISNULL(E.EndingHeadcount, 0)) / 2.0), 0)
        END
        AS decimal(18, 2)
    ) AS TurnoverPct,
    CAST(
        CASE
            WHEN (ISNULL(B.BeginningHeadcount, 0) + ISNULL(H.Hires, 0)) = 0 THEN NULL
            ELSE (100.0 * ISNULL(E.EndingHeadcount, 0)) / NULLIF((ISNULL(B.BeginningHeadcount, 0) + ISNULL(H.Hires, 0)), 0)
        END
        AS decimal(18, 2)
    ) AS RetentionPct
FROM Periods AS P
OUTER APPLY (
    SELECT
        COUNT(DISTINCT EB.EmpId) AS Hires
    FROM EmployeeBase AS EB
    WHERE EB.HireDate BETWEEN P.PeriodStartDate AND P.PeriodEndDate
) AS H
OUTER APPLY (
    SELECT
        COUNT(DISTINCT EB.EmpId) AS BeginningHeadcount
    FROM EmployeeBase AS EB
    WHERE EB.HireDate < P.PeriodStartDate
      AND (EB.ExitDate IS NULL OR EB.ExitDate >= P.PeriodStartDate)
) AS B
OUTER APPLY (
    SELECT
        COUNT(DISTINCT EB.EmpId) AS EndingHeadcount
    FROM EmployeeBase AS EB
    WHERE EB.HireDate <= P.PeriodEndDate
      AND (EB.ExitDate IS NULL OR EB.ExitDate > P.PeriodEndDate)
) AS E
OUTER APPLY (
    SELECT
        COUNT(DISTINCT EE.EmpId) AS Exits,
        SUM(CASE WHEN EE.ExitReasonBucket = ''Voluntary'' THEN 1 ELSE 0 END) AS VoluntaryExits,
        SUM(CASE WHEN EE.ExitReasonBucket = ''Dismissal'' THEN 1 ELSE 0 END) AS DismissalExits,
        SUM(CASE WHEN EE.ExitReasonBucket = ''Retirement'' THEN 1 ELSE 0 END) AS RetirementExits,
        SUM(CASE WHEN EE.ExitReasonBucket = ''Redundancy'' THEN 1 ELSE 0 END) AS RedundancyExits,
        SUM(CASE WHEN EE.ExitReasonBucket = ''Contract End'' THEN 1 ELSE 0 END) AS ContractEndExits,
        SUM(CASE WHEN EE.ExitReasonBucket = ''Death'' THEN 1 ELSE 0 END) AS DeathExits,
        SUM(CASE WHEN EE.ExitReasonBucket = ''Other'' THEN 1 ELSE 0 END) AS OtherExits,
        SUM(EE.ExitInterviewCompletedFlag) AS ExitInterviewCompletedExits,
        SUM(EE.ExitSurveyCompletedFlag) AS ExitSurveyedExits,
        SUM(EE.ExitSurveyResponseCount) AS ExitSurveyResponses,
        SUM(EE.ExitSurveyQuestionCount) AS ExitSurveyQuestions,
        SUM(EE.EligibleForRehireFlag) AS EligibleForRehireExits,
        SUM(EE.ClearedFlag) AS ClearedExits
    FROM ExitEvents AS EE
    WHERE EE.ExitDate BETWEEN P.PeriodStartDate AND P.PeriodEndDate
) AS X;
');
