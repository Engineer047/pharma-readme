/*
bi_hr_recruitment

Purpose:
- New hires vs exits monthly and quarterly trend
- Offer acceptance rate
- Cost per hire placeholder

Design note:
- Grain is one row per period type and period start date
- Hires and exits come from dbo.ACC0001 to keep one employee = one event
- Offer acceptance comes from dbo.ACC0084 to keep one application = one event
- CostPerHire is returned as NULL because the supplied HRMIS DDL does not expose a direct recruitment cost table

Assumptions:
- Hire date = dbo.ACC0001.ED
- Exit date = dbo.ACC0001.TerminationDate
- Offer acceptance rate = accepted applications / decided applications
- Accepted application = dbo.ACC0084.Approved = 1
- Rejected application = dbo.ACC0084.Rejected = 1
- Application month is used as the cohort month because no approval/rejection date is available in dbo.ACC0084

SQL Server note:
- This script avoids GO because some clients send GO directly to SQL Server
*/

IF OBJECT_ID('dbo.bi_hr_recruitment', 'V') IS NOT NULL
    EXEC(N'DROP VIEW dbo.bi_hr_recruitment;');

EXEC(N'
CREATE VIEW dbo.bi_hr_recruitment
AS
WITH ApplicationBase AS (
    SELECT
        A.VacancyApplicationId,
        DATEFROMPARTS(YEAR(A.ApplicationDate), MONTH(A.ApplicationDate), 1) AS ApplicationMonthStart,
        CASE
            WHEN ISNULL(A.Approved, 0) = 1 THEN ''Accepted''
            WHEN ISNULL(A.Rejected, 0) = 1 THEN ''Rejected''
            ELSE ''Pending''
        END AS ApplicationOutcome
    FROM dbo.ACC0084 AS A
    WHERE A.ApplicationDate IS NOT NULL
),
DateBounds AS (
    SELECT
        COALESCE(MIN(D.EventMonth), DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)) AS MinMonth,
        COALESCE(MAX(D.EventMonth), DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1)) AS MaxMonth
    FROM (
        SELECT DATEFROMPARTS(YEAR(E.ED), MONTH(E.ED), 1) AS EventMonth
        FROM dbo.ACC0001 AS E
        WHERE E.ED IS NOT NULL

        UNION ALL

        SELECT DATEFROMPARTS(YEAR(E.TerminationDate), MONTH(E.TerminationDate), 1) AS EventMonth
        FROM dbo.ACC0001 AS E
        WHERE E.TerminationDate IS NOT NULL

        UNION ALL

        SELECT AB.ApplicationMonthStart
        FROM ApplicationBase AS AB
    ) AS D
),
Numbers AS (
    SELECT TOP (2400)
        ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1 AS Num
    FROM sys.all_objects AS A
    CROSS JOIN sys.all_objects AS B
),
MonthCalendar AS (
    SELECT
        CAST(DATEADD(MONTH, N.Num, DB.MinMonth) AS date) AS PeriodStartDate
    FROM DateBounds AS DB
    INNER JOIN Numbers AS N
        ON N.Num <= DATEDIFF(MONTH, DB.MinMonth, DB.MaxMonth)
),
HireMonthAgg AS (
    SELECT
        DATEFROMPARTS(YEAR(E.ED), MONTH(E.ED), 1) AS PeriodStartDate,
        COUNT(DISTINCT E.EmpId) AS NewHires
    FROM dbo.ACC0001 AS E
    WHERE E.ED IS NOT NULL
    GROUP BY DATEFROMPARTS(YEAR(E.ED), MONTH(E.ED), 1)
),
ExitMonthAgg AS (
    SELECT
        DATEFROMPARTS(YEAR(E.TerminationDate), MONTH(E.TerminationDate), 1) AS PeriodStartDate,
        COUNT(DISTINCT E.EmpId) AS Exits
    FROM dbo.ACC0001 AS E
    WHERE E.TerminationDate IS NOT NULL
    GROUP BY DATEFROMPARTS(YEAR(E.TerminationDate), MONTH(E.TerminationDate), 1)
),
ApplicationMonthAgg AS (
    SELECT
        AB.ApplicationMonthStart AS PeriodStartDate,
        COUNT(*) AS Applications,
        SUM(CASE WHEN AB.ApplicationOutcome = ''Accepted'' THEN 1 ELSE 0 END) AS OffersAccepted,
        SUM(CASE WHEN AB.ApplicationOutcome = ''Rejected'' THEN 1 ELSE 0 END) AS OffersRejected,
        SUM(CASE WHEN AB.ApplicationOutcome IN (''Accepted'', ''Rejected'') THEN 1 ELSE 0 END) AS OfferDecisions
    FROM ApplicationBase AS AB
    GROUP BY AB.ApplicationMonthStart
),
MonthlyBase AS (
    SELECT
        CAST(''Monthly'' AS varchar(20)) AS PeriodType,
        MC.PeriodStartDate,
        EOMONTH(MC.PeriodStartDate) AS PeriodEndDate,
        YEAR(MC.PeriodStartDate) AS CalendarYear,
        DATEPART(QUARTER, MC.PeriodStartDate) AS CalendarQuarter,
        MONTH(MC.PeriodStartDate) AS CalendarMonth,
        DATENAME(MONTH, MC.PeriodStartDate) AS MonthName,
        CONVERT(char(7), MC.PeriodStartDate, 120) AS PeriodLabel,
        ISNULL(H.NewHires, 0) AS NewHires,
        ISNULL(X.Exits, 0) AS Exits,
        ISNULL(H.NewHires, 0) - ISNULL(X.Exits, 0) AS NetHires,
        ISNULL(A.Applications, 0) AS Applications,
        ISNULL(A.OffersAccepted, 0) AS OffersAccepted,
        ISNULL(A.OffersRejected, 0) AS OffersRejected,
        ISNULL(A.OfferDecisions, 0) AS OfferDecisions,
        ISNULL(A.Applications, 0) - ISNULL(A.OfferDecisions, 0) AS OffersPending,
        CAST(
            CASE
                WHEN ISNULL(A.OfferDecisions, 0) = 0 THEN NULL
                ELSE (100.0 * ISNULL(A.OffersAccepted, 0)) / NULLIF(A.OfferDecisions, 0)
            END
            AS decimal(18, 2)
        ) AS OfferAcceptanceRatePct,
        CAST(NULL AS decimal(18, 2)) AS CostPerHire
    FROM MonthCalendar AS MC
    LEFT JOIN HireMonthAgg AS H
        ON MC.PeriodStartDate = H.PeriodStartDate
    LEFT JOIN ExitMonthAgg AS X
        ON MC.PeriodStartDate = X.PeriodStartDate
    LEFT JOIN ApplicationMonthAgg AS A
        ON MC.PeriodStartDate = A.PeriodStartDate
),
QuarterlyBase AS (
    SELECT
        CAST(''Quarterly'' AS varchar(20)) AS PeriodType,
        CAST(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, M.PeriodStartDate), 0) AS date) AS PeriodStartDate,
        CAST(EOMONTH(DATEADD(MONTH, 2, DATEADD(QUARTER, DATEDIFF(QUARTER, 0, M.PeriodStartDate), 0))) AS date) AS PeriodEndDate,
        YEAR(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, M.PeriodStartDate), 0)) AS CalendarYear,
        DATEPART(QUARTER, M.PeriodStartDate) AS CalendarQuarter,
        CAST(NULL AS int) AS CalendarMonth,
        CAST(NULL AS varchar(20)) AS MonthName,
        CONCAT(CAST(YEAR(M.PeriodStartDate) AS varchar(4)), '' Q'', CAST(DATEPART(QUARTER, M.PeriodStartDate) AS varchar(1))) AS PeriodLabel,
        SUM(M.NewHires) AS NewHires,
        SUM(M.Exits) AS Exits,
        SUM(M.NetHires) AS NetHires,
        SUM(M.Applications) AS Applications,
        SUM(M.OffersAccepted) AS OffersAccepted,
        SUM(M.OffersRejected) AS OffersRejected,
        SUM(M.OfferDecisions) AS OfferDecisions,
        SUM(M.OffersPending) AS OffersPending,
        CAST(
            CASE
                WHEN SUM(M.OfferDecisions) = 0 THEN NULL
                ELSE (100.0 * SUM(M.OffersAccepted)) / NULLIF(SUM(M.OfferDecisions), 0)
            END
            AS decimal(18, 2)
        ) AS OfferAcceptanceRatePct,
        CAST(NULL AS decimal(18, 2)) AS CostPerHire
    FROM MonthlyBase AS M
    GROUP BY
        CAST(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, M.PeriodStartDate), 0) AS date),
        CAST(EOMONTH(DATEADD(MONTH, 2, DATEADD(QUARTER, DATEDIFF(QUARTER, 0, M.PeriodStartDate), 0))) AS date),
        YEAR(DATEADD(QUARTER, DATEDIFF(QUARTER, 0, M.PeriodStartDate), 0)),
        DATEPART(QUARTER, M.PeriodStartDate),
        CONCAT(CAST(YEAR(M.PeriodStartDate) AS varchar(4)), '' Q'', CAST(DATEPART(QUARTER, M.PeriodStartDate) AS varchar(1)))
)
SELECT
    PeriodType,
    PeriodStartDate,
    PeriodEndDate,
    CalendarYear,
    CalendarQuarter,
    CalendarMonth,
    MonthName,
    PeriodLabel,
    NewHires,
    Exits,
    NetHires,
    Applications,
    OffersAccepted,
    OffersRejected,
    OfferDecisions,
    OffersPending,
    OfferAcceptanceRatePct,
    CostPerHire
FROM MonthlyBase

UNION ALL

SELECT
    PeriodType,
    PeriodStartDate,
    PeriodEndDate,
    CalendarYear,
    CalendarQuarter,
    CalendarMonth,
    MonthName,
    PeriodLabel,
    NewHires,
    Exits,
    NetHires,
    Applications,
    OffersAccepted,
    OffersRejected,
    OfferDecisions,
    OffersPending,
    OfferAcceptanceRatePct,
    CostPerHire
FROM QuarterlyBase;
');
