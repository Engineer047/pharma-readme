-- HRMIS.dbo.SALARIES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SALARIES;

CREATE TABLE HRMIS.dbo.SALARIES (
	EMPNO nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NAME nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BASICSALARY decimal(18,2) NULL
);
