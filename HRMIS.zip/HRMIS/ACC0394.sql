-- HRMIS.dbo.ACC0394 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0394;

CREATE TABLE HRMIS.dbo.ACC0394 (
	IccidentCategoryId int IDENTITY(1,1) NOT NULL,
	IccidentCategory nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0394 PRIMARY KEY (IccidentCategoryId)
);
