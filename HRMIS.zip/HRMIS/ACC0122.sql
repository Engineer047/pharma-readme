-- HRMIS.dbo.ACC0122 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0122;

CREATE TABLE HRMIS.dbo.ACC0122 (
	Id int IDENTITY(1,1) NOT NULL,
	IncomeBracket nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MaleEmps int NULL,
	FemaleEmps int NULL,
	Total int NULL,
	CONSTRAINT PK_ACC0122 PRIMARY KEY (Id)
);
