-- HRMIS.dbo.CLEARANCE definition

-- Drop table

-- DROP TABLE HRMIS.dbo.CLEARANCE;

CREATE TABLE HRMIS.dbo.CLEARANCE (
	ClearanceId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	Comments nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DepartmentId int NULL,
	MID int NULL,
	Remarks nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cleared bit DEFAULT 0 NULL,
	CONSTRAINT PK_CLEARANCE PRIMARY KEY (ClearanceId)
);
