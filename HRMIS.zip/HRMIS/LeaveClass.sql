-- HRMIS.dbo.LeaveClass definition

-- Drop table

-- DROP TABLE HRMIS.dbo.LeaveClass;

CREATE TABLE HRMIS.dbo.LeaveClass (
	LeaveId int IDENTITY(1,1) NOT NULL,
	LeaveName varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	MinUnit float DEFAULT 1 NOT NULL,
	Unit smallint DEFAULT 1 NOT NULL,
	RemaindProc smallint DEFAULT 1 NOT NULL,
	RemaindCount smallint DEFAULT 1 NOT NULL,
	ReportSymbol varchar(4) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '-' NOT NULL,
	Deduct float DEFAULT 0 NOT NULL,
	Color int DEFAULT 0 NOT NULL,
	Classify smallint DEFAULT 0 NOT NULL,
	Code char(16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__LeaveCla__796DB959DC7278F7 PRIMARY KEY (LeaveId)
);
