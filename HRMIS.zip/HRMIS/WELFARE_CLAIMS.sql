-- HRMIS.dbo.WELFARE_CLAIMS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.WELFARE_CLAIMS;

CREATE TABLE HRMIS.dbo.WELFARE_CLAIMS (
	WelfareClaimId int IDENTITY(1,1) NOT NULL,
	ClaimTypeId int NULL,
	EmpId int NULL,
	Claim nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount decimal(18,2) NULL,
	[Date] date NULL,
	Comments nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_WELFARE_CLAIMS PRIMARY KEY (WelfareClaimId)
);
