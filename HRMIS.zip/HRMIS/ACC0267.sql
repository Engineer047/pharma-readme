-- HRMIS.dbo.ACC0267 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0267;

CREATE TABLE HRMIS.dbo.ACC0267 (
	LoansUploadsId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	LoanId int NULL,
	Amount decimal(18,2) NULL,
	[Date] date NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Confirmed bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0267 PRIMARY KEY (LoansUploadsId)
);
