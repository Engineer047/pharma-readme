-- HRMIS.dbo.ACC0079 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0079;

CREATE TABLE HRMIS.dbo.ACC0079 (
	NewsId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NewsBrief nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NewsDetails nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ArchiveDate date NULL,
	Approaved bit NULL,
	CONSTRAINT PK_ACC0079 PRIMARY KEY (NewsId)
);
