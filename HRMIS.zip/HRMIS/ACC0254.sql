-- HRMIS.dbo.ACC0254 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0254;

CREATE TABLE HRMIS.dbo.ACC0254 (
	EmpSkillId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	SkillCategoryId int NULL,
	SkilIsd int NULL,
	CONSTRAINT PK_ACC0254 PRIMARY KEY (EmpSkillId)
);
