-- HRMIS.dbo.ACC0044_CASUALS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0044_CASUALS;

CREATE TABLE HRMIS.dbo.ACC0044_CASUALS (
	CasualEmpDocumentId int IDENTITY(1,1) NOT NULL,
	CasualEmpId int NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IssuedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IssueDate date NULL,
	CONSTRAINT PK_ACC0044_CASUALS PRIMARY KEY (CasualEmpDocumentId)
);
