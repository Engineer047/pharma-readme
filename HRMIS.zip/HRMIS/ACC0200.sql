-- HRMIS.dbo.ACC0200 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0200;

CREATE TABLE HRMIS.dbo.ACC0200 (
	RatingId int IDENTITY(1,1) NOT NULL,
	Rate nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Value nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0200 PRIMARY KEY (RatingId)
);
