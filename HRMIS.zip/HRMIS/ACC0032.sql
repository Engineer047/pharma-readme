-- HRMIS.dbo.ACC0032 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0032;

CREATE TABLE HRMIS.dbo.ACC0032 (
	SkillsId int IDENTITY(1,1) NOT NULL,
	SkillCategoryId int NULL,
	Skill nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0032 PRIMARY KEY (SkillsId)
);
