-- HRMIS.dbo.ACC0237 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0237;

CREATE TABLE HRMIS.dbo.ACC0237 (
	TravelExpenseId int NOT NULL,
	TravelId int NULL,
	EmpId int NULL,
	Transportation decimal(18,2) NULL,
	Lodging decimal(18,2) NULL,
	Fares decimal(18,2) NULL,
	CarRental decimal(18,2) NULL,
	Parking decimal(18,2) NULL,
	Other decimal(18,2) NULL,
	TotalExpense decimal(18,2) NULL,
	CONSTRAINT PK_ACC0237 PRIMARY KEY (TravelExpenseId)
);
