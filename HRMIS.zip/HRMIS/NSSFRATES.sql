-- HRMIS.dbo.NSSFRATES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.NSSFRATES;

CREATE TABLE HRMIS.dbo.NSSFRATES (
	NssfBracketId int IDENTITY(1,1) NOT NULL,
	Rate decimal(18,2) NULL,
	LowerLimit decimal(18,2) NULL,
	UpperLimit decimal(18,2) NULL,
	NssfAmount decimal(18,2) NULL,
	CONSTRAINT PK_NSSFRATES PRIMARY KEY (NssfBracketId)
);
