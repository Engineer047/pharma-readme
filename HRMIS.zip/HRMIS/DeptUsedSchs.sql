-- HRMIS.dbo.DeptUsedSchs definition

-- Drop table

-- DROP TABLE HRMIS.dbo.DeptUsedSchs;

CREATE TABLE HRMIS.dbo.DeptUsedSchs (
	DeptId int NOT NULL,
	SchId int NOT NULL,
	CONSTRAINT DEPT_USED_SCH PRIMARY KEY (DeptId,SchId)
);
