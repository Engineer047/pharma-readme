-- HRMIS.dbo.aspnet_Roles definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_Roles;

CREATE TABLE HRMIS.dbo.aspnet_Roles (
	ApplicationId uniqueidentifier NOT NULL,
	RoleId uniqueidentifier DEFAULT newid() NOT NULL,
	RoleName nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	LoweredRoleName nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Description nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__aspnet_R__8AFACE1B533C0A0F PRIMARY KEY (RoleId),
	CONSTRAINT FK__aspnet_Ro__Appli__5748DA5E FOREIGN KEY (ApplicationId) REFERENCES HRMIS.dbo.aspnet_Applications(ApplicationId)
);
 CREATE UNIQUE CLUSTERED INDEX aspnet_Roles_index1 ON HRMIS.dbo.aspnet_Roles (  ApplicationId ASC  , LoweredRoleName ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
