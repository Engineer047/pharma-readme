-- HRMIS.dbo.ACC0202 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0202;

CREATE TABLE HRMIS.dbo.ACC0202 (
	CompetencyAssignmentId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NOT NULL,
	EmpId int NULL,
	AppraiserId int NULL,
	CompetencyFactorsId int NULL,
	Score decimal(18,2) NULL,
	OutOf decimal(18,2) DEFAULT 3.00 NULL,
	Comments nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Assessed bit NULL,
	CONSTRAINT PK_ACC0202 PRIMARY KEY (CompetencyAssignmentId,AppraisalId)
);
