-- HRMIS.dbo.ACC0199 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0199;

CREATE TABLE HRMIS.dbo.ACC0199 (
	MetricId int IDENTITY(1,1) NOT NULL,
	Metric nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0199 PRIMARY KEY (MetricId)
);
