-- HRMIS.dbo.ACC0208 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0208;

CREATE TABLE HRMIS.dbo.ACC0208 (
	BudgetId int IDENTITY(1,1) NOT NULL,
	BudgetPeriodName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StartDate date NULL,
	EndDate date NULL,
	Description nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0208 PRIMARY KEY (BudgetId)
);
