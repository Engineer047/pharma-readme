-- HRMIS.dbo.DDD definition

-- Drop table

-- DROP TABLE HRMIS.dbo.DDD;

CREATE TABLE HRMIS.dbo.DDD (
	DOB date NULL,
	ED date NULL,
	EMPNO nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
