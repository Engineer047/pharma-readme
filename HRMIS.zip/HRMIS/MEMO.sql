-- HRMIS.dbo.MEMO definition

-- Drop table

-- DROP TABLE HRMIS.dbo.MEMO;

CREATE TABLE HRMIS.dbo.MEMO (
	MemoId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MemoDate date NULL,
	Comments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Seen bit DEFAULT 0 NOT NULL,
	CategoryId int NULL,
	ResponseDate date NULL,
	Response nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ResponseBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_MEMO PRIMARY KEY (MemoId)
);
