-- HRMIS.dbo.ACC0002 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0002;

CREATE TABLE HRMIS.dbo.ACC0002 (
	CompanyId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Initials nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Locked int NULL,
	PINNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NSSFNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NHIFNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	REGNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhysicalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellPhone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Fax nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CompanyLogo varbinary(MAX) NULL,
	LogoName varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContentType varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankId int NULL,
	CONSTRAINT PK_ACC0002 PRIMARY KEY (CompanyId)
);
