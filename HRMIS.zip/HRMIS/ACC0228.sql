-- HRMIS.dbo.ACC0228 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0228;

CREATE TABLE HRMIS.dbo.ACC0228 (
	ContactId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StreetAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalCode int NULL,
	Town nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Country nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	HomeTel nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	WorkTel nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Mobile nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmailAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContactPerson nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmergencyMobile nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmergencyRelation nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0228 PRIMARY KEY (ContactId)
);
