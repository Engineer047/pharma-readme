-- HRMIS.dbo.NOKUpload definition

-- Drop table

-- DROP TABLE HRMIS.dbo.NOKUpload;

CREATE TABLE HRMIS.dbo.NOKUpload (
	NOKUploadId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Relationship nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Organization nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitle nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Notes nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Profession nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellPhone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhysicalAddress nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Confirmed bit NULL,
	CONSTRAINT PK_NOKUpload PRIMARY KEY (NOKUploadId)
);
