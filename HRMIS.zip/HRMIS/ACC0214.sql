-- HRMIS.dbo.ACC0214 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0214;

CREATE TABLE HRMIS.dbo.ACC0214 (
	TerminationReasonId int IDENTITY(1,1) NOT NULL,
	TermnationReason nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0214 PRIMARY KEY (TerminationReasonId)
);
