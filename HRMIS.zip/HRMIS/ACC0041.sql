-- HRMIS.dbo.ACC0041 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0041;

CREATE TABLE HRMIS.dbo.ACC0041 (
	EmployeeReferreeId int IDENTITY(1,1) NOT NULL,
	ReferreeId int NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0041 PRIMARY KEY (EmployeeReferreeId)
);
