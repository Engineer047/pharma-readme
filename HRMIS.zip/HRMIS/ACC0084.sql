-- HRMIS.dbo.ACC0084 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0084;

CREATE TABLE HRMIS.dbo.ACC0084 (
	VacancyApplicationId int IDENTITY(1,1) NOT NULL,
	VacancyRequisitionId int NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	CandidateId int NULL,
	ApplicationDate date NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Notes ntext COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CVUrl nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellPhone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	InterviewScheduled bit DEFAULT 0 NULL,
	Approved bit DEFAULT 0 NULL,
	Rejected bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0084 PRIMARY KEY (VacancyApplicationId)
);
