-- HRMIS.dbo.WEEKS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.WEEKS;

CREATE TABLE HRMIS.dbo.WEEKS (
	WeekId bigint IDENTITY(1,1) NOT NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	WeekNo int NULL,
	WeekName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	WeekFrom date NULL,
	WeekTo date NULL,
	Days AS (datediff(day,[WeekFrom],[WeekTo])+(1)),
	FullWeek AS ((((([WeekName]+N' (')+CONVERT([varchar](10),[WeekFrom],(103)))+N' to ')+CONVERT([varchar](10),[WeekTo],(103)))+')'),
	Active bit DEFAULT 1 NULL,
	CONSTRAINT PK_WEEKS PRIMARY KEY (WeekId)
);
