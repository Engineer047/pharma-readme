-- HRMIS.dbo.ACC0179 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0179;

CREATE TABLE HRMIS.dbo.ACC0179 (
	InfractionOriginId nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	InfractionOrigin nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0179 PRIMARY KEY (InfractionOriginId)
);
