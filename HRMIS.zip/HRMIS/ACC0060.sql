-- HRMIS.dbo.ACC0060 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0060;

CREATE TABLE HRMIS.dbo.ACC0060 (
	CashualPayrollId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Month] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Year] int NULL,
	Paid bit NULL,
	TotalAmount float NULL,
	AmountPaid float NULL,
	BalanceAmount float NULL,
	NSSF float NULL,
	NHIF float NULL,
	PAYE float NULL,
	Taxable float NULL,
	Gross float NULL,
	PayrollDate date NULL,
	CONSTRAINT PK_ACC0060 PRIMARY KEY (CashualPayrollId)
);
