-- HRMIS.dbo.ACC0275 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0275;

CREATE TABLE HRMIS.dbo.ACC0275 (
	InterviewTypeId int IDENTITY(1,1) NOT NULL,
	InterviewType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0275 PRIMARY KEY (InterviewTypeId)
);
