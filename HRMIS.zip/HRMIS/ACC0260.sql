-- HRMIS.dbo.ACC0260 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0260;

CREATE TABLE HRMIS.dbo.ACC0260 (
	DutyCategoryId int IDENTITY(1,1) NOT NULL,
	DutyCategory nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0260 PRIMARY KEY (DutyCategoryId)
);
