-- HRMIS.dbo.ACC0098 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0098;

CREATE TABLE HRMIS.dbo.ACC0098 (
	CustomParameterId int NOT NULL,
	CompanyId int NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Amount decimal(18,2) NULL,
	ParameterType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpCustomParameterId int IDENTITY(1,1) NOT NULL,
	CustomParameter nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	CustomParameterType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cancelled bit DEFAULT 0 NULL,
	Locked bit DEFAULT 0 NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TotalAmount AS ([dbo].[GetTotalInsurance]([EmpId],[CustomParameterId],[MonthId],[YearId])),
	OpeningBalance decimal(18,2) NULL,
	YearMonth AS ([dbo].[fGetPensionYearMonthJoint]([MonthId],[YearId])),
	IsInsurance bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0098 PRIMARY KEY (EmpCustomParameterId)
);
