-- HRMIS.dbo.ACTimeZones definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACTimeZones;

CREATE TABLE HRMIS.dbo.ACTimeZones (
	TimeZoneID smallint NOT NULL,
	Name varchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SunStart datetime NULL,
	SunEnd datetime NULL,
	MonStart datetime NULL,
	MonEnd datetime NULL,
	TuesStart datetime NULL,
	TuesEnd datetime NULL,
	WedStart datetime NULL,
	WedEnd datetime NULL,
	ThursStart datetime NULL,
	ThursEnd datetime NULL,
	FriStart datetime NULL,
	FriEnd datetime NULL,
	SatStart datetime NULL,
	SatEnd datetime NULL,
	CONSTRAINT PK__ACTimeZo__78D387CFE3EA8F31 PRIMARY KEY (TimeZoneID)
);
