-- HRMIS.dbo.ACC0109 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0109;

CREATE TABLE HRMIS.dbo.ACC0109 (
	LoanInterestId int IDENTITY(1,1) NOT NULL,
	[Year] int NULL,
	MonthId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LoanInterest decimal(18,4) NULL,
	CONSTRAINT PK_LoanInterest PRIMARY KEY (LoanInterestId)
);
