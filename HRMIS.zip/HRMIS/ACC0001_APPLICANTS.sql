-- HRMIS.dbo.ACC0001_APPLICANTS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0001_APPLICANTS;

CREATE TABLE HRMIS.dbo.ACC0001_APPLICANTS (
	EmpId int IDENTITY(1,1) NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitleId int NULL,
	GenderId int NULL,
	SalutationId int NULL,
	MaritalStatusId int NULL,
	CountryId int NULL,
	FirstName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MiddleName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LastName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name AS (((([FirstName]+N' ')+[MiddleName])+N' ')+[LastName]),
	PassportNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DrivingLicenseNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PINNumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IDNumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NSSFNumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NHIFNumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	HospitalNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellPhone nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmailAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DOB date NULL,
	PassportPhotoUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT N'~/PassportPhotos/PassportIcon.jpg' NULL,
	CVUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Active bit DEFAULT 1 NULL,
	HomeDistrict nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Appointed bit DEFAULT 0 NULL,
	[Search] AS (((((([EmpNo]+N' ')+[FirstName])+N' ')+[MiddleName])+N' ')+[LastName]),
	Score decimal(18,2) NULL,
	InterviewDate date NULL,
	CONSTRAINT PK_ACC0001_APPLICANTS PRIMARY KEY (EmpId)
);
