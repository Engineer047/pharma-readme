-- HRMIS.dbo.SHARES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.SHARES;

CREATE TABLE HRMIS.dbo.SHARES (
	EmpSaccoId int IDENTITY(1,1) NOT NULL,
	SaccoId int NOT NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Amount decimal(18,2) NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Sacco nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LogDate datetime DEFAULT getdate() NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	TotalAmount AS ([dbo].[GetSaccoTotalShares]([EmpId],[SaccoId])),
	CONSTRAINT PK_SHARES PRIMARY KEY (EmpSaccoId)
);
