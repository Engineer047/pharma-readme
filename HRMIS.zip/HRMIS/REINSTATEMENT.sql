-- HRMIS.dbo.REINSTATEMENT definition

-- Drop table

-- DROP TABLE HRMIS.dbo.REINSTATEMENT;

CREATE TABLE HRMIS.dbo.REINSTATEMENT (
	Id int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateReinstated date NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Reason nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateSuspended date NULL,
	DocumentURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_REINSTATEMENT PRIMARY KEY (Id)
);
