-- HRMIS.dbo.ACC0232 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0232;

CREATE TABLE HRMIS.dbo.ACC0232 (
	EmpLanguageId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	LanguageId int NULL,
	FluencyId int NULL,
	CompetencyId int NULL,
	Comments nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0232 PRIMARY KEY (EmpLanguageId)
);
