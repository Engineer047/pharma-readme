-- HRMIS.dbo.ACC0218 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0218;

CREATE TABLE HRMIS.dbo.ACC0218 (
	TransferTypeId int IDENTITY(1,1) NOT NULL,
	TransferType nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0218 PRIMARY KEY (TransferTypeId)
);
