-- HRMIS.dbo.ACC0219 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0219;

CREATE TABLE HRMIS.dbo.ACC0219 (
	EmpTransfersId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	CompanyId int NULL,
	DestinationCompanyId int NULL,
	BranchId int NULL,
	DestinationBranchId int NULL,
	OfficeId int NULL,
	DestinationOfficeId int NULL,
	DivisionId int NULL,
	DestinationDivisionId int NULL,
	Deptid int NULL,
	DestinationDeptId int NULL,
	SectionId int NULL,
	DestinationSectionId int NULL,
	JobTitleId int NULL,
	DestinationJobTitleId int NULL,
	JobGroupId int NULL,
	DestinationJobGroupId int NULL,
	JobGradeId int NULL,
	DestinationJobGradeId int NULL,
	BasicSalary decimal(18,2) NULL,
	DestinationBasicSalary decimal(18,2) NULL,
	StartDate date NULL,
	TransferReason nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	TransferTypeId int NULL,
	TransferAllowance decimal(18,2) NULL,
	Narrative nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Ref] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ManagerId int NULL,
	DestinationManagerId int NULL,
	Processing bit DEFAULT 0 NULL,
	Approved bit DEFAULT 0 NULL,
	Cancelled bit DEFAULT 0 NULL,
	ApprovedDate date NULL,
	Comment nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0219 PRIMARY KEY (EmpTransfersId)
);
