﻿$root = 'C:\Users\steph\Desktop\Power BI Project\Scripts\HRMIS'
$rawFile = Join-Path $root '_raw_ddl_from_session.sql'
$text = Get-Content -Raw -Path $rawFile
$start = $text.IndexOf('-- DROP SCHEMA dbo;')
if ($start -lt 0) { throw 'SQL start marker not found.' }
$sql = $text.Substring($start)
$firstView = [regex]::Match($sql, '(?m)^-- dbo\.[^\r\n]+ source\s*$')
$sqlTables = if ($firstView.Success) { $sql.Substring(0, $firstView.Index) } else { $sql }

$sourceFile = Join-Path $root '_source_tables_only.sql'
[System.IO.File]::WriteAllText($sourceFile, $sqlTables.Trim() + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))

$schemaMatch = [regex]::Match($sqlTables, '(?s)^\s*(-- DROP SCHEMA dbo;\s*\r?\n\s*CREATE SCHEMA dbo;\s*)')
if ($schemaMatch.Success) {
  $schemaFile = Join-Path $root '00_schema.sql'
  [System.IO.File]::WriteAllText($schemaFile, $schemaMatch.Groups[1].Value.Trim() + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
}

$pattern = '(?m)^-- HRMIS\.dbo\.(.+?) definition\s*$'
$matches = [regex]::Matches($sqlTables, $pattern)
if ($matches.Count -eq 0) { throw 'No table definitions found.' }

Get-ChildItem -Path $root -File -Filter '*.sql' |
  Where-Object { $_.Name -notin @('_raw_ddl_from_session.sql','_source_tables_only.sql','00_schema.sql') } |
  Remove-Item -Force

$tableNames = New-Object System.Collections.Generic.List[string]
for ($i = 0; $i -lt $matches.Count; $i++) {
  $name = $matches[$i].Groups[1].Value.Trim()
  $blockStart = $matches[$i].Index
  $blockEnd = if ($i -lt $matches.Count - 1) { $matches[$i + 1].Index } else { $sqlTables.Length }
  $block = $sqlTables.Substring($blockStart, $blockEnd - $blockStart).Trim()
  $safeName = ($name -replace '[\[\]]','')
  $filePath = Join-Path $root ($safeName + '.sql')
  [System.IO.File]::WriteAllText($filePath, $block + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))
  $tableNames.Add($safeName)
}

$readmeLines = @(
  '# HRMIS Tables',
  '',
  'This folder was generated from the HRMIS table DDL you pasted into the session on 2026-03-22.',
  '',
  '- `00_schema.sql`: schema creation statement.',
  '- `_source_tables_only.sql`: full extracted table-only DDL source.',
  '- `*.sql`: one file per table definition, preserving the original table block from the DDL.',
  '',
  '## Table Count',
  '',
  "$($tableNames.Count) tables extracted.",
  '',
  '## Tables',
  ''
)
$readmeLines += $tableNames | ForEach-Object { '- `' + $_ + '.sql`' }
[System.IO.File]::WriteAllText((Join-Path $root 'README.md'), ($readmeLines -join [Environment]::NewLine) + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))

Write-Output ('Generated=' + $tableNames.Count)
