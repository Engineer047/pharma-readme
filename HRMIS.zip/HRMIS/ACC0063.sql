-- HRMIS.dbo.ACC0063 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0063;

CREATE TABLE HRMIS.dbo.ACC0063 (
	CashualPayrollScheduleId int IDENTITY(1,1) NOT NULL,
	[Year] int NULL,
	[Month] int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PSFrom date NULL,
	PSTo date NULL,
	Closed bit NULL,
	ClosedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ProcessedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ApproavedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0063 PRIMARY KEY (CashualPayrollScheduleId)
);
