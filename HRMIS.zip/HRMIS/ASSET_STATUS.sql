-- HRMIS.dbo.ASSET_STATUS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ASSET_STATUS;

CREATE TABLE HRMIS.dbo.ASSET_STATUS (
	AssetStatusId int IDENTITY(1,1) NOT NULL,
	AssetStatus nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ASSET_STATUS PRIMARY KEY (AssetStatusId)
);
