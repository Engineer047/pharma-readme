-- HRMIS.dbo.ACC0146 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0146;

CREATE TABLE HRMIS.dbo.ACC0146 (
	ManagerId int IDENTITY(1,1) NOT NULL,
	MNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MId int NULL,
	MName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DepartmentId int NULL,
	CONSTRAINT PK_ACC0146 PRIMARY KEY (ManagerId)
);
