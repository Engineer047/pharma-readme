-- HRMIS.dbo.ACC0068 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0068;

CREATE TABLE HRMIS.dbo.ACC0068 (
	EmpGoalId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	GoalId int NULL,
	Metric nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Weight decimal(18,2) NULL,
	StartDate date NULL,
	DueDate date NULL,
	PercentComplete decimal(18,2) NULL,
	StatusId int NULL,
	MilestoneId int NULL,
	SubgoalId int NULL,
	SystemDate datetime NULL,
	CategoryId int NULL,
	VisibilityId int NULL,
	RatingId int NULL,
	Goal nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Comments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FormId int NULL,
	ManRatingId int NULL,
	ManComments nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpScores decimal(18,2) NULL,
	ManScores decimal(18,2) NULL,
	CONSTRAINT PK_ACC0068 PRIMARY KEY (EmpGoalId),
	CONSTRAINT FK_ACC0068_ACC0137 FOREIGN KEY (GoalId) REFERENCES HRMIS.dbo.ACC0137(GoalId)
);
