-- HRMIS.dbo.LeaveClass1 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.LeaveClass1;

CREATE TABLE HRMIS.dbo.LeaveClass1 (
	LeaveId int IDENTITY(999,1) NOT NULL,
	LeaveName varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	MinUnit float DEFAULT 1 NOT NULL,
	Unit smallint DEFAULT 0 NOT NULL,
	RemaindProc smallint DEFAULT 2 NOT NULL,
	RemaindCount smallint DEFAULT 1 NOT NULL,
	ReportSymbol varchar(4) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '-' NOT NULL,
	Deduct float DEFAULT 0 NOT NULL,
	LeaveType smallint DEFAULT 0 NOT NULL,
	Color int DEFAULT 0 NOT NULL,
	Classify smallint DEFAULT 0 NOT NULL,
	Calc text COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code char(16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__LeaveCla__796DB95988C27537 PRIMARY KEY (LeaveId)
);
