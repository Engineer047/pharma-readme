-- HRMIS.dbo.STAFF_UNIFORMS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.STAFF_UNIFORMS;

CREATE TABLE HRMIS.dbo.STAFF_UNIFORMS (
	StaffUniformId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	UniformTypeId int NULL,
	Pieces int NULL,
	UnitCost decimal(18,2) NULL,
	TotalCost AS ([Pieces]*[UnitCost]),
	Refundable bit DEFAULT 0 NULL,
	Chargeable bit DEFAULT 0 NULL,
	DateIssued date NULL,
	MonthsToExpire AS ([dbo].[fGetUniformMonthsToExpire]([ExpiryDate])),
	ExpiryDate date NULL,
	Renewed bit DEFAULT 0 NULL,
	Expired AS ([dbo].[fGetUniformExpired]([StaffUniformId])),
	AmountRefunded decimal(18,2) DEFAULT 0 NULL,
	Refunded bit DEFAULT 0 NULL,
	DateRefunded date NULL,
	Comments nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_STAFF_UNIFORMS PRIMARY KEY (StaffUniformId)
);
