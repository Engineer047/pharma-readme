-- HRMIS.dbo.WELFARE_DEDUCTIONS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.WELFARE_DEDUCTIONS;

CREATE TABLE HRMIS.dbo.WELFARE_DEDUCTIONS (
	StaffId int IDENTITY(1,1) NOT NULL,
	StaffNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount decimal(18,2) NULL,
	[Month] int NULL,
	[Year] int NULL,
	Confirmed int NULL,
	CONSTRAINT PK_WELFARE_DEDUCTIONS_1 PRIMARY KEY (StaffId)
);
