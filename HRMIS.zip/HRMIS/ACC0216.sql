-- HRMIS.dbo.ACC0216 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0216;

CREATE TABLE HRMIS.dbo.ACC0216 (
	TypeOfTerminationId int IDENTITY(1,1) NOT NULL,
	TypeOfTermination nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0216 PRIMARY KEY (TypeOfTerminationId)
);
