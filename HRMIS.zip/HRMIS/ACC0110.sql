-- HRMIS.dbo.ACC0110 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0110;

CREATE TABLE HRMIS.dbo.ACC0110 (
	FeedbackId int IDENTITY(1,1) NOT NULL,
	Subject nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Details nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0110 PRIMARY KEY (FeedbackId)
);
