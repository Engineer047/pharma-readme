-- HRMIS.dbo.ExceptionLog definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ExceptionLog;

CREATE TABLE HRMIS.dbo.ExceptionLog (
	LogId int IDENTITY(1,1) NOT NULL,
	ErrorMessage nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	ErrorStackTrace nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LogDateTime datetime NOT NULL,
	ModuleName nvarchar(150) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FunctionName nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ExceptionLog PRIMARY KEY (LogId)
);
