-- HRMIS.dbo.ACC0150 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0150;

CREATE TABLE HRMIS.dbo.ACC0150 (
	EAGLEModuleId int IDENTITY(1,1) NOT NULL,
	Module nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsLisenced bit NULL,
	ActivationDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0150 PRIMARY KEY (EAGLEModuleId)
);
