-- HRMIS.dbo.StaffDetails definition

-- Drop table

-- DROP TABLE HRMIS.dbo.StaffDetails;

CREATE TABLE HRMIS.dbo.StaffDetails (
	StaffId int IDENTITY(1,1) NOT NULL,
	StaffNo nvarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	CONSTRAINT PK_StaffDetails PRIMARY KEY (StaffId)
);
