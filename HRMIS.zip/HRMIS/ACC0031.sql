-- HRMIS.dbo.ACC0031 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0031;

CREATE TABLE HRMIS.dbo.ACC0031 (
	PerformanceReviewScheduleId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime NULL,
	CONSTRAINT PK_ACC0031 PRIMARY KEY (PerformanceReviewScheduleId)
);
