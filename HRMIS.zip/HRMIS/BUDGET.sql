-- HRMIS.dbo.BUDGET definition

-- Drop table

-- DROP TABLE HRMIS.dbo.BUDGET;

CREATE TABLE HRMIS.dbo.BUDGET (
	BudgetId int IDENTITY(1,1) NOT NULL,
	DepartmentId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Amount decimal(18,2) NULL,
	Narration nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_BUDGET PRIMARY KEY (BudgetId)
);
