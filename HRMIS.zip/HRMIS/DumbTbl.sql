-- HRMIS.dbo.DumbTbl definition

-- Drop table

-- DROP TABLE HRMIS.dbo.DumbTbl;

CREATE TABLE HRMIS.dbo.DumbTbl (
	AllowanceiD int NULL,
	JobGrade nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Rate decimal(18,2) NULL,
	JobGradeId int NULL
);
