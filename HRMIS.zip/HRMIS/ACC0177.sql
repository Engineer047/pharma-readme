-- HRMIS.dbo.ACC0177 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0177;

CREATE TABLE HRMIS.dbo.ACC0177 (
	InfractionActionId int IDENTITY(1,1) NOT NULL,
	ActionTaken nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0177 PRIMARY KEY (InfractionActionId)
);
