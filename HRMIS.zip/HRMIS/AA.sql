-- HRMIS.dbo.AA definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AA;

CREATE TABLE HRMIS.dbo.AA (
	employeeid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	employeenumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	pinnumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	nationalid nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	nssfnumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	nhifnumber nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	firstname nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	lastname nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	middlename nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	title nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	designition nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	gender nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	emailaddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	cellphone nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	passport ntext COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	dateofemployment nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	contractend nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	employmentperiod nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	periodworked nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	active nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	sucked nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	fullname nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[year] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	othername nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	genderid int NULL,
	salutationid int NULL
);
