-- HRMIS.dbo.ACC0289 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0289;

CREATE TABLE HRMIS.dbo.ACC0289 (
	ExpenseTypeId int IDENTITY(1,1) NOT NULL,
	ExpenseType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthlyLimit float NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0289 PRIMARY KEY (ExpenseTypeId)
);
