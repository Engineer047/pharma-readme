-- HRMIS.dbo.ACC0277 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0277;

CREATE TABLE HRMIS.dbo.ACC0277 (
	CandidateScoreId int IDENTITY(1,1) NOT NULL,
	QuestionId int NULL,
	VacancyRequisitionId int NULL,
	VacancyApplicationId int NULL,
	CandidateId int NULL,
	Score decimal(18,2) NULL,
	TotalScore decimal(18,2) NULL,
	TotalMarks decimal(18,2) NULL,
	TotalScoreMarks decimal(18,2) NULL,
	CONSTRAINT PK_ACC0277 PRIMARY KEY (CandidateScoreId)
);
