-- HRMIS.dbo.ACC0072 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0072;

CREATE TABLE HRMIS.dbo.ACC0072 (
	InterceptionFormId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0072 PRIMARY KEY (InterceptionFormId)
);
