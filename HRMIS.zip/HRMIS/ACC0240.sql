-- HRMIS.dbo.ACC0240 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0240;

CREATE TABLE HRMIS.dbo.ACC0240 (
	AdvanceInterestId int IDENTITY(1,1) NOT NULL,
	AdvanceInterest decimal(18,2) NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0240 PRIMARY KEY (AdvanceInterestId)
);
