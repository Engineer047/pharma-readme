-- HRMIS.dbo.ACC0252 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0252;

CREATE TABLE HRMIS.dbo.ACC0252 (
	TestId int IDENTITY(1,1) NOT NULL,
	Test nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0252 PRIMARY KEY (TestId)
);
