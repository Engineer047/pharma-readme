-- HRMIS.dbo.ACC0248 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0248;

CREATE TABLE HRMIS.dbo.ACC0248 (
	AssetCategoryId int IDENTITY(1,1) NOT NULL,
	AssetCategory nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__ACC0248__C381F47D648DD21B PRIMARY KEY (AssetCategoryId)
);
