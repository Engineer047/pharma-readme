-- HRMIS.dbo.ACC0235 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0235;

CREATE TABLE HRMIS.dbo.ACC0235 (
	LanguageId int IDENTITY(1,1) NOT NULL,
	[Language] nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0235 PRIMARY KEY (LanguageId)
);
