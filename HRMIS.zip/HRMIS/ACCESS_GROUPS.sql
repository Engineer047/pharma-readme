-- HRMIS.dbo.ACCESS_GROUPS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACCESS_GROUPS;

CREATE TABLE HRMIS.dbo.ACCESS_GROUPS (
	AccessTypeId int IDENTITY(1,1) NOT NULL,
	CompanyId int NULL,
	UserId uniqueidentifier NULL,
	CONSTRAINT PK_ACCESS_GROUPS PRIMARY KEY (AccessTypeId)
);
