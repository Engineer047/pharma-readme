-- HRMIS.dbo.b definition

-- Drop table

-- DROP TABLE HRMIS.dbo.b;

CREATE TABLE HRMIS.dbo.b (
	AmountPaid decimal(18,4) NULL,
	Balance decimal(18,4) NULL,
	Id int IDENTITY(1,1) NOT NULL,
	Total decimal(18,4) NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_b PRIMARY KEY (Id)
);
