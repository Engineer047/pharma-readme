-- HRMIS.dbo.[ACC0053.01] definition

-- Drop table

-- DROP TABLE HRMIS.dbo.[ACC0053.01];

CREATE TABLE HRMIS.dbo.[ACC0053.01] (
	MinuteAwardId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SysDate datetime NULL,
	[Date] date NULL,
	YearId int NULL,
	MonthId int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Minutes int NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Paid int NULL,
	Rate decimal(18,2) NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cancelled bit DEFAULT 0 NULL,
	PostedBy nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount decimal(18,2) NULL,
	Locked bit DEFAULT 0 NULL,
	Allowance nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT [PK_ACC0053.01] PRIMARY KEY (MinuteAwardId)
);
