-- HRMIS.dbo.ACC0044 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0044;

CREATE TABLE HRMIS.dbo.ACC0044 (
	EmpDocumentId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EntryDate date NULL,
	IssuedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IssueDate date NULL,
	ExpiryDate date NULL,
	Deleted bit DEFAULT 0 NULL,
	DeletedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateDeleted date NULL,
	ReasonDeleted nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0044_1 PRIMARY KEY (EmpDocumentId)
);
