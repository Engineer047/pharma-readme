-- HRMIS.dbo.ACC0184 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0184;

CREATE TABLE HRMIS.dbo.ACC0184 (
	ExitInterviewId int NOT NULL,
	EmpId int NOT NULL,
	ExitQuestionId int IDENTITY(1,1) NOT NULL,
	QuestionNoId int NULL,
	Respose nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0184 PRIMARY KEY (ExitInterviewId,EmpId,ExitQuestionId)
);
