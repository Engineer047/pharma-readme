-- HRMIS.dbo.ACC0206 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0206;

CREATE TABLE HRMIS.dbo.ACC0206 (
	AppraiserFeedbackId int IDENTITY(1,1) NOT NULL,
	AppraisalId int NULL,
	AppraiserId int NULL,
	EmpId int NULL,
	OveralPerformance nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	KeyStrenghts nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	GrowthAreas nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FutureRecommendation nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RecommendationReasons nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0206 PRIMARY KEY (AppraiserFeedbackId)
);
