-- HRMIS.dbo.ACC0011 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0011;

CREATE TABLE HRMIS.dbo.ACC0011 (
	GenderId int IDENTITY(1,1) NOT NULL,
	Gender nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0011 PRIMARY KEY (GenderId)
);
