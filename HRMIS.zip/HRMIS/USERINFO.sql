-- HRMIS.dbo.USERINFO definition

-- Drop table

-- DROP TABLE HRMIS.dbo.USERINFO;

CREATE TABLE HRMIS.dbo.USERINFO (
	USERID int IDENTITY(1,1) NOT NULL,
	BADGENUMBER varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	SSN varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NAME varchar(40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	GENDER varchar(8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TITLE varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PAGER varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BIRTHDAY datetime NULL,
	HIREDDAY datetime NULL,
	STREET varchar(80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CITY varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	STATE varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ZIP varchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	OPHONE varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FPHONE varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	VERIFICATIONMETHOD smallint NULL,
	DEFAULTDEPTID smallint DEFAULT 1 NULL,
	SECURITYFLAGS smallint NULL,
	ATT smallint DEFAULT 1 NOT NULL,
	INLATE smallint DEFAULT 1 NOT NULL,
	OUTEARLY smallint DEFAULT 1 NOT NULL,
	OVERTIME smallint DEFAULT 1 NOT NULL,
	SEP smallint DEFAULT 1 NOT NULL,
	HOLIDAY smallint DEFAULT 1 NOT NULL,
	MINZU varchar(8) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PASSWORD varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LUNCHDURATION smallint DEFAULT 1 NOT NULL,
	MVerifyPass varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PHOTO image NULL,
	Notes image NULL,
	privilege int DEFAULT 0 NULL,
	InheritDeptSch smallint DEFAULT 1 NULL,
	InheritDeptSchClass smallint DEFAULT 1 NULL,
	AutoSchPlan smallint DEFAULT 1 NULL,
	MinAutoSchInterval int DEFAULT 24 NULL,
	RegisterOT smallint DEFAULT 1 NULL,
	InheritDeptRule smallint DEFAULT 1 NULL,
	EMPRIVILEGE smallint DEFAULT 0 NULL,
	CardNo varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FaceGroup int DEFAULT 0 NULL,
	AccGroup int DEFAULT 1 NULL,
	UseAccGroupTZ int DEFAULT 1 NULL,
	VerifyCode int DEFAULT 0 NULL,
	Expires int DEFAULT 0 NULL,
	ValidCount int DEFAULT 0 NULL,
	ValidTimeBegin datetime NULL,
	ValidTimeEnd datetime NULL,
	TimeZone1 int DEFAULT 1 NULL,
	TimeZone2 int DEFAULT 0 NULL,
	TimeZone3 int DEFAULT 0 NULL,
	IDCardNo varchar(18) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IDCardValidTime varchar(21) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT USERIDS PRIMARY KEY (USERID)
);
 CREATE UNIQUE NONCLUSTERED INDEX BADGENUMBER ON HRMIS.dbo.USERINFO (  BADGENUMBER ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
