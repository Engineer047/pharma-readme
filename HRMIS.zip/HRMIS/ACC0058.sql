-- HRMIS.dbo.ACC0058 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0058;

CREATE TABLE HRMIS.dbo.ACC0058 (
	PayrollParameterId int IDENTITY(1,1) NOT NULL,
	PayrollParameter nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PayrollCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PayrollDescription nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0058 PRIMARY KEY (PayrollParameterId)
);
