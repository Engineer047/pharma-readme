-- HRMIS.dbo.OVERTIME_HOD definition

-- Drop table

-- DROP TABLE HRMIS.dbo.OVERTIME_HOD;

CREATE TABLE HRMIS.dbo.OVERTIME_HOD (
	OvertimeHodId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Hours decimal(18,2) NULL,
	MonthDays int NULL,
	OvertimeId int NULL,
	MonthName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Approved bit DEFAULT 0 NULL,
	Posted bit NULL,
	ApprovedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UpdatedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_OVERTIME_HOD PRIMARY KEY (OvertimeHodId)
);
