-- HRMIS.dbo.ACC0085 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0085;

CREATE TABLE HRMIS.dbo.ACC0085 (
	NonCashBenefitId int IDENTITY(1,1) NOT NULL,
	NonCashBenefit nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue decimal(18,2) NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsTaxable bit NULL,
	CONSTRAINT [PK_ACC0085.1] PRIMARY KEY (NonCashBenefitId)
);
