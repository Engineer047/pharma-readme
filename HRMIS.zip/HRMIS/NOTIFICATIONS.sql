-- HRMIS.dbo.NOTIFICATIONS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.NOTIFICATIONS;

CREATE TABLE HRMIS.dbo.NOTIFICATIONS (
	NotificationId bigint IDENTITY(1,1) NOT NULL,
	CategoryId int NULL,
	Notification nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	Seen bit DEFAULT 0 NULL,
	Link nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_NOTIFICATIONS PRIMARY KEY (NotificationId)
);
