-- HRMIS.dbo.ACC00555 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC00555;

CREATE TABLE HRMIS.dbo.ACC00555 (
	[Year] int NULL,
	[Month] int NULL
);
