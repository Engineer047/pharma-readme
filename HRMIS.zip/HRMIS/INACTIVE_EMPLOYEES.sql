-- HRMIS.dbo.INACTIVE_EMPLOYEES definition

-- Drop table

-- DROP TABLE HRMIS.dbo.INACTIVE_EMPLOYEES;

CREATE TABLE HRMIS.dbo.INACTIVE_EMPLOYEES (
	InactiveId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	DateRemoved date NULL,
	Reason nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateReturned date NULL,
	Active bit NULL,
	CONSTRAINT PK_INACTIVE_EMPLOYEES PRIMARY KEY (InactiveId)
);
