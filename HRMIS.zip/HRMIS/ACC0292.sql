-- HRMIS.dbo.ACC0292 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0292;

CREATE TABLE HRMIS.dbo.ACC0292 (
	EmpClaimLineId int IDENTITY(1,1) NOT NULL,
	EmpClaimId int NULL,
	DestinationCategoryId int NULL,
	DestinationId int NULL,
	ExpenseTypeId int NULL,
	Amount float NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AmountAccountedFor float NULL,
	DocumentUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AdminApproval bit DEFAULT 0 NULL,
	StartDate date NULL,
	EndDate date NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TransactionDate date NULL,
	ExpenseName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cancelled bit DEFAULT 0 NULL,
	Approved bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0292 PRIMARY KEY (EmpClaimLineId)
);
