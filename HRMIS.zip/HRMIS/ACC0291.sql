-- HRMIS.dbo.ACC0291 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0291;

CREATE TABLE HRMIS.dbo.ACC0291 (
	EmpClaimId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	ClaimTypeId int NULL,
	SysDate datetime DEFAULT getdate() NULL,
	Approved bit DEFAULT 0 NULL,
	DateApproved date NULL,
	Declined bit DEFAULT 0 NULL,
	DateDeclined date NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	MonthId int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	StartDate date NULL,
	EndDate date NULL,
	Claim nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TransactionDate date NULL,
	ExternalSource nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ExternalDocumentNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cancelled bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0291 PRIMARY KEY (EmpClaimId)
);
