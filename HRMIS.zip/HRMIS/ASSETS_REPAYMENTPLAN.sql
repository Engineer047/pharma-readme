-- HRMIS.dbo.ASSETS_REPAYMENTPLAN definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ASSETS_REPAYMENTPLAN;

CREATE TABLE HRMIS.dbo.ASSETS_REPAYMENTPLAN (
	AssetPlanId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	AssetId int NULL,
	EmpAssetId int NULL,
	CurrentValue decimal(18,2) NULL,
	Cost decimal(18,2) NULL,
	UsefulLife decimal(18,2) NULL,
	DateSpoiled date NULL,
	MonthlyInstallment AS ([dbo].[fGetAssetInstallment]([AssetId],[CurrentValue],[Period])),
	Period decimal(18,2) NULL,
	Balance AS ([dbo].[fGetAssetBalance]([AssetPlanId],[CurrentValue])),
	CONSTRAINT PK_ASSETS_REPAYMENTPLAN PRIMARY KEY (AssetPlanId)
);
