-- HRMIS.dbo.ACC0290 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0290;

CREATE TABLE HRMIS.dbo.ACC0290 (
	ClaimTypeId int IDENTITY(1,1) NOT NULL,
	ClaimType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0290 PRIMARY KEY (ClaimTypeId)
);
