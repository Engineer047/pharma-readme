-- HRMIS.dbo.ACC0036_UPLOAD definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0036_UPLOAD;

CREATE TABLE HRMIS.dbo.ACC0036_UPLOAD (
	EmpCourseId int IDENTITY(1,1) NOT NULL,
	Course nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EducationLevelId int NULL,
	Institution nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ECFrom date NULL,
	ECTo date NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Grade nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Points nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Ranking int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Confirmed bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0036_UPLOAD PRIMARY KEY (EmpCourseId)
);
