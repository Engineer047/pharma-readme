-- HRMIS.dbo.ACC0148 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0148;

CREATE TABLE HRMIS.dbo.ACC0148 (
	RegisterId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime2 DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RegisterDate date NULL,
	[Year] int NULL,
	[Month] int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ShiftId int NULL,
	SFrom time NULL,
	STo time NULL,
	SLFrom time NULL,
	SLTo time NULL,
	Locked bit NULL,
	PayRate float NULL,
	Overtime float NULL,
	Penalty float NULL,
	Pay float NULL,
	LateMinutes decimal(18,2) NULL,
	OvertimeMinutes decimal(18,2) NULL,
	LateHours decimal(18,2) NULL,
	OvertimeHours decimal(18,2) NULL,
	IsCasual bit NULL,
	YearId int NULL,
	MonthId int NULL,
	EmpFrom datetime NULL,
	EmpTo datetime NULL,
	PayPerMinute AS ([dbo].[fGetPayPerMinute]([EmpId])),
	EmpFrom1 datetime NULL,
	EmpTo1 datetime NULL,
	EmpFrom2 decimal(18,4) NULL,
	EmpTo2 decimal(18,4) NULL,
	EmpPenalise bit NULL,
	EmpOvertime bit NULL,
	ShiftPenalise bit NULL,
	ShiftOvertime bit NULL,
	IsClosed bit NULL,
	IsPaid bit NULL,
	TotalPenalties decimal(18,4) NULL,
	TotalOvertime decimal(18,4) NULL,
	CONSTRAINT PK_ACC0148 PRIMARY KEY (RegisterId)
);
