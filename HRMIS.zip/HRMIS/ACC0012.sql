-- HRMIS.dbo.ACC0012 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0012;

CREATE TABLE HRMIS.dbo.ACC0012 (
	SalutationId int IDENTITY(1,1) NOT NULL,
	Salutation nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0012 PRIMARY KEY (SalutationId)
);
