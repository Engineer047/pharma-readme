-- HRMIS.dbo.ACC0022 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0022;

CREATE TABLE HRMIS.dbo.ACC0022 (
	FinancialId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BasicPay float NULL,
	Relief float NULL,
	Nssf float NULL,
	Nhif float NULL,
	LiabilityBalance float NULL,
	CONSTRAINT PK_ACC0022 PRIMARY KEY (FinancialId)
);
