-- HRMIS.dbo.ACC0065 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0065;

CREATE TABLE HRMIS.dbo.ACC0065 (
	HRScheduleId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	HRSDate date NULL,
	HRSFromTime time NULL,
	HRSToTime time NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Naration nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Venue nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0065 PRIMARY KEY (HRScheduleId)
);
