-- HRMIS.dbo.ACC0082 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0082;

CREATE TABLE HRMIS.dbo.ACC0082 (
	VacancyRequisitionId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	CompanyId int NULL,
	OfficeId int NULL,
	BranchId int NULL,
	DivisionId int NULL,
	DepartmentId int NULL,
	SectionId int NULL,
	JobDescriptionId int NULL,
	JobTitleId int NULL,
	VRFrom date NULL,
	VRTo date NULL,
	Approaved bit DEFAULT 0 NULL,
	Declined bit DEFAULT 0 NULL,
	Email bit DEFAULT 0 NULL,
	WebInterface bit DEFAULT 0 NULL,
	NewsPaper bit DEFAULT 0 NULL,
	[Others] bit DEFAULT 0 NULL,
	Country nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '0' NULL,
	DateApproved date NULL,
	Memo nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Positions int NULL,
	CurrencyId int DEFAULT 7 NULL,
	Remuneration decimal(18,2) NULL,
	JobGroupId int NULL,
	Expired AS ([dbo].[fGetRequisitionExpired]([VacancyRequisitionId])),
	CONSTRAINT PK_ACC0082 PRIMARY KEY (VacancyRequisitionId)
);
