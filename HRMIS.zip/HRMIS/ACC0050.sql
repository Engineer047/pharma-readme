-- HRMIS.dbo.ACC0050 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0050;

CREATE TABLE HRMIS.dbo.ACC0050 (
	LoanTypeId int IDENTITY(1,1) NOT NULL,
	LoanType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	InterestMethodId int NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultInterest float NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MaxAmount float NULL,
	IsCompanyLoan bit NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0050 PRIMARY KEY (LoanTypeId)
);
