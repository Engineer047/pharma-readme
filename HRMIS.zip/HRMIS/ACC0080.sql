-- HRMIS.dbo.ACC0080 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0080;

CREATE TABLE HRMIS.dbo.ACC0080 (
	PortalDocumentId int IDENTITY(1,1) NOT NULL,
	PortalDocument nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentUrl nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Approaved bit NULL,
	CONSTRAINT PK_ACC0080 PRIMARY KEY (PortalDocumentId)
);
