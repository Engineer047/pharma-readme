-- HRMIS.dbo.ADDITIONS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ADDITIONS;

CREATE TABLE HRMIS.dbo.ADDITIONS (
	EMPNO nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NAME nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[REF] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AMOUNT decimal(18,2) NULL,
	ALLOWANCE nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DEPT nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EMPID int NULL,
	ALLOWANCEID int NULL
);
