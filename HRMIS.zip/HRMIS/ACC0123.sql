-- HRMIS.dbo.ACC0123 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0123;

CREATE TABLE HRMIS.dbo.ACC0123 (
	Id int IDENTITY(1,1) NOT NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AuditTax decimal(18,2) NULL,
	PAYE decimal(18,2) NULL,
	FringeBenefit decimal(18,2) NULL,
	DatePaid date NULL,
	MonthId int NULL,
	YearId int NULL,
	[Month] int NULL,
	[Year] int NULL,
	CONSTRAINT PK_P10 PRIMARY KEY (Id)
);
