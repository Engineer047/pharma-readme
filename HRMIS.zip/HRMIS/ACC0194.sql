-- HRMIS.dbo.ACC0194 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0194;

CREATE TABLE HRMIS.dbo.ACC0194 (
	AppraisalFeedbackid int IDENTITY(1,1) NOT NULL,
	AppraisalId int NOT NULL,
	EmpId int NOT NULL,
	AppraiseeComment nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	HODComment nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	HRDptAction nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0194 PRIMARY KEY (AppraisalFeedbackid,AppraisalId,EmpId)
);
