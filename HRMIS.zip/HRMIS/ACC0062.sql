-- HRMIS.dbo.ACC0062 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0062;

CREATE TABLE HRMIS.dbo.ACC0062 (
	PayrollEarningId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PayrollDate date NULL,
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AmountEarned float NULL,
	CONSTRAINT PK_ACC0062 PRIMARY KEY (PayrollEarningId)
);
