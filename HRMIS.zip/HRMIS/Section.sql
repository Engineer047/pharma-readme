-- HRMIS.dbo.[Section] definition

-- Drop table

-- DROP TABLE HRMIS.dbo.[Section];

CREATE TABLE HRMIS.dbo.[Section] (
	[Section] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
