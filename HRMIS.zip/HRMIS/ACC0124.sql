-- HRMIS.dbo.ACC0124 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0124;

CREATE TABLE HRMIS.dbo.ACC0124 (
	id int IDENTITY(1,1) NOT NULL,
	EmpPIN nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Emoluments decimal(18,2) NULL,
	Paye decimal(18,2) NULL,
	EmpName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	[Year] int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Quarter int NULL,
	CONSTRAINT PK_P10A PRIMARY KEY (id)
);
