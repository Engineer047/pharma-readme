-- HRMIS.dbo.DUMMY definition

-- Drop table

-- DROP TABLE HRMIS.dbo.DUMMY;

CREATE TABLE HRMIS.dbo.DUMMY (
	Id int NULL,
	EmpId int NULL,
	FirstName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LastName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Gender int NULL
);
