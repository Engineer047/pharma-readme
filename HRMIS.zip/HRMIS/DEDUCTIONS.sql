-- HRMIS.dbo.DEDUCTIONS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.DEDUCTIONS;

CREATE TABLE HRMIS.dbo.DEDUCTIONS (
	EMPID int NULL,
	EMPNO nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NAME nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	INCOMETAX decimal(18,2) NULL,
	NSSF decimal(18,2) NULL,
	NHIF decimal(18,2) NULL,
	RentCustomParamId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RENT nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MiscCustomParamId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MISC decimal(18,2) NULL,
	LascCustomParamId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LASC decimal(18,2) NULL,
	UnionsCustomParamId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UNIONS decimal(18,2) NULL,
	CoopSharesSaccoId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	COOP decimal(18,2) NULL,
	LoanPrincipalSaccoId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LOANPRINCIPAL decimal(18,2) NULL,
	LoanInterestSaccoId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LOANINTEREST decimal(18,2) NULL,
	TitheCustomParamId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TITHE decimal(18,2) NULL,
	ChurchCustomParamId nchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CHURCH decimal(18,2) NULL
);
