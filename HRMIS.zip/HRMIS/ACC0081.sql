-- HRMIS.dbo.ACC0081 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0081;

CREATE TABLE HRMIS.dbo.ACC0081 (
	PrivateMessageId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	Subject nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Message nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Delivered bit NULL,
	PMFrom date NULL,
	PMTo date NULL,
	SMS bit NULL,
	Email bit NULL,
	Interface bit NULL,
	CONSTRAINT PK_ACC0081 PRIMARY KEY (PrivateMessageId)
);
