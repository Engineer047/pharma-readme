-- HRMIS.dbo.ACC0229 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0229;

CREATE TABLE HRMIS.dbo.ACC0229 (
	MembershipId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	MembershipTypeId int NULL,
	SubscriptionPaidById int NULL,
	SubscriptionAmount decimal(18,2) NULL,
	CurrencyId int NULL,
	CommencementDate date NULL,
	RenewalDate date NULL,
	CONSTRAINT PK_ACC0229 PRIMARY KEY (MembershipId)
);
