-- HRMIS.dbo.ACC0286 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0286;

CREATE TABLE HRMIS.dbo.ACC0286 (
	HRStructurePositionId int IDENTITY(1,10000001) NOT NULL,
	Companyid int NULL,
	OfficeId int NULL,
	DepartmentId int NULL,
	DivisionId int NULL,
	SectionId int NULL,
	JobTitleId int NULL,
	Positions int NULL,
	FilledPositions AS ([dbo].[fGetPositionsFilled]([CompanyId],[OfficeId],[DivisionId],[DepartmentId],[SectionId],[JobTitleId])),
	VacantPositions AS ([Positions]-[dbo].[fGetPositionsFilled]([CompanyId],[OfficeId],[DivisionId],[DepartmentId],[SectionId],[JobTitleId])),
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitle nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Budget float NULL,
	HireModel nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0286 PRIMARY KEY (HRStructurePositionId)
);
