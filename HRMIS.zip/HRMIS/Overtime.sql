-- HRMIS.dbo.Overtime definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Overtime;

CREATE TABLE HRMIS.dbo.Overtime (
	OvertimeId int IDENTITY(1,1) NOT NULL,
	Overtime nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Rate decimal(18,2) NULL,
	CONSTRAINT PK_Overtime PRIMARY KEY (OvertimeId)
);
