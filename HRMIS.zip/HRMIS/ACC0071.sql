-- HRMIS.dbo.ACC0071 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0071;

CREATE TABLE HRMIS.dbo.ACC0071 (
	RatingId int IDENTITY(1,1) NOT NULL,
	RatingCategoryId int NOT NULL,
	Rating nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Rate decimal(18,2) NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0071 PRIMARY KEY (RatingId)
);
