-- HRMIS.dbo.ESS0052 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ESS0052;

CREATE TABLE HRMIS.dbo.ESS0052 (
	LoanTransactionId int IDENTITY(1,1) NOT NULL,
	EmpLoanId int NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Year] int NULL,
	[Month] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TotalLoanAmount decimal(18,2) NULL,
	BalanceBefore decimal(18,2) NULL,
	AmountDeducted decimal(18,2) NULL,
	InterestRate decimal(18,2) NULL,
	InterestCharged decimal(18,2) NULL,
	BalanceAfter AS ([BalanceBefore]-[AmountDeducted]),
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Posted bit NULL,
	LoanTypeId int NULL,
	CONSTRAINT PK_ESS0052 PRIMARY KEY (LoanTransactionId)
);
