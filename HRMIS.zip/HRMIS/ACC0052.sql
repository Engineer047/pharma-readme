-- HRMIS.dbo.ACC0052 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0052;

CREATE TABLE HRMIS.dbo.ACC0052 (
	LoanTransactionId int IDENTITY(1,1) NOT NULL,
	EmpLoanId int NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	CompanyId int NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Year] int NULL,
	[Month] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TotalLoanAmount decimal(18,2) NULL,
	BalanceBefore decimal(18,2) NULL,
	AmountDeducted decimal(18,1) NULL,
	InterestRate AS ([dbo].[fGetInterestRates]([LoanTypeId])),
	PrincipalPortion decimal(18,2) NULL,
	InterestCharged decimal(18,2) NULL,
	BalanceAfter AS ([BalanceBefore]-[PrincipalPortion]),
	Memo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Posted bit NULL,
	LoanTypeId int NULL,
	Closed bit DEFAULT 0 NULL,
	Edited bit DEFAULT 0 NULL,
	LoanType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	LoanTax decimal(18,2) NULL,
	CONSTRAINT PK_ACC0052 PRIMARY KEY (LoanTransactionId)
);
