-- HRMIS.dbo.ACC0092 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0092;

CREATE TABLE HRMIS.dbo.ACC0092 (
	PensionId int IDENTITY(1,1) NOT NULL,
	Pension nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	EmployerRate float NULL,
	IsTaxable bit NULL,
	CustomParameterType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	MonthId int NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0092 PRIMARY KEY (PensionId)
);
