-- HRMIS.dbo.ACC0284 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0284;

CREATE TABLE HRMIS.dbo.ACC0284 (
	TravelTrailId int IDENTITY(1,1) NOT NULL,
	TravelId int NULL,
	SysDate datetime DEFAULT getdate() NULL,
	EmpNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Response nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IP nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ComputerName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UserName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0284 PRIMARY KEY (TravelTrailId)
);
