-- HRMIS.dbo.ACC0167 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0167;

CREATE TABLE HRMIS.dbo.ACC0167 (
	DutyId int IDENTITY(1,1) NOT NULL,
	Duty nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SubContratorId int NULL,
	RatePerHour decimal(18,2) NULL,
	HoursPerWeek decimal(18,2) NULL,
	NoOfWeeks decimal(18,2) NULL,
	CONSTRAINT PK_ACC0167 PRIMARY KEY (DutyId)
);
