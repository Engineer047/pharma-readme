-- HRMIS.dbo.ACC0453 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0453;

CREATE TABLE HRMIS.dbo.ACC0453 (
	YearWeekId int NOT NULL,
	YearId int NULL,
	Week nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SFrom date NULL,
	STo date NULL,
	Closed bit DEFAULT 0 NULL,
	ClosedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthId int NULL,
	CONSTRAINT PK_ACC0453 PRIMARY KEY (YearWeekId)
);
