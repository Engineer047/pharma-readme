-- HRMIS.dbo.A1 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.A1;

CREATE TABLE HRMIS.dbo.A1 (
	timein1 date NULL,
	timeout1 date NULL
);
