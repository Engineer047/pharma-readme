-- HRMIS.dbo.Projects definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Projects;

CREATE TABLE HRMIS.dbo.Projects (
	ProjectId int IDENTITY(1,1) NOT NULL,
	ProjectName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AccountName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AccountCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ProjectCode nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Active bit NULL,
	CONSTRAINT PK_Projects PRIMARY KEY (ProjectId)
);
