-- HRMIS.dbo.ACC0043 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0043;

CREATE TABLE HRMIS.dbo.ACC0043 (
	EmpNextOfKinId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RelationShip nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0043 PRIMARY KEY (EmpNextOfKinId)
);
