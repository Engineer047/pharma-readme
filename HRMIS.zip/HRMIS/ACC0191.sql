-- HRMIS.dbo.ACC0191 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0191;

CREATE TABLE HRMIS.dbo.ACC0191 (
	StrenghtId int IDENTITY(1,1) NOT NULL,
	Appraisalid int NOT NULL,
	EmpId int NOT NULL,
	Strength nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0191 PRIMARY KEY (StrenghtId,Appraisalid,EmpId),
	CONSTRAINT FK_ACC0191_ACC0188 FOREIGN KEY (Appraisalid,EmpId) REFERENCES HRMIS.dbo.ACC0188(AppraisalId,EmpId)
);
