-- HRMIS.dbo.ACC0212 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0212;

CREATE TABLE HRMIS.dbo.ACC0212 (
	CompetencyratingId int IDENTITY(1,1) NOT NULL,
	Score decimal(18,2) NULL,
	Rating nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0212 PRIMARY KEY (CompetencyratingId)
);
