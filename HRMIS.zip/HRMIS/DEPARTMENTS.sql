-- HRMIS.dbo.DEPARTMENTS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.DEPARTMENTS;

CREATE TABLE HRMIS.dbo.DEPARTMENTS (
	DEPTID int IDENTITY(1,1) NOT NULL,
	DEPTNAME nvarchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SUPDEPTID int DEFAULT 1 NOT NULL,
	InheritParentSch smallint DEFAULT 1 NULL,
	InheritDeptSch smallint DEFAULT 1 NULL,
	InheritDeptSchClass smallint DEFAULT 1 NULL,
	AutoSchPlan smallint DEFAULT 1 NULL,
	InLate smallint DEFAULT 1 NULL,
	OutEarly smallint DEFAULT 1 NULL,
	InheritDeptRule smallint DEFAULT 1 NULL,
	MinAutoSchInterval int DEFAULT 24 NULL,
	RegisterOT smallint DEFAULT 1 NULL,
	DefaultSchId int DEFAULT 1 NULL,
	ATT smallint DEFAULT 1 NULL,
	Holiday smallint DEFAULT 1 NULL,
	OverTime smallint DEFAULT 1 NULL,
	CONSTRAINT aaaaaDEPARTMENTS_PK PRIMARY KEY (DEPTID)
);
