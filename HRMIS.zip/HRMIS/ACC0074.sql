-- HRMIS.dbo.ACC0074 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0074;

CREATE TABLE HRMIS.dbo.ACC0074 (
	ReviewId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SalaryBefore float NULL,
	NewSalary float NULL,
	Difference float NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ReviewedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0074 PRIMARY KEY (ReviewId)
);
