-- HRMIS.dbo.ACC0211 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0211;

CREATE TABLE HRMIS.dbo.ACC0211 (
	TrainingStatusId int IDENTITY(1,1) NOT NULL,
	TrainingStatus nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0211 PRIMARY KEY (TrainingStatusId)
);
