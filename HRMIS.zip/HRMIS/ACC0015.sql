-- HRMIS.dbo.ACC0015 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0015;

CREATE TABLE HRMIS.dbo.ACC0015 (
	CurrencyId int IDENTITY(1,1) NOT NULL,
	Currency nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ExchangeRate float NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0015 PRIMARY KEY (CurrencyId)
);
