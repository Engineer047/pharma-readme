-- HRMIS.dbo.Templates definition

-- Drop table

-- DROP TABLE HRMIS.dbo.Templates;

CREATE TABLE HRMIS.dbo.Templates (
	TemplateId int IDENTITY(1,1) NOT NULL,
	TemplateURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContractURL nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_Templates PRIMARY KEY (TemplateId)
);
