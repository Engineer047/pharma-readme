-- HRMIS.dbo.tribe definition

-- Drop table

-- DROP TABLE HRMIS.dbo.tribe;

CREATE TABLE HRMIS.dbo.tribe (
	Tribe nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
