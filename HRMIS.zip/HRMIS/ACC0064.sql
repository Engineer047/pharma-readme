-- HRMIS.dbo.ACC0064 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0064;

CREATE TABLE HRMIS.dbo.ACC0064 (
	SummaryId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime DEFAULT getdate() NULL,
	[Year] int NULL,
	[Month] int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	NETAmount float NULL,
	PAYE float NULL,
	NSSF float NULL,
	NHIF float NULL,
	Advances float NULL,
	Overtime float NULL,
	Penalties float NULL,
	CONSTRAINT PK_ACC0064 PRIMARY KEY (SummaryId)
);
