-- HRMIS.dbo.AdvanceGroups definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AdvanceGroups;

CREATE TABLE HRMIS.dbo.AdvanceGroups (
	AdvanceGroupId int IDENTITY(1,1) NOT NULL,
	JobGroupId int NULL,
	JobGroup nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MaxAmount decimal(18,2) NULL,
	CONSTRAINT PK_AdvanceGroups PRIMARY KEY (AdvanceGroupId)
);
