-- HRMIS.dbo.ACC0399 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0399;

CREATE TABLE HRMIS.dbo.ACC0399 (
	NssfId int IDENTITY(1,1) NOT NULL,
	Tier1MaxAmount decimal(18,2) NULL,
	Tier1Rate decimal(18,2) NULL,
	Tier2MaxAmount decimal(18,2) NULL,
	Tier2Rate decimal(18,2) NULL,
	Tier1MaxAmount1 decimal(18,2) NULL,
	Tier1Rate1 decimal(18,2) NULL,
	Tier2MaxAmount1 decimal(18,2) NULL,
	Tier2Rate1 decimal(18,2) NULL,
	EmployerNssfNumber nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0399 PRIMARY KEY (NssfId)
);
