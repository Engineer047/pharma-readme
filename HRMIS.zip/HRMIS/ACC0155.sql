-- HRMIS.dbo.ACC0155 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0155;

CREATE TABLE HRMIS.dbo.ACC0155 (
	ClaimsDocumentId int IDENTITY(1,1) NOT NULL,
	ClaimsId int NOT NULL,
	EmpId int NOT NULL,
	DocName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentUrl nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0155_1 PRIMARY KEY (ClaimsDocumentId,ClaimsId,EmpId),
	CONSTRAINT FK_ACC0155_ACC01541 FOREIGN KEY (ClaimsId,EmpId) REFERENCES HRMIS.dbo.ACC0154(ClaimsId,EmpId)
);
