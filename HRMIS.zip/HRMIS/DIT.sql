-- HRMIS.dbo.DIT definition

-- Drop table

-- DROP TABLE HRMIS.dbo.DIT;

CREATE TABLE HRMIS.dbo.DIT (
	DITID int IDENTITY(1,1) NOT NULL,
	Amount decimal(18,2) NULL,
	RegNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_DIT PRIMARY KEY (DITID)
);
