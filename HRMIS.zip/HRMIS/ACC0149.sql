-- HRMIS.dbo.ACC0149 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0149;

CREATE TABLE HRMIS.dbo.ACC0149 (
	UserGroupId int IDENTITY(1,1) NOT NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UserGroup nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IsActive bit DEFAULT 1 NULL,
	CONSTRAINT PK_ACC0149 PRIMARY KEY (UserGroupId)
);
