-- HRMIS.dbo.ACC0042 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0042;

CREATE TABLE HRMIS.dbo.ACC0042 (
	NextOfKinId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Relationship nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Organization nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitle nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Memo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Notes nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Profession nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CellPhone nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PostalAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PhysicalAddress nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0042 PRIMARY KEY (NextOfKinId)
);
