-- HRMIS.dbo.UPLOAD_BASICPAY definition

-- Drop table

-- DROP TABLE HRMIS.dbo.UPLOAD_BASICPAY;

CREATE TABLE HRMIS.dbo.UPLOAD_BASICPAY (
	BasicUploadsId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BasicPay decimal(18,2) NULL,
	Confirmed bit NULL,
	CONSTRAINT PK_UPLOAD_BASICPAY PRIMARY KEY (BasicUploadsId)
);
