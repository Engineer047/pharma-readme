-- HRMIS.dbo.aspnet_Users definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_Users;

CREATE TABLE HRMIS.dbo.aspnet_Users (
	ApplicationId uniqueidentifier NOT NULL,
	UserId uniqueidentifier DEFAULT newid() NOT NULL,
	UserName nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	LoweredUserName nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	MobileAlias nvarchar(16) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT NULL NULL,
	IsAnonymous bit DEFAULT 0 NOT NULL,
	LastActivityDate datetime NOT NULL,
	CONSTRAINT PK__aspnet_U__1788CC4D654973F8 PRIMARY KEY (UserId),
	CONSTRAINT FK__aspnet_Us__Appli__583CFE97 FOREIGN KEY (ApplicationId) REFERENCES HRMIS.dbo.aspnet_Applications(ApplicationId)
);
 CREATE UNIQUE CLUSTERED INDEX aspnet_Users_Index ON HRMIS.dbo.aspnet_Users (  ApplicationId ASC  , LoweredUserName ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
 CREATE NONCLUSTERED INDEX aspnet_Users_Index2 ON HRMIS.dbo.aspnet_Users (  ApplicationId ASC  , LastActivityDate ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
