-- HRMIS.dbo.ACC0276 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0276;

CREATE TABLE HRMIS.dbo.ACC0276 (
	InterviewCriteriaId int IDENTITY(1,1) NOT NULL,
	SpecificationCriteria nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Weight decimal(18,2) NULL,
	RelatedQuestions nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	JobTitleId int NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0276 PRIMARY KEY (InterviewCriteriaId)
);
