-- HRMIS.dbo.ACC0161 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0161;

CREATE TABLE HRMIS.dbo.ACC0161 (
	ConditionDueToId int IDENTITY(1,1) NOT NULL,
	ConditionDueTo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0161 PRIMARY KEY (ConditionDueToId)
);
