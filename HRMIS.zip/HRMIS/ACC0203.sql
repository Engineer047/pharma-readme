-- HRMIS.dbo.ACC0203 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0203;

CREATE TABLE HRMIS.dbo.ACC0203 (
	TrainingId int IDENTITY(1,1) NOT NULL,
	TrainingPeriodName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TrainingStartDate date NULL,
	TrainingEndDate date NULL,
	TrainingPeriodDescription nvarchar(2000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0203 PRIMARY KEY (TrainingId)
);
