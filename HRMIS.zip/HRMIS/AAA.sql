-- HRMIS.dbo.AAA definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AAA;

CREATE TABLE HRMIS.dbo.AAA (
	employeeid int NULL,
	basicpay nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
);
