-- HRMIS.dbo.ACC0127 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0127;

CREATE TABLE HRMIS.dbo.ACC0127 (
	id int IDENTITY(1,1) NOT NULL,
	EmpPIN nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	Emoluments decimal(18,2) NOT NULL,
	Paye decimal(18,2) NOT NULL,
	EmpName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	YearQuarter int NULL,
	[Year] int NULL,
	YearId int NULL,
	EmpId int NULL,
	MonthEnding nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthBeginning nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_P10D PRIMARY KEY (id)
);
