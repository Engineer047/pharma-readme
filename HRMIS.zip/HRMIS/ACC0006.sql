-- HRMIS.dbo.ACC0006 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0006;

CREATE TABLE HRMIS.dbo.ACC0006 (
	DepartmentId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CreditAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DebitAccount nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Email nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ContactPerson nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Manager nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AssManager nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ASSMNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0006 PRIMARY KEY (DepartmentId)
);
