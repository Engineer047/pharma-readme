-- HRMIS.dbo.ACC0210 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0210;

CREATE TABLE HRMIS.dbo.ACC0210 (
	BudgetDataId int IDENTITY(1,1) NOT NULL,
	BudgetId int NOT NULL,
	BudgetItemId int NOT NULL,
	January decimal(18,2) NULL,
	February decimal(18,2) NULL,
	March decimal(18,2) NULL,
	April decimal(18,2) NULL,
	May decimal(18,2) NULL,
	June decimal(18,2) NULL,
	July decimal(18,2) NULL,
	August decimal(18,2) NULL,
	September decimal(18,2) NULL,
	October decimal(18,2) NULL,
	November decimal(18,2) NULL,
	December decimal(18,2) NULL,
	CONSTRAINT PK_ACC0210 PRIMARY KEY (BudgetDataId,BudgetId,BudgetItemId)
);
