-- HRMIS.dbo.ACC0152 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0152;

CREATE TABLE HRMIS.dbo.ACC0152 (
	UserUserGroupId int IDENTITY(1,1) NOT NULL,
	UserGroupId int NULL,
	ActivationDate datetime DEFAULT getdate() NULL,
	IsActive bit DEFAULT 0 NULL,
	UserNameId nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UserId uniqueidentifier NULL,
	CONSTRAINT PK_ACC0152 PRIMARY KEY (UserUserGroupId)
);
