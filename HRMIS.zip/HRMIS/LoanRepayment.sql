-- HRMIS.dbo.LoanRepayment definition

-- Drop table

-- DROP TABLE HRMIS.dbo.LoanRepayment;

CREATE TABLE HRMIS.dbo.LoanRepayment (
	StaffId int IDENTITY(1,1) NOT NULL,
	StaffNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	loanTypeId int NULL,
	Amount decimal(18,2) NULL,
	Total decimal(18,2) NULL,
	Balance decimal(18,2) NULL,
	Period int NULL,
	[Month] int NULL,
	[Year] int NULL,
	Confirmed bit NULL,
	CONSTRAINT PK_LoanRepayment PRIMARY KEY (StaffId)
);
