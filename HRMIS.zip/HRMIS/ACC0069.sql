-- HRMIS.dbo.ACC0069 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0069;

CREATE TABLE HRMIS.dbo.ACC0069 (
	GoalTaskId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Task nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Measures nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0089 PRIMARY KEY (GoalTaskId)
);
