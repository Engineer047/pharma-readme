# HRMIS Tables

Documentation for the HRMIS extraction and reporting area has been consolidated into the root README.md.

Use ../README.md as the canonical reference for:
- HRMIS folder structure
- reporting-query coverage under HRMIS/generated queries/
- project-wide query inventory
- structural context for the extracted HRMIS DDL assets

This file is intentionally short so the project maintains one primary documentation source.
