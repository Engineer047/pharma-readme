-- HRMIS.dbo.UserUpdates definition

-- Drop table

-- DROP TABLE HRMIS.dbo.UserUpdates;

CREATE TABLE HRMIS.dbo.UserUpdates (
	UpdateId int IDENTITY(1,1) NOT NULL,
	BadgeNumber varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__UserUpda__7A0CF3C5DCE7DA81 PRIMARY KEY (UpdateId)
);
