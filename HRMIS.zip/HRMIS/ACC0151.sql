-- HRMIS.dbo.ACC0151 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0151;

CREATE TABLE HRMIS.dbo.ACC0151 (
	UserGroupModuleId int IDENTITY(1,1) NOT NULL,
	UserGroupId int NULL,
	EAGLEModuleId int NULL,
	IsActive bit DEFAULT 0 NULL,
	DateCreated datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0151 PRIMARY KEY (UserGroupModuleId)
);
