-- HRMIS.dbo.ACC0253 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0253;

CREATE TABLE HRMIS.dbo.ACC0253 (
	ProjectId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	Project nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	OrganizationId int NULL,
	FromDate date NULL,
	ToDate date NULL,
	Roles nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Details nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__ACC0253__761ABEF09C6A1BC8 PRIMARY KEY (ProjectId)
);
