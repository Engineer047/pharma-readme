-- HRMIS.dbo.ACC0121 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0121;

CREATE TABLE HRMIS.dbo.ACC0121 (
	CalenderId int IDENTITY(1,1) NOT NULL,
	Activity nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FromDate date DEFAULT getdate() NULL,
	ToDate date DEFAULT getdate() NULL,
	IsOffDay bit DEFAULT 0 NULL,
	Details nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0121_1 PRIMARY KEY (CalenderId)
);
