-- HRMIS.dbo.ACC0100 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0100;

CREATE TABLE HRMIS.dbo.ACC0100 (
	PensionId int NULL,
	CompanyId int NULL,
	EmpId int NULL,
	MonthId int NULL,
	YearId int NULL,
	Amount float NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpPensionId int IDENTITY(1,1) NOT NULL,
	Pension nvarchar(MAX) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	PensionEmployer decimal(18,2) NULL,
	PensionVol decimal(18,2) DEFAULT 0 NULL,
	Code nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DefaultValue float NULL,
	UseRate bit NULL,
	Recurring bit NULL,
	LogDate datetime DEFAULT getdate() NULL,
	Rate float NULL,
	IsTaxable bit NULL,
	CustomParameterType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cancelled bit DEFAULT 0 NULL,
	Locked bit DEFAULT 0 NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	OpeningBalVol decimal(18,2) NULL,
	OpeningBalance decimal(18,2) NULL,
	OpeningBalEmployer decimal(18,2) NULL,
	YearMonth AS ([dbo].[fGetPensionYearMonthJoint]([MonthId],[YearId])),
	TotalAmount AS ([dbo].[GetTotalPensions]([EmpId],[PensionId],[MonthId],[YearId])),
	TotalEmployer AS ([dbo].[GetTotalPensionsEmployer]([EmpId],[PensionId],[MonthId],[YearId])),
	TotalVol AS ([dbo].[GetTotalPensionsVol]([EmpId],[PensionId],[MonthId],[YearId])),
	TotalPensions AS ([dbo].[GetCumulativePensions]([EmpId],[PensionId],[MonthId],[YearId])),
	IsManual bit DEFAULT 0 NULL,
	CONSTRAINT PK_ACC0100 PRIMARY KEY (EmpPensionId)
);
