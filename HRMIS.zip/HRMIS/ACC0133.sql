-- HRMIS.dbo.ACC0133 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0133;

CREATE TABLE HRMIS.dbo.ACC0133 (
	VisibilityId int IDENTITY(1,1) NOT NULL,
	Name nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SystemDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0133 PRIMARY KEY (VisibilityId)
);
