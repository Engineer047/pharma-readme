-- HRMIS.dbo.ACC0120_CASUALS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0120_CASUALS;

CREATE TABLE HRMIS.dbo.ACC0120_CASUALS (
	RecordId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	YearId int NULL,
	MonthId int NULL,
	Week int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SysDate datetime DEFAULT getdate() NULL,
	RecordType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RecordSort int NULL,
	RecordName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Amount decimal(18,2) NULL,
	Send bit NULL,
	CompanyId int NULL,
	CONSTRAINT PK_ACC0120_CASUALS PRIMARY KEY (RecordId)
);
