-- HRMIS.dbo.EARNED_LEAVE definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EARNED_LEAVE;

CREATE TABLE HRMIS.dbo.EARNED_LEAVE (
	LeaveTypeId int NULL,
	EarnedDays decimal(18,2) NULL,
	EmpId int NULL,
	LeavePeriodId int NULL,
	MonthId int NULL,
	YearId int NULL
);
