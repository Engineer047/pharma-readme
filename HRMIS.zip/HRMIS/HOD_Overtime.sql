-- HRMIS.dbo.HOD_Overtime definition

-- Drop table

-- DROP TABLE HRMIS.dbo.HOD_Overtime;

CREATE TABLE HRMIS.dbo.HOD_Overtime (
	OTApproveId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthId int NULL,
	YearId int NULL,
	OvertimeId int NULL,
	Hours decimal(18,2) NULL,
	AprovedHours decimal(18,2) NULL,
	ApprovedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateApproved date NULL,
	Posted bit DEFAULT 0 NULL,
	PostedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DatePosted date NULL,
	Approved bit NULL,
	CONSTRAINT PK_HOD_Overtime PRIMARY KEY (OTApproveId)
);
