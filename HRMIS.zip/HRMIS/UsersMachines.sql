-- HRMIS.dbo.UsersMachines definition

-- Drop table

-- DROP TABLE HRMIS.dbo.UsersMachines;

CREATE TABLE HRMIS.dbo.UsersMachines (
	ID int IDENTITY(1,1) NOT NULL,
	USERID int NOT NULL,
	DEVICEID int NOT NULL
);
