-- HRMIS.dbo.ACC0078 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0078;

CREATE TABLE HRMIS.dbo.ACC0078 (
	FeedBackId int IDENTITY(1,1) NOT NULL,
	SystemLog datetime NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Status nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Completed bit NULL,
	Processing bit NULL,
	Declined bit NULL,
	FeedBack nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Notes nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0078 PRIMARY KEY (FeedBackId)
);
