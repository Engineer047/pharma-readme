-- HRMIS.dbo.ACC0029 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0029;

CREATE TABLE HRMIS.dbo.ACC0029 (
	CourseModuleId int IDENTITY(1,1) NOT NULL,
	CourseId int NULL,
	Module nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Cost decimal(18,2) NULL,
	CONSTRAINT PK_ACC0029 PRIMARY KEY (CourseModuleId)
);
