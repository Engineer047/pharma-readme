-- HRMIS.dbo.COMPANY_DOCUMENTS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.COMPANY_DOCUMENTS;

CREATE TABLE HRMIS.dbo.COMPANY_DOCUMENTS (
	DocumentId int IDENTITY(1,1) NOT NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocumentUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EntryDate date NULL,
	IssuedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	IssueDate date NULL,
	ExpiryDate date NULL,
	Deleted bit NULL,
	DeletedBy nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DateDeleted date NULL,
	ReasonDeleted nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Visible bit DEFAULT 0 NULL,
	CONSTRAINT PK_COMPANY_DOCUMENTS PRIMARY KEY (DocumentId)
);
