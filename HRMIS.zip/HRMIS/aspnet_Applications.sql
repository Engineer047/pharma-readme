-- HRMIS.dbo.aspnet_Applications definition

-- Drop table

-- DROP TABLE HRMIS.dbo.aspnet_Applications;

CREATE TABLE HRMIS.dbo.aspnet_Applications (
	ApplicationName nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	LoweredApplicationName nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	ApplicationId uniqueidentifier DEFAULT newid() NOT NULL,
	Description nvarchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__aspnet_A__C93A4C986770E961 PRIMARY KEY (ApplicationId),
	CONSTRAINT UQ__aspnet_A__17477DE49584DDE5 UNIQUE (LoweredApplicationName),
	CONSTRAINT UQ__aspnet_A__309103315E7CFBE5 UNIQUE (ApplicationName)
);
 CREATE CLUSTERED INDEX aspnet_Applications_Index ON HRMIS.dbo.aspnet_Applications (  LoweredApplicationName ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ] ;
