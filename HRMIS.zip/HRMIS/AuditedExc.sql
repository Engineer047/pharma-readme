-- HRMIS.dbo.AuditedExc definition

-- Drop table

-- DROP TABLE HRMIS.dbo.AuditedExc;

CREATE TABLE HRMIS.dbo.AuditedExc (
	AEID int IDENTITY(1,1) NOT NULL,
	UserId int NULL,
	CheckTime datetime NOT NULL,
	NewExcID int NULL,
	IsLeave smallint NULL,
	UName varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	UTime datetime NOT NULL,
	CONSTRAINT PK__AuditedE__40737CF3F29B1582 PRIMARY KEY (AEID)
);
