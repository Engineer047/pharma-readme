-- HRMIS.dbo.ACC0279 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0279;

CREATE TABLE HRMIS.dbo.ACC0279 (
	NationalityId int IDENTITY(1,1) NOT NULL,
	Nationality nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK__ACC0279__F628E74436746C8C PRIMARY KEY (NationalityId)
);
