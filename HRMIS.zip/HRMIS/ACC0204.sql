-- HRMIS.dbo.ACC0204 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0204;

CREATE TABLE HRMIS.dbo.ACC0204 (
	TrainerId int IDENTITY(1,1) NOT NULL,
	TrainingId int NULL,
	TrainingGroupId int NULL,
	Trainer nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0204 PRIMARY KEY (TrainerId)
);
