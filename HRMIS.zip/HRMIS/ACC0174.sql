-- HRMIS.dbo.ACC0174 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0174;

CREATE TABLE HRMIS.dbo.ACC0174 (
	RateTypeId int IDENTITY(1,1) NOT NULL,
	RateType nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0174 PRIMARY KEY (RateTypeId)
);
