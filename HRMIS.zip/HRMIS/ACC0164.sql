-- HRMIS.dbo.ACC0164 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0164;

CREATE TABLE HRMIS.dbo.ACC0164 (
	ClaimsCategoryId int IDENTITY(1,1) NOT NULL,
	ClaimsCategory nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ClaimsCategory PRIMARY KEY (ClaimsCategoryId)
);
