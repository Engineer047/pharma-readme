-- HRMIS.dbo.LEAVEMASTER definition

-- Drop table

-- DROP TABLE HRMIS.dbo.LEAVEMASTER;

CREATE TABLE HRMIS.dbo.LEAVEMASTER (
	LeaveMasterId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Balance decimal(18,2) NULL,
	LeaveTypeId int NULL,
	Confirmed bit DEFAULT 0 NULL,
	CONSTRAINT PK_LEAVEMASTER PRIMARY KEY (LeaveMasterId)
);
