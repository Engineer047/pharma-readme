-- HRMIS.dbo.TRANSFERS definition

-- Drop table

-- DROP TABLE HRMIS.dbo.TRANSFERS;

CREATE TABLE HRMIS.dbo.TRANSFERS (
	TransferId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	StartPoint nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Destination nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Date] date NULL,
	TimeFrom time NULL,
	TimeTo time NULL,
	Completed bit DEFAULT 0 NULL,
	Comments nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_TRANSFERS PRIMARY KEY (TransferId)
);
