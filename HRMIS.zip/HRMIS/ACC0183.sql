-- HRMIS.dbo.ACC0183 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0183;

CREATE TABLE HRMIS.dbo.ACC0183 (
	ExitInterviewId int IDENTITY(1,1) NOT NULL,
	EmpId int NOT NULL,
	DepartmentId int NULL,
	JotTitleId int NULL,
	LenghtOfServiceId int NULL,
	LeaveToPositionId int NULL,
	ReasonForLeavingId int NULL,
	[Date] date NULL,
	CONSTRAINT PK_ACC0183 PRIMARY KEY (ExitInterviewId,EmpId),
	CONSTRAINT FK_ACC0183_ACC0181 FOREIGN KEY (LeaveToPositionId) REFERENCES HRMIS.dbo.ACC0181(LeaveToPositionId),
	CONSTRAINT FK_ACC0183_ACC0182 FOREIGN KEY (ReasonForLeavingId) REFERENCES HRMIS.dbo.ACC0182(ReasonForLeavingId)
);
