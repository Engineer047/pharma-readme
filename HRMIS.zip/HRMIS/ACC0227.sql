-- HRMIS.dbo.ACC0227 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0227;

CREATE TABLE HRMIS.dbo.ACC0227 (
	JobContractTypeId int IDENTITY(1,1) NOT NULL,
	JobContractType nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0227 PRIMARY KEY (JobContractTypeId)
);
