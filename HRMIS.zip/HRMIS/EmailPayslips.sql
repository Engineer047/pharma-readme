-- HRMIS.dbo.EmailPayslips definition

-- Drop table

-- DROP TABLE HRMIS.dbo.EmailPayslips;

CREATE TABLE HRMIS.dbo.EmailPayslips (
	EmailPayslipsId int IDENTITY(1,1) NOT NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MonthId int NULL,
	YearId int NULL,
	Send bit DEFAULT 0 NULL,
	CONSTRAINT PK_EmailPayslips PRIMARY KEY (EmailPayslipsId)
);
