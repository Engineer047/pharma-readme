-- HRMIS.dbo.ACC0107 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0107;

CREATE TABLE HRMIS.dbo.ACC0107 (
	TaxBracketId int IDENTITY(1,1) NOT NULL,
	Rangefrom decimal(18,4) NULL,
	RangeTo decimal(18,4) NULL,
	Rate decimal(18,4) NULL,
	Value decimal(18,4) NULL,
	EmpId int NULL,
	EmpFromRange decimal(18,4) NULL,
	EmpToRange decimal(18,4) NULL,
	EmpValue decimal(18,4) NULL,
	CONSTRAINT PK_ACC0107 PRIMARY KEY (TaxBracketId)
);
