-- HRMIS.dbo.ACC0278 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0278;

CREATE TABLE HRMIS.dbo.ACC0278 (
	InterviewActionId int IDENTITY(1,1) NOT NULL,
	InterviewAction nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0278 PRIMARY KEY (InterviewActionId)
);
