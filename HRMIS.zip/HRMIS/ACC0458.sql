-- HRMIS.dbo.ACC0458 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0458;

CREATE TABLE HRMIS.dbo.ACC0458 (
	BankUploadId int IDENTITY(1,1) NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankId nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankBranchId nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankAccountNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankAcountName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Confirmed bit NULL,
	CONSTRAINT PK_ACC0458 PRIMARY KEY (BankUploadId)
);
