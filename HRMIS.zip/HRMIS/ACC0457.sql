-- HRMIS.dbo.ACC0457 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0457;

CREATE TABLE HRMIS.dbo.ACC0457 (
	AdvanceDeductionId int IDENTITY(1,1) NOT NULL,
	AdvanceId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	YearId int NULL,
	MonthId int NULL,
	MMonth nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	TotalAmount float NULL,
	AmountDeducted float NULL,
	AmountPerPayPeriod float NULL,
	CONSTRAINT PK_ACC0457 PRIMARY KEY (AdvanceDeductionId)
);
