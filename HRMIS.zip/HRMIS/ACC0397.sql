-- HRMIS.dbo.ACC0397 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0397;

CREATE TABLE HRMIS.dbo.ACC0397 (
	IccidentDocumentId int NOT NULL,
	IccidentId int NULL,
	DocumentUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Name nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	RefNo nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	SysDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0397 PRIMARY KEY (IccidentDocumentId)
);
