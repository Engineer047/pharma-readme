-- HRMIS.dbo.ACC0010 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0010;

CREATE TABLE HRMIS.dbo.ACC0010 (
	JobTitleId int IDENTITY(1,1) NOT NULL,
	JobTitle nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	MaxSalary float NULL,
	MinSalary float NULL,
	CONSTRAINT PK_ACC0010 PRIMARY KEY (JobTitleId)
);
