-- HRMIS.dbo.ACC0142 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0142;

CREATE TABLE HRMIS.dbo.ACC0142 (
	IntrospectionId int IDENTITY(1,1) NOT NULL,
	Hindances nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Achievements nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Motivations nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpId int NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	FormId int NULL,
	FormName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0142 PRIMARY KEY (IntrospectionId)
);
