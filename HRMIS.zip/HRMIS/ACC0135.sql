-- HRMIS.dbo.ACC0135 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0135;

CREATE TABLE HRMIS.dbo.ACC0135 (
	MilestoneId int IDENTITY(1,1) NOT NULL,
	TargetDate date NULL,
	Milestone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	ActualDate date NULL,
	StatusId int NULL,
	GoalId int NULL,
	SystemDate datetime DEFAULT getdate() NULL,
	CONSTRAINT PK_ACC0135 PRIMARY KEY (MilestoneId),
	CONSTRAINT FK_ACC0135_ACC0132 FOREIGN KEY (StatusId) REFERENCES HRMIS.dbo.ACC0132(GoalStatusId),
	CONSTRAINT FK_ACC0135_ACC0137 FOREIGN KEY (GoalId) REFERENCES HRMIS.dbo.ACC0137(GoalId)
);
