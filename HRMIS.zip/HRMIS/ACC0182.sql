-- HRMIS.dbo.ACC0182 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0182;

CREATE TABLE HRMIS.dbo.ACC0182 (
	ReasonForLeavingId int IDENTITY(1,1) NOT NULL,
	ReasonForLeaving nvarchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0182 PRIMARY KEY (ReasonForLeavingId)
);
