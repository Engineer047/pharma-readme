-- HRMIS.dbo.ACC0187 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0187;

CREATE TABLE HRMIS.dbo.ACC0187 (
	DisciplineId int NOT NULL,
	EmpId int NOT NULL,
	DisciplineDocId int IDENTITY(1,1) NOT NULL,
	DocUrl nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DocName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0187 PRIMARY KEY (DisciplineId,EmpId,DisciplineDocId)
);
