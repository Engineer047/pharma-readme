-- HRMIS.dbo.ACC0170 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0170;

CREATE TABLE HRMIS.dbo.ACC0170 (
	SubContractorId int IDENTITY(1,1) NOT NULL,
	SubContractor nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	DutyId int NULL,
	Address nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Town nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Telephone nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	BankBranch nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AccountName nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	AccountNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0170 PRIMARY KEY (SubContractorId),
	CONSTRAINT FK_ACC0170_ACC0167 FOREIGN KEY (DutyId) REFERENCES HRMIS.dbo.ACC0167(DutyId)
);
