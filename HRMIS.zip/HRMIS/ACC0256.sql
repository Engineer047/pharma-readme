-- HRMIS.dbo.ACC0256 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0256;

CREATE TABLE HRMIS.dbo.ACC0256 (
	DistrictId int IDENTITY(1,1) NOT NULL,
	District nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	Description nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0256 PRIMARY KEY (DistrictId)
);
