-- HRMIS.dbo.ACC0159 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0159;

CREATE TABLE HRMIS.dbo.ACC0159 (
	TimeOfServiceId int IDENTITY(1,1) NOT NULL,
	TimeOfService nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0159 PRIMARY KEY (TimeOfServiceId)
);
