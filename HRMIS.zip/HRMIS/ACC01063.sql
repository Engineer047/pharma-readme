-- HRMIS.dbo.ACC01063 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC01063;

CREATE TABLE HRMIS.dbo.ACC01063 (
	EmpManualAttId int IDENTITY(1,1) NOT NULL,
	RegisterId int NULL,
	DateAtt date NOT NULL,
	EmpId int NOT NULL,
	EmpNo nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	EmpName nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CheckIn datetime NULL,
	CheckOut datetime NULL,
	LunchIn datetime NULL,
	LunchOut datetime NULL,
	Cancelled bit NULL,
	Narration nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC01063 PRIMARY KEY (EmpManualAttId)
);
