-- HRMIS.dbo.ACC0234 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0234;

CREATE TABLE HRMIS.dbo.ACC0234 (
	CompetencyId int IDENTITY(1,1) NOT NULL,
	Competency nvarchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	CONSTRAINT PK_ACC0234 PRIMARY KEY (CompetencyId)
);
