-- HRMIS.dbo.ACC0016 definition

-- Drop table

-- DROP TABLE HRMIS.dbo.ACC0016;

CREATE TABLE HRMIS.dbo.ACC0016 (
	SettingsId int IDENTITY(1,1) NOT NULL,
	DefaultCurrencyId int NULL,
	CONSTRAINT PK_ACC0016 PRIMARY KEY (SettingsId)
);
